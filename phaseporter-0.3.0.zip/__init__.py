"""PhasePorter — フェーズ移行アドオン(Blender 拡張)。

フィギュア制作の「フェーズ = ファイル」運用を支援する:
選択オブジェクトだけを mdl_ → split_ → sculpt_ → print_ の命名規則に
沿った新規 .blend へ圧縮付きで書き出す。リグ・シミュ・旧データは
持ち込まれず、元ファイルは変更されない。
"""

from . import core, operators, ui


def register():
    operators.register()
    ui.register()


def unregister():
    ui.unregister()
    operators.unregister()
