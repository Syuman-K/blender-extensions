"""PhasePorter のコアロジック。

フェーズ移行 = 「選択オブジェクトだけを、命名規則どおりの新規 .blend に
圧縮付きで書き出す」こと。元ファイルは一切変更しない。

書き出しの仕組み:
    一時シーンを作り、各オブジェクトのクリーンコピー(親子・コンストレイント
    を外し、ワールドトランスフォームを焼き込んだもの)をリンクして
    ``bpy.data.libraries.write`` でシーンごと書き出す。シーン経由で書くことで、
    書き出先ファイルを開いたときにオブジェクトがビューレイヤーに表示される。
    依存データ(メッシュ・マテリアル・モディファイアの参照先など)は自動で
    同梱される。リグや旧コレクションなどシーン由来の資産は付いてこない。

UI に依存しない関数のみを置き、ヘッドレステストから直接呼べるようにする。
"""

import csv
import os
import re
from collections import Counter
from datetime import datetime

import bpy

# フェーズ接頭辞。ワークフロー文書の命名規則と対応:
#   mdl_ (造形) -> split_ (分割) -> sculpt_ (詳細造形) -> print_ (出力)
PHASE_PREFIXES = ("mdl", "split", "sculpt", "print")

# EvenMesh の「分割前の密度統一」プリセット値(evenmesh v0.5.0 の
# operators._PRESETS['PRESPLIT'] と同期を保つこと)。書き出し先シーンに
# あらかじめ設定しておき、開いた直後にリメッシュへ進めるようにする。
EVENMESH_PRESPLIT = dict(
    voxel_mode='AUTO',
    auto_detail=256,
    merge_mode='INTERSECT',
    merge_tol=0.0,
    fill_holes=True,
    use_decimate=True,
    decimate_ratio=0.5,
    min_tris=1000,
    triangulate=False,
    smooth_shade=False,
    keep_original=True,
)


def sanitize_kit(kit):
    """キット名から拡張子の残骸・前後の区切り文字を取り除く。

    ファイル名の手入力ミス(``hoge.blend`` のような値)がそのまま
    次ファイル名に入り込んで ``split_.blend_...`` を作らないようにする。
    無効なら空文字を返す(呼び出し側でエラーにする)。
    """
    kit = (kit or "").strip()
    while kit.lower().endswith(".blend"):
        kit = kit[:-6]
    kit = re.sub(r'[<>:"/\\|?*]', "", kit)
    return kit.strip(" ._-")


def parse_blend_name(filepath):
    """現在のファイル名から ``(phase, kit)`` を推定する。

    ``mdl_eula_260709_03.blend`` -> ``('mdl', 'eula')``。
    規則に合わない場合は ``(None, <拡張子なしファイル名>)``。
    """
    stem = os.path.splitext(os.path.basename(filepath))[0]
    m = re.match(r"^({})_(.+?)_(\d{{6}})(?:_\d+)?$".format(
        "|".join(PHASE_PREFIXES)), stem)
    if m:
        return m.group(1), sanitize_kit(m.group(2))
    m = re.match(r"^({})_(.+)$".format("|".join(PHASE_PREFIXES)), stem)
    if m:
        return m.group(1), sanitize_kit(m.group(2))
    return None, sanitize_kit(stem)


def build_filepath(directory, phase, kit, date_str=None):
    """空いている連番で ``<phase>_<kit>_<YYMMDD>_<NN>.blend`` のパスを返す。"""
    if date_str is None:
        date_str = datetime.now().strftime("%y%m%d")
    for nn in range(1, 100):
        name = "{}_{}_{}_{:02d}.blend".format(phase, kit, date_str, nn)
        path = os.path.join(directory, name)
        if not os.path.exists(path):
            return path
    raise RuntimeError("空いている連番が見つかりません: " + directory)


def _clean_copy(obj):
    """親子・コンストレイントを外しトランスフォームを確定したコピーを返す。

    メッシュデータは元とブロック共有(コピーしない)。モディファイアは
    コピーに引き継がれる(EvenMesh 側が移行先で適用する)。
    """
    dup = obj.copy()
    dup.parent = None
    for con in list(dup.constraints):
        dup.constraints.remove(con)
    dup.matrix_world = obj.matrix_world.copy()
    dup.animation_data_clear()
    return dup


def export_phase_file(context, objects, filepath, evenmesh_preset=False):
    """``objects`` のクリーンコピーだけを含む新規 .blend を書き出す。

    現在のファイルは変更しない(オブジェクト名は書き出しの間だけ一時的に
    退避し、終了時に必ず復元する)。``evenmesh_preset`` が真で EvenMesh が
    インストールされていれば、書き出し先シーンに「分割前の密度統一」
    プリセット値を設定しておく。書き出しは常に圧縮(zstd)。
    """
    src_scene = context.scene
    temp = bpy.data.scenes.new("Scene_" + os.path.splitext(
        os.path.basename(filepath))[0])
    # 単位設定は印刷スケールの前提なので必ず引き継ぐ。
    try:
        temp.unit_settings.system = src_scene.unit_settings.system
        temp.unit_settings.scale_length = src_scene.unit_settings.scale_length
        temp.unit_settings.length_unit = src_scene.unit_settings.length_unit
    except (AttributeError, TypeError):
        pass
    if evenmesh_preset and hasattr(temp, "evenmesh"):
        for name, value in EVENMESH_PRESPLIT.items():
            # インストール済み EvenMesh が古くてプロパティが無い場合は飛ばす
            if hasattr(temp.evenmesh, name):
                setattr(temp.evenmesh, name, value)

    renamed = []   # (original, dup, name)
    try:
        for obj in objects:
            dup = _clean_copy(obj)
            name = obj.name
            obj.name = name + ".pporig"
            dup.name = name
            renamed.append((obj, dup, name))
            temp.collection.objects.link(dup)
        bpy.data.libraries.write(filepath, {temp}, compress=True,
                                 fake_user=False)
    finally:
        for obj, dup, name in renamed:
            try:
                bpy.data.objects.remove(dup, do_unlink=True)
            except ReferenceError:
                pass
            obj.name = name
        bpy.data.scenes.remove(temp)
    return filepath


def write_parts_csv(objects, blend_filepath, kit):
    """パーツ一覧 CSV をキットごとに1つだけ出力してパスを返す。

    書き出し先フォルダの ``<キット名>_parts.csv`` を毎回上書きする
    (ファイルごとに CSV を増やさない)。フォーマットは既存の
    export_objects_csv.py と同じ(部品名,個数 / 合計 / 全オブジェクト名)。
    Excel 対応のため utf-8-sig。
    """
    csv_path = os.path.join(os.path.dirname(blend_filepath),
                            "{}_parts.csv".format(kit))

    def base_name(name):
        return re.sub(r"\.\d{3,}$", "", name)

    counts = Counter(base_name(o.name) for o in objects)
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["部品名", "個数"])
        for name, count in sorted(counts.items()):
            writer.writerow([name, count])
        writer.writerow([])
        writer.writerow(["合計", sum(counts.values())])
        writer.writerow([])
        writer.writerow(["--- 全オブジェクト名 ---"])
        for obj in sorted(objects, key=lambda o: o.name):
            writer.writerow([obj.name])
    return csv_path
