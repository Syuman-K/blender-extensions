"""PhasePorter のオペレーターと設定。"""

import os

import bpy
from bpy.props import BoolProperty, EnumProperty, PointerProperty, StringProperty
from bpy.types import Operator, PropertyGroup

from . import core


class PhasePorterSettings(PropertyGroup):
    target_phase: EnumProperty(
        name="移行先フェーズ",
        items=[
            ('split', "split(分割)",
             "密度統一と分割作業用のファイルへ移行する"),
            ('sculpt', "sculpt(詳細造形)",
             "分割後のリトポ・マルチレゾ詳細造形用のファイルへ移行する"),
            ('print', "print(出力)",
             "中空化・サポート・STL 書き出し用のファイルへ移行する"),
        ],
        default='split',
    )
    kit_name: StringProperty(
        name="キット名",
        default="",
        description="空のままなら現在のファイル名から自動推定する"
                    "(例: mdl_eula_260709_03.blend → eula)")
    evenmesh_preset: BoolProperty(
        name="EvenMesh プリセットを設定",
        default=True,
        description="書き出し先シーンに EvenMesh「分割前の密度統一」の設定値を"
                    "入れておく(EvenMesh 未インストール時は何もしない)。"
                    "split 移行時のみ有効")
    write_csv: BoolProperty(
        name="パーツ一覧 CSV も出力",
        default=True,
        description="書き出し先と同じフォルダの <キット名>_parts.csv を"
                    "上書き更新する(ファイルごとに増えない)")


def _resolve_kit(context):
    st = context.scene.phaseporter
    kit = core.sanitize_kit(st.kit_name)
    if kit:
        return kit
    _phase, kit = core.parse_blend_name(bpy.data.filepath or "untitled")
    return kit


def _target_path(context):
    st = context.scene.phaseporter
    directory = os.path.dirname(bpy.data.filepath) if bpy.data.filepath else ""
    if not directory:
        return None
    return core.build_filepath(directory, st.target_phase,
                               _resolve_kit(context))


class PHASEPORTER_OT_export(Operator):
    bl_idname = "phaseporter.export"
    bl_label = "フェーズ移行ファイルを書き出し"
    bl_description = ("選択中のメッシュだけを、命名規則どおりの新規 .blend に"
                     "圧縮付きで書き出す。親子・コンストレイントは外され、"
                     "現在のファイルは変更されない")
    bl_options = {'REGISTER'}

    open_after: BoolProperty(
        name="書き出して開く", default=False,
        description="書き出した .blend をそのまま開く(現在のファイルは"
                    "保存済みである必要がある)")

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        st = context.scene.phaseporter
        objects = [o for o in context.selected_objects if o.type == 'MESH']
        if not bpy.data.filepath:
            self.report({'ERROR'},
                        "現在のファイルを一度保存してから実行してください"
                        "(書き出し先フォルダと命名の基準になります)")
            return {'CANCELLED'}
        if not _resolve_kit(context):
            self.report({'ERROR'},
                        "キット名を決められません。パネルの「キット名」に"
                        "入力してください")
            return {'CANCELLED'}
        if self.open_after and bpy.data.is_dirty:
            self.report({'ERROR'},
                        "未保存の変更があります。保存してから「書き出して開く」を"
                        "実行してください")
            return {'CANCELLED'}

        target = _target_path(context)
        try:
            core.export_phase_file(
                context, objects, target,
                evenmesh_preset=(st.evenmesh_preset
                                 and st.target_phase == 'split'))
        except Exception as exc:  # noqa: BLE001 - surface any failure
            self.report({'ERROR'}, "書き出し失敗: {}".format(exc))
            return {'CANCELLED'}

        msgs = ["{} オブジェクト → {}".format(
            len(objects), os.path.basename(target))]
        if st.write_csv:
            try:
                csv_path = core.write_parts_csv(objects, target,
                                                _resolve_kit(context))
                msgs.append(os.path.basename(csv_path))
            except Exception as exc:  # noqa: BLE001
                self.report({'WARNING'}, "CSV 出力失敗: {}".format(exc))

        if self.open_after:
            bpy.ops.wm.open_mainfile(filepath=target)
        else:
            self.report({'INFO'}, "PhasePorter: " + " / ".join(msgs))
        return {'FINISHED'}


CLASSES = (
    PhasePorterSettings,
    PHASEPORTER_OT_export,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.phaseporter = PointerProperty(type=PhasePorterSettings)


def unregister():
    del bpy.types.Scene.phaseporter
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
