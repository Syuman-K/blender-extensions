"""N パネル UI (View3D > Sidebar > PhasePorter)。"""

import os

import bpy
from bpy.types import Panel

from . import operators


class PHASEPORTER_PT_main(Panel):
    bl_idname = "PHASEPORTER_PT_main"
    bl_label = "PhasePorter"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PhasePorter"

    def draw(self, context):
        st = context.scene.phaseporter
        layout = self.layout

        col = layout.column(align=True)
        col.prop(st, "target_phase")
        col.prop(st, "kit_name")

        box = layout.box()
        box.prop(st, "write_csv")
        sub = box.row()
        sub.enabled = st.target_phase == 'split'
        sub.prop(st, "evenmesh_preset")

        n_sel = sum(1 for o in context.selected_objects if o.type == 'MESH')
        target = operators._target_path(context)
        if target is None:
            layout.label(text="ファイル未保存 — 先に保存してください",
                         icon='ERROR')
        else:
            layout.label(text="→ " + os.path.basename(target),
                         icon='FILE_BLEND')
        layout.label(text="選択中のメッシュ: {}".format(n_sel))

        col = layout.column(align=True)
        op = col.operator("phaseporter.export",
                          text="書き出し", icon='EXPORT')
        op.open_after = False
        op = col.operator("phaseporter.export",
                          text="書き出して開く", icon='FILE_TICK')
        op.open_after = True


CLASSES = (
    PHASEPORTER_PT_main,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
