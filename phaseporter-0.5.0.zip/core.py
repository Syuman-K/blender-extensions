"""PhasePorter のコアロジック。

フェーズ移行 = 「選択オブジェクトだけを、命名規則どおりの新規 .blend に
圧縮付きで書き出す」こと。元ファイルは一切変更しない。

書き出しの仕組み:
    一時シーンを作り、各オブジェクトのクリーンコピー(親子・コンストレイント
    を外し、ワールドトランスフォームを焼き込んだもの)をリンクして
    ``bpy.data.libraries.write`` でシーンごと書き出す。シーン経由で書くことで、
    書き出先ファイルを開いたときにオブジェクトがビューレイヤーに表示される。
    依存データ(メッシュ・マテリアル・モディファイアの参照先など)は自動で
    同梱される。リグや旧コレクションなどシーン由来の資産は付いてこない。

UI に依存しない関数のみを置き、ヘッドレステストから直接呼べるようにする。
"""

import csv
import os
import re
from collections import Counter
from datetime import datetime

import bpy
from mathutils import Vector

# フェーズ接頭辞。ワークフロー文書の命名規則と対応:
#   mdl_ (造形) -> split_ (分割) -> sculpt_ (詳細造形) -> print_ (出力)
PHASE_PREFIXES = ("mdl", "split", "sculpt", "print")

# EvenMesh の「分割前の密度統一」プリセット値(evenmesh v0.5.0 の
# operators._PRESETS['PRESPLIT'] と同期を保つこと)。書き出し先シーンに
# あらかじめ設定しておき、開いた直後にリメッシュへ進めるようにする。
EVENMESH_PRESPLIT = dict(
    voxel_mode='AUTO',
    auto_detail=256,
    merge_mode='INTERSECT',
    merge_tol=0.0,
    fill_holes=True,
    use_decimate=True,
    decimate_ratio=0.5,
    min_tris=1000,
    triangulate=False,
    smooth_shade=False,
    keep_original=True,
)


# --------------------------------------------------------------------------- #
# シーンスケールの取り決め
# --------------------------------------------------------------------------- #
# パイプライン全体の約束: **1 Blender 単位 = 1 mm**。
# プリンタの造形範囲も、HollowKit の壁厚・軸径も、SculptBase の接合部判定も
# すべて mm で考える。ジオメトリの数値は変えず、シーンの表示単位だけを
# mm に合わせる(scale_length = 0.001)。
MM_SCALE_LENGTH = 0.001
# HollowKit のマーカーコレクション接頭辞(マーカーを次フェーズへ運ぶため)
HK_COLL_PREFIXES = ("HK_穴_", "HK_軸_")
HK_PARENT_COLL = "HollowKit"


def scene_is_mm(scene):
    """シーンが「1単位 = 1mm」表示になっているか。"""
    us = scene.unit_settings
    if us.system == 'NONE':
        return True                      # 単位なしは 1単位=1mm とみなす
    # scale_length は単精度で保持されるので、緩めの許容差で比べる。
    return abs(us.scale_length - MM_SCALE_LENGTH) < 1e-7


def set_scene_mm(scene):
    """シーンの表示単位を mm に合わせる(ジオメトリは動かさない)。"""
    us = scene.unit_settings
    us.system = 'METRIC'
    us.scale_length = MM_SCALE_LENGTH
    try:
        us.length_unit = 'MILLIMETERS'
    except TypeError:
        pass


def sanitize_kit(kit):
    """キット名から拡張子の残骸・前後の区切り文字を取り除く。

    ファイル名の手入力ミス(``hoge.blend`` のような値)がそのまま
    次ファイル名に入り込んで ``split_.blend_...`` を作らないようにする。
    無効なら空文字を返す(呼び出し側でエラーにする)。
    """
    kit = (kit or "").strip()
    while kit.lower().endswith(".blend"):
        kit = kit[:-6]
    kit = re.sub(r'[<>:"/\\|?*]', "", kit)
    return kit.strip(" ._-")


def parse_blend_name(filepath):
    """現在のファイル名から ``(phase, kit)`` を推定する。

    ``mdl_eula_260709_03.blend`` -> ``('mdl', 'eula')``。
    規則に合わない場合は ``(None, <拡張子なしファイル名>)``。
    """
    stem = os.path.splitext(os.path.basename(filepath))[0]
    m = re.match(r"^({})_(.+?)_(\d{{6}})(?:_\d+)?$".format(
        "|".join(PHASE_PREFIXES)), stem)
    if m:
        return m.group(1), sanitize_kit(m.group(2))
    m = re.match(r"^({})_(.+)$".format("|".join(PHASE_PREFIXES)), stem)
    if m:
        return m.group(1), sanitize_kit(m.group(2))
    return None, sanitize_kit(stem)


def build_filepath(directory, phase, kit, date_str=None):
    """空いている連番で ``<phase>_<kit>_<YYMMDD>_<NN>.blend`` のパスを返す。"""
    if date_str is None:
        date_str = datetime.now().strftime("%y%m%d")
    for nn in range(1, 100):
        name = "{}_{}_{}_{:02d}.blend".format(phase, kit, date_str, nn)
        path = os.path.join(directory, name)
        if not os.path.exists(path):
            return path
    raise RuntimeError("空いている連番が見つかりません: " + directory)


def _clean_copy(obj):
    """親子・コンストレイントを外しトランスフォームを確定したコピーを返す。

    メッシュデータは元とブロック共有(コピーしない)。モディファイアは
    コピーに引き継がれる(EvenMesh 側が移行先で適用する)。
    """
    dup = obj.copy()
    dup.parent = None
    for con in list(dup.constraints):
        dup.constraints.remove(con)
    dup.matrix_world = obj.matrix_world.copy()
    dup.animation_data_clear()
    return dup


def export_phase_file(context, objects, filepath, evenmesh_preset=False,
                      carry_markers=True):
    """``objects`` のクリーンコピーだけを含む新規 .blend を書き出す。

    現在のファイルは変更しない(オブジェクト名は書き出しの間だけ一時的に
    退避し、終了時に必ず復元する)。``evenmesh_preset`` が真で EvenMesh が
    インストールされていれば、書き出し先シーンに「分割前の密度統一」
    プリセット値を設定しておく。書き出しは常に圧縮(zstd)。
    """
    src_scene = context.scene
    temp = bpy.data.scenes.new("Scene_" + os.path.splitext(
        os.path.basename(filepath))[0])
    # 単位設定は印刷スケールの前提なので必ず引き継ぐ。
    try:
        temp.unit_settings.system = src_scene.unit_settings.system
        temp.unit_settings.scale_length = src_scene.unit_settings.scale_length
        temp.unit_settings.length_unit = src_scene.unit_settings.length_unit
    except (AttributeError, TypeError):
        pass
    if evenmesh_preset and hasattr(temp, "evenmesh"):
        for name, value in EVENMESH_PRESPLIT.items():
            # インストール済み EvenMesh が古くてプロパティが無い場合は飛ばす
            if hasattr(temp.evenmesh, name):
                setattr(temp.evenmesh, name, value)

    renamed = []        # (original, dup, name)
    renamed_colls = []  # (collection, 元の名前)
    extra_objects = []
    extra_colls = []
    try:
        for obj in objects:
            dup = _clean_copy(obj)
            name = obj.name
            obj.name = name + ".pporig"
            dup.name = name
            renamed.append((obj, dup, name))
            temp.collection.objects.link(dup)
            # HollowKit のマーカー(軸打ち・排出穴)も一緒に運ぶ。運ばないと
            # print ファイルを作り直すたびに全マーカーを置き直しになる。
            if carry_markers:
                e_objs, e_colls = _copy_hk_markers(temp, dup, name,
                                                   renamed_colls)
                extra_objects += e_objs
                extra_colls += e_colls
        bpy.data.libraries.write(filepath, {temp}, compress=True,
                                 fake_user=False)
    finally:
        for ob in extra_objects:
            try:
                bpy.data.objects.remove(ob, do_unlink=True)
            except ReferenceError:
                pass
        for coll in extra_colls:
            try:
                bpy.data.collections.remove(coll)
            except ReferenceError:
                pass
        for coll, orig_name in renamed_colls:
            try:
                coll.name = orig_name
            except ReferenceError:
                pass
        for obj, dup, name in renamed:
            try:
                bpy.data.objects.remove(dup, do_unlink=True)
            except ReferenceError:
                pass
            obj.name = name
        bpy.data.scenes.remove(temp)
    return filepath


def _copy_hk_markers(temp_scene, dup, part_name, renamed_colls):
    """HollowKit のマーカーを複製し、``dup`` に親付けして同梱する。

    マーカーは ``HK_穴_<オブジェクト名>`` / ``HK_軸_<オブジェクト名>`` という
    コレクションに入っている。移行先でも**同じ名前**でないと HollowKit が
    見つけられないので、元のコレクションを一時的に退避名へ改名してから、
    正式名の複製を作る(オブジェクト名の扱いと同じ二段構え)。

    戻り値は後始末用の ``(作ったオブジェクト, 作ったコレクション)``。
    ``renamed_colls`` には ``(コレクション, 元の名前)`` を積んでいく。
    """
    made_objs, made_colls = [], []
    parent = None
    for prefix in HK_COLL_PREFIXES:
        coll = bpy.data.collections.get(prefix + part_name)
        if coll is None or not coll.objects:
            continue
        markers = list(coll.objects)
        # 元を退避名にして、正式名を空ける。
        coll.name = prefix + part_name + ".pporig"
        renamed_colls.append((coll, prefix + part_name))

        if parent is None:
            existing = bpy.data.collections.get(HK_PARENT_COLL)
            if existing is not None:
                existing.name = HK_PARENT_COLL + ".pporig"
                renamed_colls.append((existing, HK_PARENT_COLL))
            parent = bpy.data.collections.new(HK_PARENT_COLL)
            temp_scene.collection.children.link(parent)
            made_colls.append(parent)

        new_coll = bpy.data.collections.new(prefix + part_name)
        parent.children.link(new_coll)
        made_colls.append(new_coll)
        for marker in markers:
            m = marker.copy()
            if marker.data is not None:
                m.data = marker.data.copy()
            new_coll.objects.link(m)
            m.parent = dup
            m.matrix_parent_inverse = marker.matrix_parent_inverse.copy()
            m.matrix_basis = marker.matrix_basis.copy()
            made_objs.append(m)
    return made_objs, made_colls


def write_parts_csv(objects, blend_filepath, kit):
    """パーツ一覧 CSV をキットごとに1つだけ出力してパスを返す。

    書き出し先フォルダの ``<キット名>_parts.csv`` を毎回上書きする
    (ファイルごとに CSV を増やさない)。フォーマットは既存の
    export_objects_csv.py と同じ(部品名,個数 / 合計 / 全オブジェクト名)。
    Excel 対応のため utf-8-sig。
    """
    csv_path = os.path.join(os.path.dirname(blend_filepath),
                            "{}_parts.csv".format(kit))

    def base_name(name):
        return re.sub(r"\.\d{3,}$", "", name)

    counts = Counter(base_name(o.name) for o in objects)
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["部品名", "個数"])
        for name, count in sorted(counts.items()):
            writer.writerow([name, count])
        writer.writerow([])
        writer.writerow(["合計", sum(counts.values())])
        writer.writerow([])
        writer.writerow(["--- 全オブジェクト名 ---"])
        for obj in sorted(objects, key=lambda o: o.name):
            writer.writerow([obj.name])
    return csv_path


# --------------------------------------------------------------------------- #
# 量産レイアウト(複製 → プレートへ配置 → プレート単位で書き出し)
# --------------------------------------------------------------------------- #
PLATE_PREFIX = "plate"
PLATE_PROP = "phaseporter_plate"


def world_bbox(obj):
    """ワールド空間のバウンディングボックス ``(min, max)`` を返す。"""
    mw = obj.matrix_world
    corners = [mw @ Vector(c) for c in obj.bound_box]
    mins = Vector((min(c[i] for c in corners) for i in range(3)))
    maxs = Vector((max(c[i] for c in corners) for i in range(3)))
    return mins, maxs


def check_printable(context, objects):
    """出力前チェック: 各オブジェクトが水密(境界0・非多様体0)かを調べる。

    HollowKit の中空化・穴あけブーリアンを通った結果はここまでノーチェック
    だったため、非水密のままスライサへ渡って印刷してから気づく事故があり得た。
    モディファイア適用後(＝実際に書き出される形)を見る。
    ``[(名前, 境界エッジ数, 非多様体エッジ数), ...]`` の問題リストを返す。
    """
    import bmesh

    depsgraph = context.evaluated_depsgraph_get()
    problems = []
    for obj in objects:
        if obj.type != 'MESH':
            continue
        eval_obj = obj.evaluated_get(depsgraph)
        mesh = eval_obj.to_mesh()
        bm = bmesh.new()
        bm.from_mesh(mesh)
        boundary = sum(1 for e in bm.edges if e.is_boundary)
        nonman = sum(1 for e in bm.edges if not e.is_manifold)
        bm.free()
        eval_obj.to_mesh_clear()
        if boundary or nonman:
            problems.append((obj.name, boundary, nonman))
    return problems


def live_modifier_parts(objects):
    """ジオメトリノードのモディファイアが生きているオブジェクト名を返す。

    量産レイアウトは複製ごとにモディファイアスタックを持つので、HollowKit を
    確定しないまま何十個も複製すると、書き出し時にその数だけジオメトリノード
    評価が走って極端に重くなる。先に確定させるべきものを知らせる。
    """
    return [o.name for o in objects
            if any(m.type == 'NODES' and m.show_viewport
                   for m in o.modifiers)]


def shelf_pack(items, width, depth, gap, edge):
    """XY フットプリントを棚(シェルフ)方式でプレートへ詰める。

    ``items`` は ``(キー, 幅, 奥行)`` の列。戻り値は
    ``(プレートのリスト, 入らなかったキーのリスト)``。各プレートは
    ``[(キー, x, y), ...]`` で、x/y はプレート原点からの配置位置。

    レジンではパーツを傾けて置くので、フットプリントは**現在の回転を
    含めた**寸法で測る(傾きは Blender 側で決める前提)。``gap`` には
    スライサが後から付けるサポートのぶんの余白も見込む。
    """
    usable_w = width - edge * 2
    usable_d = depth - edge * 2
    plates, oversize = [], []
    current = []
    x = y = 0.0
    row_depth = 0.0
    # 奥行の大きい順に詰めると棚の無駄が減る。
    for key, w, d in sorted(items, key=lambda i: -i[2]):
        if w > usable_w or d > usable_d:
            oversize.append(key)
            continue
        if x + w > usable_w:                 # 次の棚へ
            x = 0.0
            y += row_depth + gap
            row_depth = 0.0
        if y + d > usable_d:                 # 次のプレートへ
            plates.append(current)
            current = []
            x = y = 0.0
            row_depth = 0.0
        current.append((key, edge + x, edge + y))
        x += w + gap
        row_depth = max(row_depth, d)
    if current:
        plates.append(current)
    return plates, oversize


def _height_groups(items, heights, tolerance):
    """高さの近いものどうしをまとめた ``items`` のグループ列を返す。

    背の低い順に見て、グループ内の最小高さから ``tolerance`` を超えたら
    新しいグループにする。
    """
    if tolerance <= 0.0:
        return [items]
    ordered = sorted(items, key=lambda it: heights[it[0][0].name])
    groups, current, base = [], [], None
    for it in ordered:
        h = heights[it[0][0].name]
        if base is None:
            base = h
        elif h - base > tolerance:
            groups.append(current)
            current, base = [], h
        current.append(it)
    if current:
        groups.append(current)
    return groups


def _plate_collection(context, index):
    name = "{}{:02d}".format(PLATE_PREFIX, index)
    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
        context.scene.collection.children.link(coll)
    return coll


def clear_plates(context):
    """既存の plateNN コレクションと、その中の複製オブジェクトを消す。"""
    n = 0
    for coll in list(bpy.data.collections):
        if not coll.name.startswith(PLATE_PREFIX):
            continue
        for obj in list(coll.objects):
            if obj.get(PLATE_PROP):
                mesh = obj.data
                bpy.data.objects.remove(obj, do_unlink=True)
                if mesh is not None and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)
                n += 1
        try:
            bpy.data.collections.remove(coll)
        except Exception:
            pass
    return n


def layout_plates(context, parts, settings):
    """``parts`` を必要数だけ複製し、プレートへ並べる。

    複製はメッシュを共有するリンク複製なので、個数を増やしてもメモリは
    ほぼ増えない。戻り値は ``(プレート数, 配置した個数, 入らなかった名前)``。
    """
    if not parts:
        raise RuntimeError("レイアウトするパーツを選択してください。")
    copies = max(1, settings.copies)
    clear_plates(context)

    # (元オブジェクト, 何個目) をキーにフットプリントを作る。バウンディング
    # ボックスは現在の回転込みで測る(傾きは Blender 側で決める前提)。
    items = []
    boxes = {}
    heights = {}
    for obj in parts:
        mn, mx = world_bbox(obj)
        boxes[obj.name] = mn
        heights[obj.name] = mx.z - mn.z
        w, d = mx.x - mn.x, mx.y - mn.y
        for i in range(copies):
            items.append(((obj, i), w, d))

    if settings.group_by_height:
        # 造形時間はプレート上の一番背の高いパーツで決まる。高さの近いもの
        # どうしをまとめると、低いパーツが高いパーツに付き合わされずに済む。
        groups = _height_groups(items, heights, settings.height_tolerance)
    else:
        groups = [items]

    plates, oversize = [], []
    for group in groups:
        p, o = shelf_pack(group, settings.plate_x, settings.plate_y,
                          settings.plate_gap, settings.plate_edge)
        plates += p
        oversize += o

    placed = 0
    for pi, plate in enumerate(plates, start=1):
        coll = _plate_collection(context, pi)
        for (src, _i), px, py in plate:
            dup = src.copy()          # メッシュは共有(リンク複製)
            dup[PLATE_PROP] = pi
            coll.objects.link(dup)
            # フットプリントの最小角をプレート上の (px, py) に合わせ、
            # 底面をプレート面(Z=0)に接地させる。位置は元オブジェクトの
            # バウンディングボックスから求める(複製直後の matrix_world は
            # まだ再計算されていないため、複製自身からは測らない)。
            mn = boxes[src.name]
            dup.location = src.location + Vector(
                (px - mn.x, py - mn.y, -mn.z))
            placed += 1
    # 以降 matrix_world を読む処理のために、ここで反映させておく。
    context.view_layer.update()
    return len(plates), placed, [o.name for (o, _i) in oversize]


def threemf_available():
    """3MF 書き出しオペレーターが登録されているか。

    ``bpy.ops`` は属性アクセスが遅延解決なので ``hasattr`` では判定できない
    (未登録でも True が返り、呼び出し時に初めて失敗する)。登録済みクラスの
    有無で見る。
    """
    return hasattr(bpy.types, "EXPORT_MESH_OT_threemf")


def export_plates(context, directory, kit, global_scale=1.0):
    """plateNN コレクションを 1 枚ずつ 3MF に書き出す。

    3MF は 1 ファイルに複数オブジェクトを配置ごと保持できるので、
    スライサ側で個々のパーツを動かせる(STL は全部が 1 つの塊に融合する)。
    戻り値は書き出したファイルパスのリスト。
    """
    colls = sorted((c for c in bpy.data.collections
                    if c.name.startswith(PLATE_PREFIX) and c.objects),
                   key=lambda c: c.name)
    if not colls:
        raise RuntimeError("plateNN コレクションがありません。"
                           "先に「量産レイアウト」を実行してください。")
    if not threemf_available():
        raise RuntimeError("3MF アドオン(ThreeMF_io)が有効になっていません。"
                           "Preferences > Get Extensions で有効にしてください。")
    written = []
    saved = [o for o in context.selected_objects]
    for coll in colls:
        for obj in context.selected_objects:
            obj.select_set(False)
        for obj in coll.objects:
            obj.select_set(True)
        context.view_layer.objects.active = coll.objects[0]
        path = os.path.join(directory, "{}_{}.3mf".format(kit, coll.name))
        bpy.ops.export_mesh.threemf(filepath=path, use_selection=True,
                                    global_scale=global_scale,
                                    use_mesh_modifiers=True)
        written.append(path)
    for obj in context.selected_objects:
        obj.select_set(False)
    for obj in saved:
        try:
            obj.select_set(True)
        except ReferenceError:
            pass
    return written


def write_plate_csv(directory, kit):
    """プレートごとの明細 CSV を書き出してパスを返す。"""
    csv_path = os.path.join(directory, "{}_plates.csv".format(kit))

    def base_name(name):
        return re.sub(r"\.\d{3,}$", "", name)

    colls = sorted((c for c in bpy.data.collections
                    if c.name.startswith(PLATE_PREFIX) and c.objects),
                   key=lambda c: c.name)
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["プレート", "部品名", "個数"])
        grand = 0
        for coll in colls:
            counts = Counter(base_name(o.name) for o in coll.objects)
            for name, n in sorted(counts.items()):
                writer.writerow([coll.name, name, n])
            writer.writerow([coll.name, "小計", sum(counts.values())])
            grand += sum(counts.values())
            writer.writerow([])
        writer.writerow(["合計", "", grand])
    return csv_path
