"""N パネル UI (View3D > Sidebar > PhasePorter)。"""

import os

import bpy
from bpy.types import Panel

from . import core, operators


class PHASEPORTER_PT_main(Panel):
    bl_idname = "PHASEPORTER_PT_main"
    bl_label = "PhasePorter"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PhasePorter"

    def draw(self, context):
        st = context.scene.phaseporter
        layout = self.layout

        col = layout.column(align=True)
        col.prop(st, "target_phase")
        col.prop(st, "kit_name")

        box = layout.box()
        box.prop(st, "write_csv")
        sub = box.row()
        sub.enabled = st.target_phase == 'split'
        sub.prop(st, "evenmesh_preset")

        n_sel = sum(1 for o in context.selected_objects if o.type == 'MESH')
        target = operators._target_path(context)
        if target is None:
            layout.label(text="ファイル未保存 — 先に保存してください",
                         icon='ERROR')
        else:
            layout.label(text="→ " + os.path.basename(target),
                         icon='FILE_BLEND')
        layout.label(text="選択中のメッシュ: {}".format(n_sel))

        col = layout.column(align=True)
        op = col.operator("phaseporter.export",
                          text="書き出し", icon='EXPORT')
        op.open_after = False
        op = col.operator("phaseporter.export",
                          text="書き出して開く", icon='FILE_TICK')
        op.open_after = True

        # ---- 量産レイアウト(print フェーズ) ----
        box = layout.box()
        box.label(text="量産レイアウト", icon='MOD_ARRAY')
        if not core.scene_is_mm(context.scene):
            col = box.column(align=True)
            col.label(text="シーンが mm 表示ではありません", icon='ERROR')
            col.operator("phaseporter.set_scene_mm", icon='SETTINGS')
        box.prop(st, "copies")
        row = box.row(align=True)
        row.prop(st, "plate_x")
        row.prop(st, "plate_y")
        box.prop(st, "plate_gap")
        box.prop(st, "plate_edge")
        box.prop(st, "group_by_height")
        row = box.row()
        row.enabled = st.group_by_height
        row.prop(st, "height_tolerance")
        if n_sel:
            box.label(text="{} パーツ × {} セット = {} 個".format(
                n_sel, st.copies, n_sel * st.copies), icon='MESH_DATA')
        plates = sorted(c.name for c in bpy.data.collections
                        if c.name.startswith(core.PLATE_PREFIX) and c.objects)
        if plates:
            box.label(text="プレート {} 枚".format(len(plates)),
                      icon='CHECKMARK')
        col = box.column(align=True)
        col.operator("phaseporter.layout_plates", icon='MOD_ARRAY')
        col.prop(st, "export_scale")
        col.prop(st, "check_before_export")
        col.operator("phaseporter.export_plates", icon='EXPORT')
        col.operator("phaseporter.clear_plates", icon='X')


CLASSES = (
    PHASEPORTER_PT_main,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
