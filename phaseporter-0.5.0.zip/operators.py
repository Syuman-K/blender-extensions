"""PhasePorter のオペレーターと設定。"""

import os

import bpy
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import Operator, PropertyGroup

from . import core


class PhasePorterSettings(PropertyGroup):
    target_phase: EnumProperty(
        name="移行先フェーズ",
        items=[
            ('split', "split(分割)",
             "密度統一と分割作業用のファイルへ移行する"),
            ('sculpt', "sculpt(詳細造形)",
             "分割後のリトポ・マルチレゾ詳細造形用のファイルへ移行する"),
            ('print', "print(出力)",
             "中空化・サポート・STL 書き出し用のファイルへ移行する"),
        ],
        default='split',
    )
    kit_name: StringProperty(
        name="キット名",
        default="",
        description="空のままなら現在のファイル名から自動推定する"
                    "(例: mdl_eula_260709_03.blend → eula)")
    evenmesh_preset: BoolProperty(
        name="EvenMesh プリセットを設定",
        default=True,
        description="書き出し先シーンに EvenMesh「分割前の密度統一」の設定値を"
                    "入れておく(EvenMesh 未インストール時は何もしない)。"
                    "split 移行時のみ有効")
    # --- 量産レイアウト(print フェーズ用) ---
    copies: IntProperty(
        name="セット数",
        default=1, min=1, soft_max=50,
        description="何セットぶん作るか。各パーツをこの数だけリンク複製して"
                    "プレートへ並べる(メッシュは共有なのでメモリは増えない)")
    plate_x: FloatProperty(
        name="プレート幅 X",
        default=153.36, min=1.0, soft_max=500.0, precision=2, unit='LENGTH',
        description="造形プレートの X 寸法(ELEGOO Mars 4 Ultra: 153.36)")
    plate_y: FloatProperty(
        name="プレート奥行 Y",
        default=77.76, min=1.0, soft_max=500.0, precision=2, unit='LENGTH',
        description="造形プレートの Y 寸法(ELEGOO Mars 4 Ultra: 77.76)")
    plate_gap: FloatProperty(
        name="パーツ間クリアランス",
        default=4.0, min=0.0, soft_max=30.0, precision=2, unit='LENGTH',
        description="パーツ同士の余白。サポートはスライサ側で後から付くので、"
                    "その占有ぶんも見込んで広めに取る(実測で調整)")
    plate_edge: FloatProperty(
        name="プレート端の余白",
        default=3.0, min=0.0, soft_max=30.0, precision=2, unit='LENGTH',
        description="プレート外周に空ける余白")
    group_by_height: BoolProperty(
        name="高さでグループ化", default=True,
        description="高さの近いパーツどうしを同じプレートにまとめる。"
                    "造形時間はプレート上の一番背の高いパーツで決まるので、"
                    "背の低いパーツが高いパーツに付き合わされるのを防ぐ")
    height_tolerance: FloatProperty(
        name="高さの許容差",
        default=15.0, min=0.0, soft_max=200.0, precision=2, unit='LENGTH',
        description="同じプレートに載せる高さの幅。小さくするとプレート枚数が"
                    "増える代わりに1枚あたりの造形時間が短くなる")
    check_before_export: BoolProperty(
        name="書き出し前に水密チェック", default=True,
        description="書き出す形(モディファイア適用後)が水密かを調べ、"
                    "境界エッジや非多様体エッジがあれば中止する。"
                    "非水密のままスライサへ渡すのを防ぐ")
    export_scale: FloatProperty(
        name="書き出しスケール",
        default=1.0, min=1e-6, soft_max=1000.0, precision=4,
        description="3MF 書き出し時の倍率。シーンの単位が既に mm なら 1.0")

    write_csv: BoolProperty(
        name="パーツ一覧 CSV も出力",
        default=True,
        description="書き出し先と同じフォルダの <キット名>_parts.csv を"
                    "上書き更新する(ファイルごとに増えない)")


def _resolve_kit(context):
    st = context.scene.phaseporter
    kit = core.sanitize_kit(st.kit_name)
    if kit:
        return kit
    _phase, kit = core.parse_blend_name(bpy.data.filepath or "untitled")
    return kit


def _target_path(context):
    st = context.scene.phaseporter
    directory = os.path.dirname(bpy.data.filepath) if bpy.data.filepath else ""
    if not directory:
        return None
    return core.build_filepath(directory, st.target_phase,
                               _resolve_kit(context))


class PHASEPORTER_OT_export(Operator):
    bl_idname = "phaseporter.export"
    bl_label = "フェーズ移行ファイルを書き出し"
    bl_description = ("選択中のメッシュだけを、命名規則どおりの新規 .blend に"
                     "圧縮付きで書き出す。親子・コンストレイントは外され、"
                     "現在のファイルは変更されない")
    bl_options = {'REGISTER'}

    open_after: BoolProperty(
        name="書き出して開く", default=False,
        description="書き出した .blend をそのまま開く(現在のファイルは"
                    "保存済みである必要がある)")

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        st = context.scene.phaseporter
        objects = [o for o in context.selected_objects if o.type == 'MESH']
        if not bpy.data.filepath:
            self.report({'ERROR'},
                        "現在のファイルを一度保存してから実行してください"
                        "(書き出し先フォルダと命名の基準になります)")
            return {'CANCELLED'}
        if not _resolve_kit(context):
            self.report({'ERROR'},
                        "キット名を決められません。パネルの「キット名」に"
                        "入力してください")
            return {'CANCELLED'}
        if self.open_after and bpy.data.is_dirty:
            self.report({'ERROR'},
                        "未保存の変更があります。保存してから「書き出して開く」を"
                        "実行してください")
            return {'CANCELLED'}

        target = _target_path(context)
        try:
            core.export_phase_file(
                context, objects, target,
                evenmesh_preset=(st.evenmesh_preset
                                 and st.target_phase == 'split'))
        except Exception as exc:  # noqa: BLE001 - surface any failure
            self.report({'ERROR'}, "書き出し失敗: {}".format(exc))
            return {'CANCELLED'}

        msgs = ["{} オブジェクト → {}".format(
            len(objects), os.path.basename(target))]
        if st.write_csv:
            try:
                csv_path = core.write_parts_csv(objects, target,
                                                _resolve_kit(context))
                msgs.append(os.path.basename(csv_path))
            except Exception as exc:  # noqa: BLE001
                self.report({'WARNING'}, "CSV 出力失敗: {}".format(exc))

        if self.open_after:
            bpy.ops.wm.open_mainfile(filepath=target)
        else:
            self.report({'INFO'}, "PhasePorter: " + " / ".join(msgs))
        return {'FINISHED'}


class PHASEPORTER_OT_set_mm(Operator):
    bl_idname = "phaseporter.set_scene_mm"
    bl_label = "シーン単位を mm に設定"
    bl_description = ("シーンの表示単位を「1 Blender 単位 = 1mm」に合わせる"
                     "(ジオメトリは動かさない)。パイプライン全体がこの前提で、"
                     "プリンタの造形範囲も各アドオンの既定値も mm で書かれている")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        core.set_scene_mm(context.scene)
        self.report({'INFO'}, "PhasePorter: シーン単位を mm にしました")
        return {'FINISHED'}


class PHASEPORTER_OT_layout_plates(Operator):
    bl_idname = "phaseporter.layout_plates"
    bl_label = "量産レイアウト"
    bl_description = ("選択パーツを必要セット数だけ複製し、造形プレートへ"
                     "並べて plate01, plate02... のコレクションを作る。"
                     "パーツの傾きは現在の回転をそのまま使う")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        st = context.scene.phaseporter
        parts = [o for o in context.selected_objects
                 if o.type == 'MESH' and not o.get(core.PLATE_PROP)]
        if not core.scene_is_mm(context.scene):
            self.report({'WARNING'},
                        "シーンが mm 表示になっていません。プレート寸法は "
                        "1単位=1mm 前提なので、「シーン単位を mm に設定」を"
                        "先に実行してください")
        live = core.live_modifier_parts(parts)
        if live:
            self.report({'WARNING'},
                        "{} 個にジオメトリノードが生きています({} など)。"
                        "複製ごとに評価が走って書き出しが重くなるので、"
                        "HollowKit を先に確定してください".format(
                            len(live), live[0]))
        try:
            n_plates, placed, oversize = core.layout_plates(context, parts, st)
        except RuntimeError as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        except Exception as exc:  # noqa: BLE001 - surface any failure
            self.report({'ERROR'}, "レイアウト失敗: {}".format(exc))
            return {'CANCELLED'}
        if oversize:
            self.report({'WARNING'},
                        "プレートに収まらないパーツが {} 個あります({} など)。"
                        "傾きを見直すか、分割し直してください".format(
                            len(oversize), oversize[0]))
        self.report({'INFO'},
                    "PhasePorter: {} 個を {} 枚のプレートに配置しました".format(
                        placed, n_plates))
        return {'FINISHED'}


class PHASEPORTER_OT_export_plates(Operator):
    bl_idname = "phaseporter.export_plates"
    bl_label = "プレートを3MFで書き出し"
    bl_description = ("plateNN コレクションを 1 枚ずつ 3MF に書き出す。"
                     "3MF は配置とオブジェクトの区別を保持するので、"
                     "スライサ側で個々のパーツを動かせる")
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return any(c.name.startswith(core.PLATE_PREFIX) and c.objects
                   for c in bpy.data.collections)

    def execute(self, context):
        st = context.scene.phaseporter
        if not bpy.data.filepath:
            self.report({'ERROR'},
                        "現在のファイルを一度保存してから実行してください")
            return {'CANCELLED'}
        kit = _resolve_kit(context)
        if not kit:
            self.report({'ERROR'}, "キット名を決められません")
            return {'CANCELLED'}
        directory = os.path.dirname(bpy.data.filepath)
        if st.check_before_export:
            targets = [o for c in bpy.data.collections
                       if c.name.startswith(core.PLATE_PREFIX)
                       for o in c.objects]
            problems = core.check_printable(context, targets)
            if problems:
                for name, boundary, nonman in problems[:3]:
                    self.report({'ERROR'},
                                "{}: 境界エッジ {} / 非多様体 {}".format(
                                    name, boundary, nonman))
                self.report({'ERROR'},
                            "水密でないパーツが {} 個あります。修正するか、"
                            "「書き出し前に水密チェック」を切って続行して"
                            "ください".format(len(problems)))
                return {'CANCELLED'}
        try:
            written = core.export_plates(context, directory, kit,
                                         st.export_scale)
        except RuntimeError as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        except Exception as exc:  # noqa: BLE001 - surface any failure
            self.report({'ERROR'}, "3MF 書き出し失敗: {}".format(exc))
            return {'CANCELLED'}
        msg = "{} 枚を書き出しました".format(len(written))
        if st.write_csv:
            try:
                path = core.write_plate_csv(directory, kit)
                msg += " / " + os.path.basename(path)
            except Exception as exc:  # noqa: BLE001
                self.report({'WARNING'}, "CSV 出力失敗: {}".format(exc))
        self.report({'INFO'}, "PhasePorter: " + msg)
        return {'FINISHED'}


class PHASEPORTER_OT_clear_plates(Operator):
    bl_idname = "phaseporter.clear_plates"
    bl_label = "プレートを消す"
    bl_description = "plateNN コレクションと、その中の複製パーツを削除する"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(c.name.startswith(core.PLATE_PREFIX)
                   for c in bpy.data.collections)

    def execute(self, context):
        n = core.clear_plates(context)
        self.report({'INFO'}, "PhasePorter: 複製 {} 個を削除しました".format(n))
        return {'FINISHED'}


CLASSES = (
    PhasePorterSettings,
    PHASEPORTER_OT_set_mm,
    PHASEPORTER_OT_export,
    PHASEPORTER_OT_layout_plates,
    PHASEPORTER_OT_export_plates,
    PHASEPORTER_OT_clear_plates,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.phaseporter = PointerProperty(type=PhasePorterSettings)


def unregister():
    del bpy.types.Scene.phaseporter
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
