"""
PartSplit  (Blender Add-on)
===================================
フィギュア原型(単一高ポリメッシュ)を、指定した「切断面オブジェクト」で
分割し、ダボ(オス凸/メス凹)を自動生成するアドオン。
3Dプリント出力 + シリコン型複製 + 塗装を想定したガイド付き分割ツール。

------------------------------------------------------------
インストール
------------------------------------------------------------
  Edit > Preferences > Add-ons > Install...  からこの .py を選択し、
  "PartSplit" を有効化。
  3Dビューの右サイドバー(N) に "PartSplit" タブが追加されます。

------------------------------------------------------------
切断面の指定方法（2種類）
------------------------------------------------------------
名前を接頭辞(既定 "CUT_")で始めたオブジェクトが「切断面」になります。

(A) Empty (Plain Axes) … 平面でまっすぐ切る
      Empty の +Z 軸 = 切断面の法線。+Z 側が凸ダボ(オス)側。

(B) Mesh (面を持つ曲面ポリゴン) … 曲面で切る  ★今回追加
      メッシュの「面の平均法線」の向き(+N)側が凸ダボ(オス)側。
      ※その曲面は対象メッシュのシルエットを完全に貫通(はみ出す)させること。
        中途半端だと2つに分離できません。
      ※開いた1枚のサーフェス(穴の無い縁取り)を想定しています。

ダボ位置(任意):
      切断面オブジェクトの「子」として Empty を置くと、その位置がダボに。
      子が無ければ切断面の中心に1個自動配置。

------------------------------------------------------------
型抜き・塗装のヒント
------------------------------------------------------------
  シリコン型: 分割面は抜き方向にアンダーカットを作らない位置に。
  塗装: 色境界(肌/服, 髪/顔)で分けるとマスキングが楽。
  細い突起(髪先・指・武器)は別パーツ化推奨。
"""

bl_info = {
    "name": "PartSplit",
    "author": "Generated for st-kai",
    "version": (2, 7, 0),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar (N) > PartSplit",
    "description": "原型メッシュを切断面オブジェクト(平面/曲面)で分割しダボを自動生成",
    "category": "Mesh",
}

import bpy
import bmesh
import math
import gpu
from gpu_extras.batch import batch_for_shader
from bpy_extras import view3d_utils
from bpy.props import (FloatProperty, BoolProperty, StringProperty,
                       EnumProperty)
from bpy.types import PropertyGroup, Operator, Panel
from mathutils import Vector, Matrix


# ============================================================
# 幾何ユーティリティ
# ============================================================

def _unit_mm_per_bu(props):
    """Blender 1単位が何ミリメートルか。auto時はシーンの単位設定から自動検出。"""
    if props.auto_unit:
        us = bpy.context.scene.unit_settings
        # scale_length は常にメートル基準。1単位 = scale_length メートル = *1000 mm
        if us.system in ('METRIC', 'IMPERIAL'):
            return max(1e-9, us.scale_length * 1000.0)
    return props.unit_scale


def _mm(props, v):
    """ミリメートル指定値を、現在のシーン単位(Blender単位)へ換算する。"""
    return v / _unit_mm_per_bu(props)


def world_bbox(obj):
    coords = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    mn = Vector((min(c.x for c in coords), min(c.y for c in coords),
                 min(c.z for c in coords)))
    mx = Vector((max(c.x for c in coords), max(c.y for c in coords),
                 max(c.z for c in coords)))
    return mn, mx


def obj_diagonal(obj):
    mn, mx = world_bbox(obj)
    return (mx - mn).length, mn, mx


def duplicate_obj(obj, name):
    new = obj.copy()
    new.data = obj.data.copy()
    new.name = name
    bpy.context.collection.objects.link(new)
    return new


def is_empty_mesh(obj):
    return len(obj.data.vertices) == 0


def _apply_modifiers(obj):
    """obj の全モディファイアを評価メッシュへ焼き込む。bpy.ops.modifier_apply の
    オペレータ/undo/コンテキスト依存を避け、直接データAPIで高速に適用する。"""
    dg = bpy.context.evaluated_depsgraph_get()
    new_me = bpy.data.meshes.new_from_object(obj.evaluated_get(dg))
    old = obj.data
    obj.data = new_me
    obj.modifiers.clear()
    if old.users == 0:
        bpy.data.meshes.remove(old)


def apply_boolean(part, cutter, op, solver):
    mod = part.modifiers.new(name="bool", type='BOOLEAN')
    mod.operation = op
    mod.object = cutter
    mod.solver = solver
    _apply_modifiers(part)


def join_objects(main, others):
    """others を main に統合(ブーリアン無し・高速)。others は消える。
    bmesh で main のローカル空間へ取り込む(join オペレータ非依存)。"""
    others = [o for o in others if o is not None]
    if not others:
        return main
    bm = bmesh.new()
    bm.from_mesh(main.data)
    mwi = main.matrix_world.inverted()
    for o in others:
        mat = mwi @ o.matrix_world
        vmap = []
        for v in o.data.vertices:
            vmap.append(bm.verts.new(mat @ v.co))
        bm.verts.ensure_lookup_table()
        for poly in o.data.polygons:
            try:
                bm.faces.new([vmap[i] for i in poly.vertices])
            except ValueError:
                pass                       # 重複面はスキップ
    bm.to_mesh(main.data)
    bm.free()
    main.data.update()
    for o in others:
        bpy.data.objects.remove(o, do_unlink=True)
    return main


def _watertight_fill(bm, seed_edges):
    """切断断面を確実に閉じる。複数ループ/非平面でも残った穴を潰す。
    1) seed_edges を edgeloop_fill -> 2) 残境界を triangle_fill ->
    3) なお残る穴を holes_fill -> 4) 新規nグンを三角化して整える。"""
    new_faces = []

    def _collect(res):
        new_faces.extend(f for f in res.get("geom", [])
                         if isinstance(f, bmesh.types.BMFace))

    if seed_edges:
        try:
            _collect(bmesh.ops.edgeloop_fill(bm, edges=seed_edges))
        except Exception:
            pass
    # まだ開いている境界エッジを総当りで閉じる
    for _ in range(3):
        boundary = [e for e in bm.edges if e.is_boundary]
        if not boundary:
            break
        try:
            _collect(bmesh.ops.triangle_fill(
                bm, edges=boundary, use_beauty=True, use_dissolve=False))
        except Exception:
            try:
                _collect(bmesh.ops.holes_fill(bm, edges=boundary, sides=0))
            except Exception:
                break
    # フタの n-gon を三角化(凹断面でも破綻しないように)
    big_ngons = [f for f in new_faces if f.is_valid and len(f.verts) > 4]
    if big_ngons:
        try:
            bmesh.ops.triangulate(bm, faces=big_ngons)
        except Exception:
            pass


def surface_average_normal(obj):
    """メッシュの面積加重平均法線(ワールド) - numpy高速版"""
    import numpy as np
    me = obj.data
    me.calc_loop_triangles()
    n_tri = len(me.loop_triangles)
    if n_tri == 0:
        return Vector((0, 0, 1))
    normals = np.empty(n_tri * 3, dtype=np.float64)
    areas = np.empty(n_tri, dtype=np.float64)
    me.loop_triangles.foreach_get('normal', normals)
    me.loop_triangles.foreach_get('area', areas)
    normals = normals.reshape(n_tri, 3)
    wn = (normals * areas[:, None]).sum(axis=0)
    mw3 = np.array(obj.matrix_world.to_3x3())
    wn_world = mw3 @ wn
    length = float(np.linalg.norm(wn_world))
    if length < 1e-9:
        return Vector((0, 0, 1))
    return Vector((wn_world / length).tolist())


def normal_at_point(cut, point):
    """ダボ軸に使う切断面法線。平面カットは平面法線。曲面(メッシュ)カットも
    『断面積全体の平均法線』(cut["no"])で統一する=ピンの接続面(土台上面)を
    平面化して、嵌合しやすく生成も安定させる。"""
    return cut["no"]


# ============================================================
# ダボ生成
# ============================================================

def part_min_extent(part):
    """パーツの最小バウンディングボックス寸法(=ダボが収まる上限の目安)"""
    mn, mx = world_bbox(part)
    d = mx - mn
    return min(d.x, d.y, d.z)


def _cap_faces_numpy(me, co, no, tol):
    """numpy一括読み込みで切断面coplanarポリゴンを高速抽出。
    Returns (cap_idx, loop_verts, loop_starts, loop_totals, areas, centers_flat, vco)
    または None(頂点/ポリゴンなし)。"""
    import numpy as np
    nv, np_poly = len(me.vertices), len(me.polygons)
    if nv == 0 or np_poly == 0:
        return None
    vco = np.empty(nv * 3, dtype=np.float64)
    me.vertices.foreach_get('co', vco)
    vco = vco.reshape(nv, 3)
    no_arr = np.array([no.x, no.y, no.z])
    co_arr = np.array([co.x, co.y, co.z])
    vdist = (vco - co_arr) @ no_arr
    loop_count = len(me.loops)
    loop_verts = np.empty(loop_count, dtype=np.int32)
    me.loops.foreach_get('vertex_index', loop_verts)
    loop_starts = np.empty(np_poly, dtype=np.int32)
    loop_totals = np.empty(np_poly, dtype=np.int32)
    areas = np.empty(np_poly, dtype=np.float64)
    centers_flat = np.empty(np_poly * 3, dtype=np.float64)
    me.polygons.foreach_get('loop_start', loop_starts)
    me.polygons.foreach_get('loop_total', loop_totals)
    me.polygons.foreach_get('area', areas)
    me.polygons.foreach_get('center', centers_flat)
    poly_idx = np.repeat(np.arange(np_poly, dtype=np.int32), loop_totals)
    max_dists = np.zeros(np_poly)
    np.maximum.at(max_dists, poly_idx, np.abs(vdist[loop_verts]))
    cap_idx = np.where(max_dists < tol)[0]
    return cap_idx, loop_verts, loop_starts, loop_totals, areas, centers_flat, vco


def extract_cap_full(obj, co, no, tol):
    """平面(co,no)coplanar なフタ面を単一パスで抽出:
    (verts, faces, centroid, area_total, dowel_point) or None。"""
    import numpy as np
    r = _cap_faces_numpy(obj.data, co, no, tol)
    if r is None or len(r[0]) == 0:
        return None
    cap_idx, loop_verts, loop_starts, loop_totals, areas, centers_flat, vco = r
    cap_areas = areas[cap_idx]
    cap_centers = centers_flat.reshape(-1, 3)[cap_idx]
    area_total = float(cap_areas.sum())
    if area_total > 0:
        centroid_arr = (cap_centers * cap_areas[:, None]).sum(axis=0) / area_total
    else:
        centroid_arr = cap_centers[0].copy()
    centroid = Vector(centroid_arr.tolist())
    dists = np.linalg.norm(cap_centers - centroid_arr, axis=1)
    dowel_pt = Vector(cap_centers[int(np.argmin(dists))].tolist())
    vmap = {}
    verts_out = []
    faces_out = []
    for i in cap_idx:
        ls, lt = int(loop_starts[i]), int(loop_totals[i])
        face_idx = []
        for vi in loop_verts[ls:ls + lt]:
            vi = int(vi)
            if vi not in vmap:
                vmap[vi] = len(verts_out)
                verts_out.append(Vector(vco[vi].tolist()))
            face_idx.append(vmap[vi])
        faces_out.append(tuple(face_idx))
    return verts_out, faces_out, centroid, area_total, dowel_pt


def compute_dowel_dims(props, area_units, safe_max_units):
    """ダボ寸法(r_peg, r_hole, peg_out, peg_base)を決定。
      手動  : 入力した径(mm)をそのまま使う(無制限)。
      自動  : 断面と等価な円の直径 × 断面比。最小/最大(mm)でのみ丸める。
    clamp_to_part が有効なときだけ、パーツに収まるよう上限をかける。"""
    if props.dowel_auto_size and area_units > 0.0:
        char_d = 2.0 * math.sqrt(area_units / math.pi)
        dia = props.dowel_area_ratio * char_d
        dia = max(_mm(props, props.dowel_min_mm), dia)
        dia = min(dia, _mm(props, props.dowel_max_mm))
        peg_out = dia * props.dowel_depth_factor
        peg_base = dia * props.dowel_base_factor
    else:
        dia = _mm(props, props.dowel_diameter)   # 手動=入力どおり
        peg_out = _mm(props, props.peg_depth)
        peg_base = _mm(props, props.base_depth)

    clearance = _mm(props, props.dowel_clearance)

    # 任意: パーツに収める安全クランプ(既定オフ=制限なし)
    if props.clamp_to_part and safe_max_units > 0.0:
        clearance = min(clearance, 0.2 * safe_max_units)
        max_dia = 0.9 * safe_max_units - 2.0 * clearance
        dia = min(dia, max(0.0, max_dia))
        peg_out = min(peg_out, safe_max_units)
        peg_base = min(peg_base, safe_max_units)

    r_peg = dia / 2.0
    r_hole = r_peg + clearance       # 穴は必ず凸より clearance だけ大きい
    return r_peg, r_hole, peg_out, peg_base


def make_cylinder(center, axis, radius, length, name):
    bpy.ops.mesh.primitive_cylinder_add(radius=radius, depth=length,
                                         location=center, vertices=48)
    cyl = bpy.context.active_object
    rot = Vector((0, 0, 1)).rotation_difference(axis).to_matrix().to_4x4()
    cyl.matrix_world = Matrix.Translation(center) @ rot
    bpy.context.view_layer.update()
    cyl.name = name
    return cyl


def make_peg_solid(props, center, axis, half_pz, half_mz, length, name,
                   link_coll=None, shape=None):
    """ダボ(丸/角/L字)を生成。+Z端の半幅(半径)=half_pz、-Z端=half_mz の
    角錐台/円錐台。half_pz==half_mz なら角柱/円柱。局所+Zを axis に向ける。
    shape で 'ROUND'/'SQUARE'/'L' を明示指定できる(未指定なら props.dowel_shape)。
    'L' は 2a×2a の角柱から +X+Y 象限を除いたL字断面(先細りも同じ勾配で追従)。
    bpy.ops や bpy.context.collection に依存しない(タイマー文脈でも安全)。"""
    rot = Vector((0, 0, 1)).rotation_difference(axis).to_matrix().to_4x4()
    eff_shape = shape or props.dowel_shape
    me = bpy.data.meshes.new(name)
    bm = bmesh.new()
    if eff_shape == 'L':
        hz = length / 2.0
        a, b = half_pz, half_mz
        # L字断面(反時計回り): (2a)角形から +X+Y 象限を欠いた6角形。角ダボと同様の
        # 回り止めに加え、左右非対称なので前後(表裏)の取り違えも防げるキー形状。
        top = [(-a, -a), (a, -a), (a, 0.0), (0.0, 0.0), (0.0, a), (-a, a)]
        bot = [(-b, -b), (b, -b), (b, 0.0), (0.0, 0.0), (0.0, b), (-b, b)]
        top_v = [bm.verts.new((x, y, hz)) for (x, y) in top]
        bot_v = [bm.verts.new((x, y, -hz)) for (x, y) in bot]
        m = len(top)
        bm.faces.new(top_v)                       # +Z フタ
        bm.faces.new(list(reversed(bot_v)))       # -Z フタ
        for i in range(m):                        # 側面(6枚)
            j = (i + 1) % m
            bm.faces.new([top_v[i], top_v[j], bot_v[j], bot_v[i]])
    elif eff_shape == 'SQUARE':
        hz = length / 2.0
        a, b = half_pz, half_mz
        co = [(-a, -a, hz), (a, -a, hz), (a, a, hz), (-a, a, hz),     # +Z
              (-b, -b, -hz), (b, -b, -hz), (b, b, -hz), (-b, b, -hz)]  # -Z
        vs = [bm.verts.new(c) for c in co]
        for f in [(0, 1, 2, 3), (7, 6, 5, 4), (0, 4, 5, 1),
                  (1, 5, 6, 2), (2, 6, 7, 3), (3, 7, 4, 0)]:
            bm.faces.new([vs[i] for i in f])
    else:
        # 円錐台: radius1(-Z)=half_mz, radius2(+Z)=half_pz
        bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False,
                              segments=48, radius1=half_mz, radius2=half_pz,
                              depth=length)
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    if eff_shape == 'L':
        # L字は凹多角形フタを含むため、どのソルバでも安定するよう三角化しておく
        bmesh.ops.triangulate(bm, faces=list(bm.faces))
    bm.to_mesh(me)
    bm.free()
    me.update()
    obj = bpy.data.objects.new(name, me)
    (link_coll or bpy.context.scene.collection).objects.link(obj)
    obj.matrix_basis = Matrix.Translation(center) @ rot
    return obj


def make_sphere(center, radius, name, link_coll=None):
    """半径 radius の球(bmesh製・ops非依存)。center に配置。"""
    me = bpy.data.meshes.new(name)
    bm = bmesh.new()
    try:
        bmesh.ops.create_icosphere(bm, subdivisions=2, radius=radius)
    except TypeError:        # 旧API
        bmesh.ops.create_icosphere(bm, subdivisions=2, diameter=radius * 2.0)
    bm.to_mesh(me)
    bm.free()
    me.update()
    obj = bpy.data.objects.new(name, me)
    (link_coll or bpy.context.scene.collection).objects.link(obj)
    obj.matrix_basis = Matrix.Translation(center)
    return obj


def dowel_taper_params(props, dims):
    """ダボの各端半幅・長さ等を計算(凸/凹で同一テーパー勾配)。
    寸法が0なら None。本番生成・プレビューで共用する。"""
    r_peg, r_hole, peg_out, peg_base = dims
    if r_peg <= 0.0 or peg_out <= 0.0:
        return None
    clr = r_hole - r_peg
    margin = _mm(props, 0.5)
    taper = max(0.0, min(0.6, props.dowel_taper))
    slope = taper * r_peg / peg_out          # 単位長さあたりの半幅減少量
    return {
        "r_peg": r_peg, "clr": clr, "margin": margin,
        "peg_out": peg_out, "peg_base": peg_base,
        "peg_len": peg_out + peg_base, "hole_len": peg_out + margin,
        "peg_pz": r_peg + slope * peg_base,          # +Z端(根元,+n側)=太い
        "peg_mz": r_peg - slope * peg_out,           # -Z端(先端)     =細い
        "hole_pz": (r_peg + clr) + slope * margin,
        "hole_mz": (r_peg + clr) - slope * peg_out,
    }


def _seat_taper(props):
    """座の先細り率(0〜0.6にクランプ)。先端(突出側)半径 = 根元 ×(1-率)。"""
    return max(0.0, min(0.6, props.base_taper))


def _peg_center(pt, n, P):
    return pt + (-n) * (P["peg_out"] / 2.0 - P["peg_base"] / 2.0)


def _hole_center(pt, n, P):
    return pt + (-n) * (P["hole_len"] / 2.0 - P["margin"])


def _l_guide_offset(axis, half):
    """L字ダボの軸打ちガイド位置オフセット。L断面の交差部(コーナー正方形 [-a,0]²)の
    中心 = ローカル(-half/2, -half/2) を、ピンと同じ回転(rotation_difference)で
    ワールドへ写したベクトル。これで中心(凹角)ではなく肉厚のある交差部中心に穴が来る。"""
    rot = Vector((0.0, 0.0, 1.0)).rotation_difference(axis).to_matrix()
    return rot @ Vector((-half / 2.0, -half / 2.0, 0.0))


CUTTER_COLL = "PartSplit_DowelCutters"


def _ensure_cutter_collection():
    coll = bpy.data.collections.get(CUTTER_COLL)
    if coll is None:
        coll = bpy.data.collections.new(CUTTER_COLL)
        bpy.context.scene.collection.children.link(coll)
    return coll


def _dowel_node_group(name, union_objs, diff_objs, solver):
    """非破壊ダボ用の Geometry Nodes グループを作る。入力ジオメトリに対し、
    union_objs を順に UNION、diff_objs を順に DIFFERENCE(いずれも Object Info→
    Mesh Boolean)して出力。各カッターは1つずつ処理=自己交差で壊れない。"""
    gsolver = 'EXACT' if solver == 'EXACT' else 'FLOAT'
    ng = bpy.data.node_groups.new(name, 'GeometryNodeTree')
    ng.interface.new_socket("Geometry", in_out='INPUT',
                            socket_type='NodeSocketGeometry')
    ng.interface.new_socket("Geometry", in_out='OUTPUT',
                            socket_type='NodeSocketGeometry')
    gin = ng.nodes.new('NodeGroupInput')
    gin.location = (-400, 0)
    gout = ng.nodes.new('NodeGroupOutput')
    geo = gin.outputs[0]
    x = -200

    def cutter_node(obj, y):
        oi = ng.nodes.new('GeometryNodeObjectInfo')
        oi.location = (x, y - 220)
        oi.transform_space = 'RELATIVE'
        oi.inputs['Object'].default_value = obj
        return oi

    for obj in union_objs:
        oi = cutter_node(obj, 0)
        b = ng.nodes.new('GeometryNodeMeshBoolean')
        b.location = (x, 0)
        b.operation = 'UNION'
        b.solver = gsolver
        ng.links.new(geo, b.inputs['Mesh'])
        ng.links.new(oi.outputs['Geometry'], b.inputs['Mesh'])
        geo = b.outputs['Mesh']
        x += 200
    for obj in diff_objs:
        oi = cutter_node(obj, 0)
        b = ng.nodes.new('GeometryNodeMeshBoolean')
        b.location = (x, 0)
        b.operation = 'DIFFERENCE'
        b.solver = gsolver
        ng.links.new(geo, b.inputs['Mesh 1'])
        ng.links.new(oi.outputs['Geometry'], b.inputs['Mesh 2'])
        geo = b.outputs['Mesh']
        x += 200
    gout.location = (x, 0)
    ng.links.new(geo, gout.inputs[0])
    return ng


def _prep_cutter(obj, parent, coll):
    """カッターを親付け・ワイヤ表示・非レンダ・カッター用コレクションへ移動。
    hide_viewport は使わない(Object Info が評価できなくなるため)。"""
    obj.parent = parent
    obj.matrix_parent_inverse = parent.matrix_world.inverted()
    obj.display_type = 'WIRE'
    obj.hide_render = True
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    coll.objects.link(obj)


def _setup_live_dowels(props, pos_part, neg_part, pegs, holes,
                       guides_pos, guides_neg):
    """焼き込まず、pos/neg 各パーツに GN モディファイアで非破壊ダボを付ける。
    カッター(ピン/穴/座/ガイド)はオブジェクトとして残し、パーツに親付けする。"""
    coll = _ensure_cutter_collection()
    for o in pegs:
        _prep_cutter(o, pos_part, coll)
    for o in holes:
        _prep_cutter(o, neg_part, coll)
    for o in guides_pos:
        _prep_cutter(o, pos_part, coll)
    for o in guides_neg:
        _prep_cutter(o, neg_part, coll)
    ngp = _dowel_node_group("PS_Dowel_" + pos_part.name, pegs, guides_pos,
                            props.solver)
    pos_part.modifiers.new("PartSplit Dowel", 'NODES').node_group = ngp
    ngn = _dowel_node_group("PS_Dowel_" + neg_part.name, [], holes + guides_neg,
                            props.solver)
    neg_part.modifiers.new("PartSplit Dowel", 'NODES').node_group = ngn


def add_dowels_batch(props, pos_part, neg_part, points, normal_func, dims,
                     no=None, area=0.0, cap_data=None, seat_loop=None):
    """ダボを生成。座(土台)方式が有効なら、各ダボ点にピン径基準の単純な円柱/角柱の
    座をピン根元に付け(凸=UNION / 凹=クリアランス付きの座ぐり DIFFERENCE)、その上に
    指定寸法のピンを乗せる。断面シルエットには追従しないので薄肉・複雑断面でも自然。
    base_shape=='LOOP' かつ seat_loop(なぞりループ)があれば、座の断面をそのループ形状
    にする(_loop_seat_rings + build_loop_prism)。"""
    P = dowel_taper_params(props, dims)
    if P is None:
        print(f"[PartSplit] dowel skipped: zero size (dims={dims})")
        return
    # オス/メス反転: pos(凸)とneg(凹)を入れ替え、法線も反転すればピン・座とも
    # 幾何は対称なので、突出向き・座ぐり側が正しく入れ替わる。
    if props.dowel_flip:
        pos_part, neg_part = neg_part, pos_part
        _nf = normal_func
        normal_func = lambda pt, _f=_nf: -_f(pt)
    use_base = (props.dowel_use_base and no is not None)
    print(f"[PartSplit] dowels: n={len(points)} "
          f"dia={2*P['r_peg']*_unit_mm_per_bu(props):.2f}mm "
          f"peg_out={P['peg_out']*_unit_mm_per_bu(props):.2f}mm "
          f"clearance={P['clr']*_unit_mm_per_bu(props):.3f}mm "
          f"base={'on' if use_base else 'off'}")

    # 座(単純プリミティブ)の寸法
    height = props.base_height_factor * (2.0 * P["r_peg"]) if use_base else 0.0
    seat_r = props.base_dia_factor * P["r_peg"]          # 座の半径(半幅・根元/切断面側)
    seat_tip = seat_r * (1.0 - _seat_taper(props))       # 突出先端側の半径(先細り)
    seat_clr = _mm(props, props.base_clearance)           # 凹側座ぐりの半径クリアランス
    seat_shape = props.base_shape                          # 座の断面(丸/角柱/L/ループ)
    use_loop_seat = (seat_shape == 'LOOP' and seat_loop is not None
                     and len(seat_loop) >= 3)
    s_root = props.base_loop_scale                         # ループ座の倍率(根元)
    s_tip = s_root * (1.0 - _seat_taper(props))            # 同(先端=先細り)
    margin = P["margin"]
    # 座を本体側へ食い込ませ、切断面の蓋と同一面(coplanar)を避ける量
    overlap = max(_mm(props, 1.0), 3.0 * _mm(props, props.kerf_mm))

    pegs, holes = [], []
    tips = []     # 軸打ちガイド用: 各ピン先端(断面中心)
    for pt in points:
        n = normal_func(pt)
        base_pt = pt + (-n) * height       # 座の底面(=ピンが立つ面)
        if use_base and height > 0.0 and use_loop_seat:
            # ループ断面の座: なぞったループ形状を根元/先端リングにして押し出す。
            # 凸: +n へ overlap 食い込み、-n へ height 突出。凹: クリアランス付き座ぐり。
            rm, tm, mean_r = _loop_seat_rings(seat_loop, pt, n, overlap, -height,
                                              s_root, s_tip)
            sm = build_loop_prism(rm, tm, "_seatM")
            if sm is not None:
                pegs.append(sm)
            d = seat_clr / max(mean_r, 1e-9)               # 絶対クリアランス→倍率換算
            rf, tf, _ = _loop_seat_rings(seat_loop, pt, n, margin,
                                         -(height + margin), s_root + d, s_tip + d)
            sf = build_loop_prism(rf, tf, "_seatF")
            if sf is not None:
                holes.append(sf)
        elif use_base and seat_r > 0.0 and height > 0.0:
            # 凸の座: pt(切断面)から本体側 +n へ overlap 食い込み、-n へ height。
            # +Z(根元=切断面側)=seat_r, -Z(突出先端)=seat_tip の先細り。
            seat_top = pt + n * overlap
            length_m = height + overlap
            pegs.append(make_peg_solid(props, seat_top + (-n) * length_m / 2.0,
                                       n, seat_r, seat_tip, length_m, "_seatM",
                                       shape=seat_shape))
            # 凹の座ぐり: クリアランス付きで、口を margin だけ広げ底も margin 深く
            seat_top_f = pt + n * margin
            length_f = height + 2.0 * margin
            holes.append(make_peg_solid(props,
                                        seat_top_f + (-n) * length_f / 2.0, n,
                                        seat_r + seat_clr, seat_tip + seat_clr,
                                        length_f, "_seatF", shape=seat_shape))
        pegs.append(make_peg_solid(props, _peg_center(base_pt, n, P), n,
                                   P["peg_pz"], P["peg_mz"], P["peg_len"],
                                   "_peg"))
        holes.append(make_peg_solid(props, _hole_center(base_pt, n, P), n,
                                    P["hole_pz"], P["hole_mz"], P["hole_len"],
                                    "_hole"))
        # ピン先端=断面の中心。ただしL字ダボは中心(=凹角)が材料の角に当たり軸打ち
        # できないため、L字の交差部(コーナー正方形)の中心へずらす。
        tip = base_pt + (-n) * P["peg_out"]
        if props.dowel_shape == 'L':
            tip = tip + _l_guide_offset(n, P["peg_mz"])
        tips.append(tip)

    # --- 軸打ちガイド球を作る(適用はモードにより後段で分岐) ---
    #     非破壊(GN)では凸/凹それぞれに親付けするので2個ずつ作る。
    guides_pos, guides_neg = [], []
    if props.axis_guide:
        rg = _mm(props, props.axis_guide_dia) / 2.0
        for tp in tips:
            guides_pos.append(make_sphere(tp, rg, "_guideM"))
            if props.dowel_live:
                guides_neg.append(make_sphere(tp, rg, "_guideF"))

    # --- 非破壊(GN)モード: 焼き込まず GN モディファイアで付ける ---
    if props.dowel_live:
        _setup_live_dowels(props, pos_part, neg_part, pegs, holes,
                           guides_pos, guides_neg)
        return

    # --- 焼き込みモード(従来) ---
    # 凸: 各ピン/座は重なり合うため、まとめると自己交差で UNION が破綻する。1本ずつ。
    if props.peg_use_boolean:
        for peg in pegs:
            apply_boolean(pos_part, peg, 'UNION', props.solver)
            bpy.data.objects.remove(peg, do_unlink=True)
    else:
        join_objects(pos_part, pegs)   # 演算0回
    # 凹: 受け(土台)と穴(ピン)は重なるため、まとめず個別に DIFFERENCE
    for h in holes:
        apply_boolean(neg_part, h, 'DIFFERENCE', props.solver)
        bpy.data.objects.remove(h, do_unlink=True)
    # 軸打ちガイド: 凸/凹の両方を同じ球でえぐる
    for s in guides_pos:
        apply_boolean(pos_part, s, 'DIFFERENCE', props.solver)
        apply_boolean(neg_part, s, 'DIFFERENCE', props.solver)
        bpy.data.objects.remove(s, do_unlink=True)


# ============================================================
# 切断面オブジェクトの収集
# ============================================================

def collect_cuts(props, target, selected=None):
    """切断面オブジェクトを集める。
    選択モード(selected_cuts_only)では、選択中で target 以外のメッシュ/Emptyを
    名前に関係なく刃として使う(選択していないものは無視)。
    通常モードでは接頭辞(CUT_)で始まる全オブジェクトを使う。"""
    cuts = []
    if props.selected_cuts_only:
        sel = set(selected) if selected is not None else set(
            bpy.context.selected_objects)
        candidates = [o for o in sel if o != target and o.type == 'MESH']
    else:
        candidates = [o for o in bpy.data.objects
                      if o != target and o.type == 'MESH'
                      and o.name.startswith(props.cut_prefix)]
    # 切断面は Subdivision→Solidify で厚み付けした『刃』にして、単純ブーリアン
    # (DIFFERENCE)+ルース分離でカッター輪郭内の交差部だけを分割する(平面/曲面とも)。
    for o in candidates:
        dowel_pts = [c.matrix_world.translation.copy()
                     for c in o.children if c.type == 'EMPTY']
        no = surface_average_normal(o)
        mn, mx = world_bbox(o)
        cuts.append({"name": o.name, "type": 'mesh', "obj": o,
                     "co": (mn + mx) / 2.0, "no": no, "dowels": dowel_pts})
    return cuts


# ============================================================
# カット分割 / ダボ計画 (本番・プレビュー共用)
# ============================================================

def extract_blade_cap(part, blade_smooth, tol, no):
    """刃(subdivision→solidify)で分割した後の『実カット面』を part から抽出する。
    厚み付け前の平滑サーフェス(blade_smooth)への近接(tol以内)で判定するので、
    平面/曲面いずれの刃でも、カッター輪郭内に収まる有限断面を正しく取れる。
    戻り値 (verts, faces, centroid, area) / 無ければ None。"""
    from mathutils.bvhtree import BVHTree
    bm = bmesh.new()
    bm.from_mesh(blade_smooth.data)
    bvh = BVHTree.FromBMesh(bm)
    me = part.data
    vmap = {}
    verts = []
    faces = []
    cw = Vector((0, 0, 0))
    area = 0.0
    for poly in me.polygons:
        loc, _nor, _idx, _d = bvh.find_nearest(poly.center, tol)
        if loc is not None:
            idx = []
            for vi in poly.vertices:
                if vi not in vmap:
                    vmap[vi] = len(verts)
                    verts.append(me.vertices[vi].co.copy())
                idx.append(vmap[vi])
            faces.append(tuple(idx))
            area += poly.area
            cw += poly.center * poly.area
    bm.free()
    if not faces:
        return None
    centroid = cw / area if area > 0 else verts[0].copy()
    return verts, faces, centroid, area


def compute_cut_dowels(props, pos, neg, cut, co, no, blade=None):
    """この切断面のダボ位置・寸法・断面積・断面輪郭(cap_data)を返す。
    刃(blade_smooth)が渡されれば、それに近接する pos の面=実カット断面を抽出する
    (subdivision→solidify 刃方式。カッター輪郭内の有限断面を平面/曲面とも正しく取得)。
    刃が無い場合は coplanar フタにフォールバック。断面積はダボ径の自動算出に、
    重心(または子Empty)はダボ点として使う。cap_data は座方式では未使用。"""
    dpos, _mn, _mx = obj_diagonal(pos)
    tol = max(1e-6, dpos * 2e-3)
    cap_data = None
    area = 0.0
    auto_pt = None
    cap_kind = "none"
    if blade is not None:
        kerf = _mm(props, props.kerf_mm)
        bc = extract_blade_cap(pos, blade, max(kerf * 1.5, tol), no)
        if bc is not None:
            verts, faces, centroid = bc[0], bc[1], bc[2]
            flat = [v - no * ((v - centroid).dot(no)) for v in verts]
            cap_data = (flat, faces, centroid)
            area = bc[3]
            auto_pt = centroid
            cap_kind = "blade-cut"
    if cap_data is None:
        cap_result = extract_cap_full(pos, co, no, tol)  # 平らな実カット面(有限)
        if cap_result is not None:
            cap_data = (cap_result[0], cap_result[1], cap_result[2])
            area = cap_result[3]
            auto_pt = cap_result[4]
            cap_kind = "flat-cut"
    print(f"[PartSplit]   cap faces={len(cap_data[1]) if cap_data else 0} "
          f"kind={cap_kind} type={cut['type']} area={area:.6f} "
          f"(area はダボ径の自動算出に使用)")
    if cut["dowels"]:
        # ダボ点を実カット面(平均法線平面)へ投影(座・ピンが断面上に正しく載る)
        plane_c = cap_data[2] if cap_data is not None else co
        pts = [pt - no * (pt - plane_c).dot(no) for pt in cut["dowels"]]
    else:
        pts = [auto_pt if auto_pt is not None else cut["co"]]
    n_pts = max(1, len(pts))
    # ダボがパーツに収まる上限。0.85=断面いっぱい近くまで許容(穴の収まりは別途確保)
    safe_max = 0.85 * min(part_min_extent(pos), part_min_extent(neg))
    dims = compute_dowel_dims(props, area / n_pts, safe_max)
    return pts, dims, area, safe_max, cap_data


def aabb_overlap(a, b):
    """2オブジェクトの軸平行バウンディングボックスが重なるか。"""
    amn, amx = world_bbox(a)
    bmn, bmx = world_bbox(b)
    return all(amn[i] <= bmx[i] and bmn[i] <= amx[i] for i in range(3))


def make_blade_slab(props, cutter, kerf):
    """カッター(開いた面)を『刃』ソリッドにする。
    1) Subdivision Surface で平滑化・高密度化(粗い/カクついた面でも滑らかな刃に)
    2) Solidify で厚み kerf を付け、閉じた水密ソリッドにする
    戻り値 (blade_smooth, slab):
      blade_smooth = 厚み付け前の平滑サーフェス(断面抽出の基準に使う)
      slab         = 厚み kerf の閉じたソリッド(ブーリアンの刃)
    粗い刃でも subdivision→solidify で安定した単純ブーリアン分割ができる。"""
    smooth = duplicate_obj(cutter, "_blade")
    # トランスフォームをメッシュへ焼き込む(transform_apply オペレータ非依存)
    smooth.data.transform(smooth.matrix_world)
    smooth.matrix_world = Matrix.Identity(4)
    if props.blade_subdiv > 0:
        sub = smooth.modifiers.new("subsurf", 'SUBSURF')
        sub.levels = props.blade_subdiv
        sub.render_levels = props.blade_subdiv
        _apply_modifiers(smooth)
    slab = duplicate_obj(smooth, "_slab")
    m = slab.modifiers.new("sol", 'SOLIDIFY')
    m.thickness = kerf
    m.offset = 0.0          # 面を中心に±kerf/2
    m.use_even_offset = True
    _apply_modifiers(slab)
    return smooth, slab


def drop_debris(props, pieces):
    """刃カットで生じた極小破片(しきい値トライ数以下)を削除し、残りを返す。"""
    if not props.remove_debris:
        return pieces
    keep = []
    for p in pieces:
        if len(p.data.polygons) <= props.debris_max_tris:
            bpy.data.objects.remove(p, do_unlink=True)
        else:
            keep.append(p)
    return keep


def split_part_by_blade(props, part, cut, co, no, consume=True):
    """part を『厚み付けした刃(subdivision→solidify)』で単純ブーリアン(DIFFERENCE)し、
    ルース分離 → 極小破片除去 → 切断面(co,no)の±側でグループ化して pos/neg に統合する。
    半空間ソリッド方式より頑健で、出力は水密な単一シェルになりやすい。
    戻り値 (pos, neg, blade_smooth)。分離できなければ pos か neg が None。
    consume=True で part を消費、False で複製上で行い元を残す(プレビュー)。"""
    work = part if consume else duplicate_obj(part, part.name + "_pv")
    blade_smooth, slab = make_blade_slab(props, cut["obj"], _mm(props, props.kerf_mm))
    try:
        apply_boolean(work, slab, 'DIFFERENCE', props.solver)
    finally:
        bpy.data.objects.remove(slab, do_unlink=True)

    pieces = [p for p in separate_loose(work) if not is_empty_mesh(p)]
    pieces = drop_debris(props, pieces)

    pos_g, neg_g = [], []
    for p in pieces:
        d = (_piece_volume_centroid(p) - co).dot(no)
        (pos_g if d >= 0 else neg_g).append(p)
    pos = join_objects(pos_g[0], pos_g[1:]) if pos_g else None
    neg = join_objects(neg_g[0], neg_g[1:]) if neg_g else None
    return pos, neg, blade_smooth


def separate_loose(obj):
    """obj を非連結(ルース)で分離し、結果オブジェクトのリストを返す。
    bmesh で連結成分を求めて島ごとにメッシュを作る(edit モード切替の
    重い `mesh.separate` オペレータを使わない=高速・コンテキスト非依存)。"""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    isl = {}                                   # vert index -> island id
    nis = 0
    for v in bm.verts:
        if v.index in isl:
            continue
        stack = [v]
        while stack:
            w = stack.pop()
            if w.index in isl:
                continue
            isl[w.index] = nis
            for e in w.link_edges:
                stack.append(e.other_vert(w))
        nis += 1
    if nis <= 1:
        bm.free()
        return [obj]
    # 島ごとに面を集めてメッシュ化。先頭島は obj を上書き、残りは新規オブジェクト。
    groups = {}
    for f in bm.faces:
        groups.setdefault(isl[f.verts[0].index], []).append(f)
    coll = obj.users_collection[0] if obj.users_collection else \
        bpy.context.scene.collection
    mw = obj.matrix_world.copy()
    base_name = obj.name
    results = []
    for k, faces in groups.items():
        vmap = {}
        co = []
        py_faces = []
        for f in faces:
            row = []
            for v in f.verts:
                if v.index not in vmap:
                    vmap[v.index] = len(co)
                    co.append(v.co.copy())
                row.append(vmap[v.index])
            py_faces.append(row)
        me = bpy.data.meshes.new(base_name)
        me.from_pydata([c[:] for c in co], [], py_faces)
        me.update()
        if not results:
            old = obj.data
            obj.data = me
            if old.users == 0:
                bpy.data.meshes.remove(old)
            results.append(obj)
        else:
            nobj = bpy.data.objects.new(base_name, me)
            nobj.matrix_world = mw
            coll.objects.link(nobj)
            results.append(nobj)
    bm.free()
    return results


def _piece_volume_centroid(p):
    """パーツの体積重心(ワールド=ローカル前提)。頂点平均は切り口の高密度メッシュに
    引っ張られて±判定を誤るため、破片の ±側分類にはこちらを使う。
    符号付き四面体で算出。縮退(体積≒0)時は bbox 中心。"""
    bm = bmesh.new()
    bm.from_mesh(p.data)
    vol = 0.0
    acc = Vector((0.0, 0.0, 0.0))
    for f in bm.faces:
        vs = f.verts
        o = vs[0].co
        for i in range(1, len(vs) - 1):
            a = vs[i].co
            b = vs[i + 1].co
            t = o.dot(a.cross(b)) / 6.0
            vol += t
            acc += (o + a + b) * (t / 4.0)
    bm.free()
    if abs(vol) > 1e-15:
        return acc / vol
    mn, mx = world_bbox(p)
    return (mn + mx) / 2.0


def dowel_pair(props, pos, neg, cut, co, no, blade=None):
    """pos(凸側)/neg(凹側)の2パーツにダボ(土台+ピン)を生成する共通処理。"""
    pts, dims, area, safe_max, cap_data = compute_cut_dowels(
        props, pos, neg, cut, co, no, blade=blade)
    print(f"[PartSplit]   dowel calc: area={area:.6f} safe_max={safe_max:.5f} "
          f"points={len(pts)}")
    seat_loop = get_cut_loop(cut.get("obj")) if props.base_shape == 'LOOP' else None
    add_dowels_batch(props, pos, neg, pts,
                     lambda pt, c=cut: normal_at_point(c, pt),
                     dims, no=no, area=area, cap_data=cap_data, seat_loop=seat_loop)


# ============================================================
# メイン処理
# ============================================================

def run_split(props, target):
    import time
    t_all = time.time()

    sel = list(bpy.context.selected_objects)   # 選択を先に確保(以後deselectされる)
    cuts = collect_cuts(props, target, selected=sel)
    if not cuts:
        raise RuntimeError(
            f"'{props.cut_prefix}' で始まる切断面オブジェクトがありません。")

    # 作業用コピーを用意（元は任意で温存）
    if props.keep_original:
        target.hide_set(True)
        first = duplicate_obj(target, props.part_prefix + "_src")
    else:
        first = target

    # トランスフォームを適用 → 以後 ローカル=ワールド（bisectが高速・簡潔に）
    bpy.ops.object.select_all(action='DESELECT')
    first.select_set(True)
    bpy.context.view_layer.objects.active = first
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    parts = [first]

    for cut in cuts:
        t_cut = time.time()
        co, no = cut["co"], cut["no"]
        new_parts = []
        for part in parts:
            # --- 切断面(平面ポリゴン/曲面メッシュ)= 厚み付けした刃で分割 ---
            # subdivision→solidify で刃をソリッド化し、単純ブーリアン(DIFFERENCE)+
            # ルース分離で ±側へ分ける。輪郭外(他部位)は巻き込まず局所分割が可能。
            if not aabb_overlap(part, cut["obj"]):
                new_parts.append(part)            # カッターと交差せず
                continue
            blade = None
            try:
                pos, neg, blade = split_part_by_blade(props, part, cut, co, no,
                                                      consume=True)
            except Exception as e:
                print(f"[PartSplit]   split failed ({e}) -> kept whole")
                new_parts.append(part)
                continue
            valid = [p for p in (pos, neg)
                     if p is not None and not is_empty_mesh(p)]
            if len(valid) < 2:
                print("[PartSplit]   cutter did not separate into two pieces "
                      "(カッターが対象を完全に貫通しているか確認)")
            elif props.add_dowels:
                print("[PartSplit]   split -> 2 pieces")
                dowel_pair(props, pos, neg, cut, co, no, blade=blade)
            new_parts.extend(valid)
            if blade is not None:
                bpy.data.objects.remove(blade, do_unlink=True)
        parts = new_parts
        print(f"[PartSplit] cut '{cut['name']}' done in {time.time()-t_cut:.1f}s "
              f"-> {len(parts)} parts")

    for i, p in enumerate(parts):
        p.name = f"{props.part_prefix}_{i:02d}"
    print(f"[PartSplit] ALL DONE: {len(parts)} parts in {time.time()-t_all:.1f}s")
    return len(parts)


# ============================================================
# プロパティ
# ============================================================

# 直近プレビューの配置キャッシュ: [(point, normal, area_per_dowel, safe_max), ...]
# 断面計算(重い)は一度だけ。ダボサイズ変更時はここから即再描画する。
_PREVIEW_CACHE = []
_rebuild_pending = False


def _preview_rebuild_timer():
    """安全なタイミングでプレビューを作り直す(タイマー実行)。一度きり。"""
    global _rebuild_pending
    _rebuild_pending = False
    try:
        scene = bpy.context.scene
        if scene is not None and _PREVIEW_CACHE:
            rebuild_dowel_preview(scene.partsplit)
    except Exception as e:
        print("[PartSplit] preview update skipped:", e)
    return None        # 再登録しない(one-shot)


def _schedule_preview_rebuild():
    """プレビュー再描画をタイマーに予約(多重予約は1つに集約)。"""
    global _rebuild_pending
    if _rebuild_pending:
        return
    _rebuild_pending = True
    try:
        bpy.app.timers.register(_preview_rebuild_timer, first_interval=0.0)
    except Exception:
        _rebuild_pending = False


def _dowel_prop_update(self, context):
    """ダボ系プロパティ変更時、プレビュー表示中なら作り直しを予約(ボタン不要)。
    UI操作中はコールバック内で直接データ生成できないため、タイマーへ委譲する。"""
    if _PREVIEW_CACHE:
        _schedule_preview_rebuild()


class PARTSPLIT_Props(PropertyGroup):
    selected_cuts_only: BoolProperty(
        name="選択した刃のみで分割", default=True,
        description="アクティブ=分割元、他の選択メッシュ/Empty=刃 として分割する。"
                    "選択していないメッシュは無視(名前は不問)。1つずつ確実に分割可")
    cut_prefix: StringProperty(name="切断面の接頭辞(非選択モード時)", default="CUT_")
    part_prefix: StringProperty(name="パーツ接頭辞", default="Part")
    auto_unit: BoolProperty(
        name="単位を自動検出", default=True,
        description="シーンの単位設定(メートル等)から1単位=何mmを自動換算する。"
                    "ダボ寸法・クリアランスが常に正しい実寸になる")
    unit_scale: FloatProperty(name="1単位=何mm(手動)", default=1.0, min=0.0001)
    keep_original: BoolProperty(name="元メッシュを残す", default=True)

    draw_cut_expand: FloatProperty(
        name="ループ拡大率", default=0.05, min=0.0, soft_max=0.5,
        description="なぞった閉ループを重心から外側へ拡大する割合。0.05=5%大きく。"
                    "表面のわずかに外まで刃を張り出させ、囲った断面を確実に切り離す")
    draw_cut_brush: FloatProperty(
        name="ブラシサイズ(%)", default=1.5, min=0.1, soft_max=15.0,
        subtype='PERCENTAGE',
        description="なぞり時の点の間隔(対象サイズ比%)。小さいほど頂点が密=多く、"
                    "大きいほど疎=少なくなる。描画中は [ ] キーでも増減できる")

    add_dowels: BoolProperty(name="ダボを生成", default=True)

    dowel_live: BoolProperty(
        name="ダボを非破壊(GN)で生成", default=False,
        description="ダボを焼き込まず、各パーツに Geometry Nodes モディファイア"
                    "(Object Info→Mesh Boolean)で付ける。カッター(ワイヤ表示)を動かす/"
                    "差し替えるとライブで再計算=非破壊編集。エクスポート時は自動で反映。"
                    "※ブーリアンは同じソルバなので重い原型では再計算に時間はかかる")

    dowel_flip: BoolProperty(
        name="オス/メスを反転", default=False,
        description="ダボのオス(凸ピン・座)とメス(凹穴・座ぐり)が付く側を入れ替える。"
                    "切断面の法線(+N)側が既定でオス。ピンも座も一括で反転する",
        update=_dowel_prop_update)

    dowel_shape: EnumProperty(
        name="ダボ断面", default='SQUARE',
        items=[('SQUARE', "四角(角ダボ)", "回り止めになる角柱/角錐台ダボ"),
               ('L', "L字(Lボックス)", "L字断面の角柱/角錐台ダボ。回り止めに加え、"
                "非対称なので表裏・向きの取り違えも防げる"),
               ('ROUND', "丸", "円柱/円錐台ダボ")],
        update=_dowel_prop_update)
    dowel_taper: FloatProperty(
        name="テーパー(先細り)", default=0.15, min=0.0, max=0.6,
        description="先端を基部より細くする割合。0で真っ直ぐ、0.15で先端15%細い。"
                    "型抜き・差し込みが容易になる",
        update=_dowel_prop_update)

    dowel_use_base: BoolProperty(
        name="ピン根元に座(土台)を付ける", default=True,
        description="ピン径基準の単純な円柱/角柱の座をピン根元に付ける(凸=出っ張り/"
                    "凹=座ぐり)。断面シルエットには追従しない。位置決め・強度に有利",
        update=_dowel_prop_update)
    base_shape: EnumProperty(
        name="座の形状", default='SQUARE',
        items=[('SQUARE', "四角(角柱)", "回り止めになる角柱/角錐台の座"),
               ('L', "L字(Lボックス)", "L字断面の角柱/角錐台の座"),
               ('ROUND', "丸(円柱)", "円柱/円錐台の座"),
               ('LOOP', "なぞったループ断面",
                "『なぞってループカット』で描いたループの形状を座の断面に使う。"
                "ループカット由来の刃でのみ有効(それ以外は丸座にフォールバック)")],
        description="座の断面形状。ピンとは独立に選べる",
        update=_dowel_prop_update)
    base_loop_scale: FloatProperty(
        name="ループ座の倍率", default=0.9, min=0.1, soft_max=1.5,
        description="ループ断面座の大きさ倍率。1.0=なぞったループそのまま、"
                    "0.9=一回り内側(切り口の縁から少し内側に座が来る)",
        update=_dowel_prop_update)
    base_height_factor: FloatProperty(
        name="座の高さ=径×", default=1.0, min=0.0, max=10.0,
        description="座の高さ(凸の出っ張り/凹の座ぐり深さ)をダボ径の倍率で指定",
        update=_dowel_prop_update)
    base_dia_factor: FloatProperty(
        name="座の径=ダボ径×", default=1.6, min=1.0, max=5.0, soft_max=3.0,
        description="座(円柱/角柱)の径をダボ径の倍率で指定。1.6=ピンの1.6倍の太さ。"
                    "大きいほど接合面が広く位置決めが安定",
        update=_dowel_prop_update)
    base_taper: FloatProperty(
        name="座のテーパー(先細り)", default=0.10, min=0.0, max=0.6,
        description="座の突出先端を根元より細くする割合。0で真っ直ぐ、0.1で先端10%細い。"
                    "抜き差し・型抜きが容易になる",
        update=_dowel_prop_update)
    base_clearance: FloatProperty(
        name="座のクリアランス(mm)", default=0.10, min=0.0,
        description="凹側の座ぐりを半径方向にこの分だけ広げる(嵌合の遊び)",
        update=_dowel_prop_update)

    kerf_mm: FloatProperty(
        name="刃の厚み(mm)", default=0.40, min=0.001, soft_max=2.0,
        description="切断面を Solidify で厚み付けした『刃』の厚み(切り代)。"
                    "小さいほど隙間が少ないが、薄すぎるとブーリアン/分離に失敗しやすい。"
                    "0.3〜0.6mm 程度が安定")

    blade_subdiv: bpy.props.IntProperty(
        name="刃の平滑化(Subdivision)", default=2, min=0, soft_max=4,
        description="切断面を Solidify で厚み付けする前に Subdivision Surface で"
                    "平滑化・高密度化する回数。粗い/カクついた切断面でも滑らかで安定した"
                    "刃になる。0で平滑化なし(元の面のまま厚み付け)")

    remove_debris: BoolProperty(
        name="極小破片を除去", default=True,
        description="刃カットで生じた、しきい値以下の極小な破片を自動削除する")
    debris_max_tris: bpy.props.IntProperty(
        name="破片しきい値(tris)", default=100, min=0, soft_max=2000,
        description="このトライ数以下の破片を削除。大きくすると小さなパーツも消える")

    axis_guide: BoolProperty(
        name="軸打ちガイド穴", default=True,
        description="ピン先端(断面中心)に半球のくぼみを掘り、軸打ち(ドリル)の"
                    "センター目印にする。凸・凹の両方に作られる",
        update=_dowel_prop_update)
    axis_guide_dia: FloatProperty(
        name="ガイド径(mm)", default=1.0, min=0.05, soft_max=5.0,
        description="軸打ちガイドの半球の直径",
        update=_dowel_prop_update)

    clamp_to_part: BoolProperty(
        name="パーツに収める(安全制限)", default=False,
        description="ONのときだけ、ダボがパーツより大きくならないよう上限をかける。"
                    "OFF(既定)は指定どおり=大きさ無制限",
        update=_dowel_prop_update)

    dowel_auto_size: BoolProperty(
        name="断面積からダボ径を自動算出", default=True,
        description="切断断面の面積に応じてダボ径と深さを決める。"
                    "OFFなら『ダボ径(mm)[手動]』を入力どおりに使う(直感的)",
        update=_dowel_prop_update)
    dowel_area_ratio: FloatProperty(
        name="径/断面比", default=0.30, min=0.02, max=2.0, soft_max=1.2,
        description="断面と等価な円の直径に対するダボ径の割合。"
                    "1.0で断面いっぱい相当(さらに大きくも可)",
        update=_dowel_prop_update)
    dowel_depth_factor: FloatProperty(
        name="深さ=径×", default=1.5, min=0.1,
        description="ダボ径に対する突出/穴深さの倍率",
        update=_dowel_prop_update)
    dowel_base_factor: FloatProperty(
        name="根元=径×", default=1.0, min=0.0,
        description="ダボ径に対する根元長さの倍率",
        update=_dowel_prop_update)
    dowel_min_mm: FloatProperty(name="最小径(mm)", default=3.0, min=0.05,
                                update=_dowel_prop_update)
    dowel_max_mm: FloatProperty(name="最大径(mm)", default=100.0, min=0.1,
                                soft_max=300.0, update=_dowel_prop_update)

    dowel_diameter: FloatProperty(name="ダボ径(mm)[手動]", default=8.0, min=0.1,
                                  update=_dowel_prop_update)
    peg_depth: FloatProperty(name="凸の突出/穴深さ(mm)[手動]", default=10.0,
                             min=0.1, update=_dowel_prop_update)
    base_depth: FloatProperty(name="凸の根元(mm)[手動]", default=6.0, min=0.0,
                              update=_dowel_prop_update)
    dowel_clearance: FloatProperty(
        name="嵌合クリアランス(mm/片側)", default=0.10, min=0.0,
        description="穴を半径(半幅)方向にこの分だけ大きくする。"
                    "小さいほどキツい嵌合。0.05〜0.15が目安",
        update=_dowel_prop_update)

    peg_use_boolean: BoolProperty(
        name="凸をブーリアンで融合(推奨)", default=True,
        description="ON=UNIONで凸ダボを本体へ融合し、内部に膜/余計なシェルの無い"
                    "水密メッシュにする(既定・推奨)。OFF=join(高速だが凸ダボが"
                    "本体と分離したシェルのまま残る=内部に余計なメッシュが見える)")

    solver: EnumProperty(name="ソルバ(曲面/穴)",
                         items=[('EXACT', "Exact(高精度)", ""),
                                ('FAST', "Fast(高速)", "")],
                         default='EXACT')

    export_dir: StringProperty(name="出力先", subtype='DIR_PATH',
                               default="//split_parts")
    export_format: EnumProperty(name="形式",
                                items=[('STL', "STL", ""), ('OBJ', "OBJ", "")],
                                default='STL')


# ============================================================
# オペレーター
# ============================================================

# ============================================================
# 線を引いて刃を作る (Dovetail Key 風のドロー式カット)
# ============================================================

def _screen_ray(region, rv3d, co2d):
    """スクリーン座標 co2d をワールド空間の視線レイ (origin, direction) にする。"""
    co = Vector((co2d[0], co2d[1]))
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, co)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, co)
    return origin, direction.normalized()


def _raycast_target(target, depsgraph, origin_w, dir_w):
    """target(評価後メッシュ)へワールド空間のレイを撃ち、(hit, loc_w, nrm_w) を返す。"""
    mw = target.matrix_world
    mwi = mw.inverted()
    o_l = mwi @ origin_w
    d_l = (mwi.to_3x3() @ dir_w).normalized()
    res, loc_l, nrm_l, _idx = target.ray_cast(o_l, d_l, depsgraph=depsgraph)
    if not res:
        return False, None, None
    loc_w = mw @ loc_l
    nrm_w = (mw.to_3x3() @ nrm_l).normalized()
    return True, loc_w, nrm_w


def _loop_normal(pts):
    """点列(閉ループ)の最良近似平面の法線を Newell 法で求める。"""
    n = Vector((0.0, 0.0, 0.0))
    m = len(pts)
    for i in range(m):
        a = pts[i]
        b = pts[(i + 1) % m]
        n.x += (a.y - b.y) * (a.z + b.z)
        n.y += (a.z - b.z) * (a.x + b.x)
        n.z += (a.x - b.x) * (a.y + b.y)
    return n.normalized() if n.length > 1e-12 else Vector((0.0, 0.0, 1.0))


def build_loop_blade(props, target, loop_pts, name):
    """対象表面をなぞった閉ループ loop_pts(ワールド座標)から刃メッシュを生成する。
    ループの内側に面を張り(三角化フィル)、外側へ少し拡大した円盤にする。これを
    既存パイプライン(solidify→ブーリアン)で厚み付けして切ると、ループで囲った断面で
    パーツを切り離せる。視線方向へは伸ばさないので奥/手前を巻き込まない。
    中心に極(ポール)を作らないよう三角化フィルで張る=ダボ軸(中心)と重なって
    非多様体になるのを防ぐ。"""
    if len(loop_pts) < 3:
        return None
    pts = [Vector(p) for p in loop_pts]
    center = Vector((0.0, 0.0, 0.0))
    for p in pts:
        center += p
    center /= len(pts)
    # 外側へ少し拡大(重心からの放射方向)。ループが表面のわずかに外まで広がることで
    # 表面を確実に貫き、囲った断面がきれいに切り離せる。
    exp = 1.0 + max(0.0, props.draw_cut_expand)
    ring = [center + (p - center) * exp for p in pts]
    nrm = _loop_normal(ring)

    me = bpy.data.meshes.new(name)
    bm = bmesh.new()
    rv = [bm.verts.new(p) for p in ring]
    n = len(rv)
    edges = []
    for i in range(n):
        try:
            edges.append(bm.edges.new((rv[i], rv[(i + 1) % n])))
        except ValueError:
            pass                                          # 重複エッジはスキップ
    made = 0
    try:
        res = bmesh.ops.triangle_fill(bm, edges=edges, use_beauty=True,
                                      use_dissolve=False, normal=nrm)
        made = sum(1 for g in res.get("geom", []) if isinstance(g, bmesh.types.BMFace))
    except Exception:
        made = 0
    if made == 0:
        # フォールバック: 重心へのファン(三角化フィルが失敗した歪んだループ用)
        cv = bm.verts.new(center)
        for i in range(n):
            try:
                bm.faces.new((cv, rv[i], rv[(i + 1) % n]))
                made += 1
            except ValueError:
                pass
    if made == 0:
        bm.free()
        bpy.data.meshes.remove(me)
        return None
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(me)
    bm.free()
    me.update()
    obj = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(obj)
    obj.show_wire = True
    # なぞった素のループ(拡大前)をワールド座標で保存。座の断面として利用する。
    obj["ps_loop"] = [c for p in pts for c in (p.x, p.y, p.z)]
    return obj


def get_cut_loop(cut_obj):
    """CUT オブジェクトに保存された『なぞりループ』(ワールド座標 Vector 列)を返す。
    無ければ None。ループカット由来の刃のみ持つ。"""
    flat = cut_obj.get("ps_loop") if cut_obj is not None else None
    if not flat or len(flat) < 9:
        return None
    return [Vector((flat[i], flat[i + 1], flat[i + 2]))
            for i in range(0, len(flat) - 2, 3)]


def build_loop_prism(root_ring, tip_ring, name, link_coll=None):
    """2つのリング(根元/先端、等数のワールド座標列)から角柱状ソリッドを作る。
    側面を四角面で張り、両端は triangle_fill でフタする(中心ポールを作らないので
    ダボ軸と重なっても非多様体にならない)。座をループ断面で作るのに使う。"""
    if len(root_ring) < 3 or len(root_ring) != len(tip_ring):
        return None
    me = bpy.data.meshes.new(name)
    bm = bmesh.new()
    rv = [bm.verts.new(p) for p in root_ring]
    tv = [bm.verts.new(p) for p in tip_ring]
    n = len(rv)
    for i in range(n):
        j = (i + 1) % n
        try:
            bm.faces.new((rv[i], rv[j], tv[j], tv[i]))
        except ValueError:
            pass
    for ring in (rv, tv):
        edges = [e for i in range(n)
                 for e in (bm.edges.get((ring[i], ring[(i + 1) % n])),) if e]
        try:
            bmesh.ops.triangle_fill(bm, edges=edges, use_beauty=True,
                                    use_dissolve=False)
        except Exception:
            pass
    if not bm.faces:
        bm.free()
        bpy.data.meshes.remove(me)
        return None
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(me)
    bm.free()
    me.update()
    obj = bpy.data.objects.new(name, me)
    (link_coll or bpy.context.scene.collection).objects.link(obj)
    return obj


def _loop_seat_rings(loop, pt, n, root_off, tip_off, root_scale, tip_scale):
    """ループ断面座の根元/先端リングを計算。loop をカット平面へ射影し重心(=pt想定)
    まわりに scale して、軸 n 方向へ root_off/tip_off だけ離した2リングを返す。"""
    c = Vector((0.0, 0.0, 0.0))
    for p in loop:
        c += p
    c /= len(loop)
    rel = [(p - c) - n * ((p - c).dot(n)) for p in loop]   # 平面内オフセット
    root_c = pt + n * root_off
    tip_c = pt + n * tip_off
    root_ring = [root_c + r * root_scale for r in rel]
    tip_ring = [tip_c + r * tip_scale for r in rel]
    mean_r = sum(r.length for r in rel) / max(1, len(rel))
    return root_ring, tip_ring, mean_r


def _tangent_circle(center, normal, radius, seg=32):
    """center を中心に、normal に垂直な平面上の半径 radius の円の点列を返す。"""
    n = normal.normalized()
    a = Vector((1.0, 0.0, 0.0)) if abs(n.x) < 0.9 else Vector((0.0, 1.0, 0.0))
    t1 = n.cross(a).normalized()
    t2 = n.cross(t1).normalized()
    return [center + (t1 * math.cos(2 * math.pi * i / seg)
                      + t2 * math.sin(2 * math.pi * i / seg)) * radius
            for i in range(seg + 1)]


def _draw_cut_callback(op, context):
    """モーダル中、対象表面上に描いた3Dループとブラシ円を描画(POST_VIEW=ワールド空間)。
    ワールド座標で描くので視点を回してもループは表面に貼り付いたまま見える。"""
    pts = [Vector(p) for p in op.loop3d]
    try:
        gpu.state.blend_set('ALPHA')
        gpu.state.line_width_set(2.0)
        gpu.state.depth_test_set('NONE')
        sh = gpu.shader.from_builtin('UNIFORM_COLOR')
        sh.bind()
        if len(pts) >= 2:
            # 描画中は開いた線、確定前でもループの閉じ具合が分かるよう始点へ戻す線も薄く
            sh.uniform_float("color", (1.0, 0.55, 0.1, 0.95))
            batch_for_shader(sh, 'LINE_STRIP', {"pos": pts}).draw(sh)
            sh.uniform_float("color", (1.0, 0.55, 0.1, 0.35))
            batch_for_shader(sh, 'LINES', {"pos": [pts[-1], pts[0]]}).draw(sh)
        if pts:
            gpu.state.point_size_set(5.0)
            sh.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
            batch_for_shader(sh, 'POINTS', {"pos": pts}).draw(sh)
        # ブラシ円(カーソル直下の表面点に、サンプル間隔=ブラシサイズの円)
        loc = getattr(op, "_cursor_loc", None)
        nrm = getattr(op, "_cursor_nrm", None)
        if loc is not None and nrm is not None:
            ring = _tangent_circle(loc, nrm, op._min_step_now())
            sh.uniform_float("color", (0.2, 0.8, 1.0, 0.9))
            batch_for_shader(sh, 'LINE_STRIP', {"pos": ring}).draw(sh)
    except Exception as e:
        print("[PartSplit] draw_cut preview error:", e)
    finally:
        gpu.state.point_size_set(1.0)
        gpu.state.line_width_set(1.0)
        gpu.state.depth_test_set('LESS_EQUAL')
        gpu.state.blend_set('NONE')


class PARTSPLIT_OT_draw_cut(Operator):
    bl_idname = "partsplit.draw_cut"
    bl_label = "なぞってループカット"
    bl_description = ("対象メッシュの表面をなぞって閉ループ(円)を描くと、その内側に面を張り"
                     "外側へ少し拡大した刃(CUT_)を作る。ループで囲った断面でパーツを切り"
                     "離せる。描画中も視点を回転/ズームでき、裏側まで回り込んでなぞれる。"
                     "左ドラッグ=なぞる / 中ボタン等=視点操作 / F=ブラシサイズ変更 / "
                     "Enter=確定 / Esc=中止")
    bl_options = {'REGISTER', 'UNDO'}

    def _status(self, context):
        if self._resizing:
            context.workspace.status_text_set(
                f"[ブラシサイズ変更中] マウスを動かして調整({self._brush:.1f}%) / "
                f"クリック・F=確定 / Esc=取消し")
            return
        context.workspace.status_text_set(
            f"[なぞってループカット] 左ドラッグ=なぞる / 中ボタン・ホイール=視点 / "
            f"F=ブラシサイズ変更 / [ ]=増減({self._brush:.1f}%) / "
            f"Enter=確定 / C=クリア / Esc=中止")

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'ERROR'}, "3Dビューポート上で実行してください")
            return {'CANCELLED'}
        props = context.scene.partsplit
        target = context.active_object
        if (target is None or target.type != 'MESH'
                or target.name.startswith(props.cut_prefix)):
            self.report({'ERROR'}, "分割したい対象メッシュをアクティブにしてください")
            return {'CANCELLED'}
        self.target = target
        self.area = context.area
        self.loop3d = []            # 表面上のワールド座標ループ点
        self.drawing = False
        self._cursor_loc = None     # ブラシ円用: カーソル直下の表面点
        self._cursor_nrm = None
        self._resizing = False      # F: インタラクティブなブラシサイズ変更中か
        self._resize_depth = None   # リサイズ中の中心(奥行き基準)ワールド点
        self._brush_before = None   # リサイズ取消し用の元の値
        mn, mx = world_bbox(target)
        self._diag = max((mx - mn).length, 1e-9)
        self._brush = props.draw_cut_brush   # ブラシサイズ(対象サイズ比%)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            _draw_cut_callback, (self, context), 'WINDOW', 'POST_VIEW')
        context.window_manager.modal_handler_add(self)
        self._status(context)
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}

    def _win_region(self):
        return next((r for r in self.area.regions if r.type == 'WINDOW'), None)

    def _min_step_now(self):
        """現在のブラシサイズに対応するサンプル最小間隔(ワールド距離)。"""
        return max(self._diag * self._brush / 100.0, 1e-9)

    def _cursor_hit(self, context, event):
        """カーソル直下を対象表面へレイキャストし (loc, nrm) を返す。外れたら None。"""
        region = self._win_region()
        rv3d = self.area.spaces.active.region_3d if self.area else None
        if region is None or rv3d is None:
            return None
        co = (event.mouse_x - region.x, event.mouse_y - region.y)
        if not (0 <= co[0] <= region.width and 0 <= co[1] <= region.height):
            return None
        o, d = _screen_ray(region, rv3d, co)
        ok, loc, nrm = _raycast_target(self.target, context.evaluated_depsgraph_get(),
                                       o, d)
        return (loc, nrm) if ok else None

    def _add_point(self, loc):
        """表面点を、前点からブラシサイズ以上離れていればループに追加。"""
        if not self.loop3d or (loc - Vector(self.loop3d[-1])).length >= self._min_step_now():
            self.loop3d.append((loc.x, loc.y, loc.z))

    def _enter_resize(self, context, event):
        """F: スカルプトのようなインタラクティブなブラシサイズ変更を開始。"""
        region = self._win_region()
        rv3d = self.area.spaces.active.region_3d if self.area else None
        if region is None or rv3d is None:
            return
        # 中心(奥行き基準)= カーソル直下の表面点。無ければ対象の中心。
        if self._cursor_loc is not None:
            self._resize_depth = self._cursor_loc.copy()
        else:
            mn, mx = world_bbox(self.target)
            self._resize_depth = (mn + mx) / 2.0
            self._cursor_loc = self._resize_depth
        if self._cursor_nrm is None:
            self._cursor_nrm = (rv3d.view_rotation @ Vector((0.0, 0.0, 1.0))).normalized()
        self._brush_before = self._brush
        self._resizing = True
        self.drawing = False
        self._status(context)

    def _resize_modal(self, context, event):
        """リサイズ中のイベント処理。マウス距離をブラシ%に写す(スカルプトのF相当)。"""
        region = self._win_region()
        rv3d = self.area.spaces.active.region_3d if self.area else None
        if event.type == 'MOUSEMOVE' and region is not None and rv3d is not None:
            mouse = Vector((event.mouse_x - region.x, event.mouse_y - region.y))
            world_pt = view3d_utils.region_2d_to_location_3d(
                region, rv3d, mouse, self._resize_depth)
            world_r = (world_pt - self._resize_depth).length
            self._brush = min(15.0, max(0.1, world_r / self._diag * 100.0))
            context.scene.partsplit.draw_cut_brush = self._brush
            self._status(context)
            return {'RUNNING_MODAL'}
        if event.value == 'PRESS' and event.type in {
                'LEFTMOUSE', 'F', 'RET', 'NUMPAD_ENTER'}:
            self._resizing = False            # 確定
            self._status(context)
            return {'RUNNING_MODAL'}
        if event.value == 'PRESS' and event.type in {'ESC', 'RIGHTMOUSE'}:
            self._brush = self._brush_before   # 取消し
            context.scene.partsplit.draw_cut_brush = self._brush
            self._resizing = False
            self._status(context)
            return {'RUNNING_MODAL'}
        return {'RUNNING_MODAL'}               # リサイズ中は他を飲み込む

    def modal(self, context, event):
        if self.area:
            self.area.tag_redraw()

        # F によるブラシサイズ変更中は専用処理で完結(視点操作等は無効)
        if self._resizing:
            return self._resize_modal(context, event)

        # 視点操作(オービット/ズーム/パン)は Blender に渡す=描画中も視点を動かせる
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE',
                          'TRACKPADPAN', 'TRACKPADZOOM'} or (
                event.type in {'LEFT_ALT', 'RIGHT_ALT'} and event.value != 'RELEASE'):
            return {'PASS_THROUGH'}

        # F: インタラクティブなブラシサイズ変更を開始(スカルプトの F 相当)
        if event.type == 'F' and event.value == 'PRESS':
            self._enter_resize(context, event)
            return {'RUNNING_MODAL'}

        # ブラシサイズ調整([=小さく/頂点密、]=大きく/頂点疎)
        if event.type in {'LEFT_BRACKET', 'RIGHT_BRACKET'} and event.value == 'PRESS':
            f = 0.8 if event.type == 'LEFT_BRACKET' else 1.25
            self._brush = min(15.0, max(0.1, self._brush * f))
            context.scene.partsplit.draw_cut_brush = self._brush
            self._status(context)
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            hit = self._cursor_hit(context, event)
            self._cursor_loc = hit[0] if hit else None
            self._cursor_nrm = hit[1] if hit else None
            if self.drawing and hit is not None:
                self._add_point(hit[0])
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                self.drawing = True
                hit = self._cursor_hit(context, event)
                if hit is not None:
                    self._cursor_loc, self._cursor_nrm = hit
                    self._add_point(hit[0])
            elif event.value == 'RELEASE':
                self.drawing = False
            return {'RUNNING_MODAL'}

        if event.type == 'C' and event.value == 'PRESS':
            self.loop3d = []
            self.drawing = False
            return {'RUNNING_MODAL'}

        if event.type in {'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            return self._finish(context)

        if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            return self._cancel(context)

        return {'RUNNING_MODAL'}

    def _teardown(self, context):
        if getattr(self, "_handle", None) is not None:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            self._handle = None
        context.workspace.status_text_set(None)
        if self.area:
            self.area.tag_redraw()

    def _cancel(self, context):
        self._teardown(context)
        self.report({'INFO'}, "中止しました")
        return {'CANCELLED'}

    def _finish(self, context):
        loop = list(self.loop3d)
        self._teardown(context)
        if len(loop) < 3:
            self.report({'ERROR'},
                        "表面をなぞってループ(円)を描いてください(点が足りません)")
            return {'CANCELLED'}
        props = context.scene.partsplit
        cut = build_loop_blade(props, self.target, loop, props.cut_prefix + "draw")
        if cut is None:
            self.report({'ERROR'}, "刃を作成できませんでした")
            return {'CANCELLED'}
        # 対象=アクティブ、描いた刃も選択して即『分割を実行』できる状態にする
        bpy.ops.object.select_all(action='DESELECT')
        cut.select_set(True)
        self.target.select_set(True)
        context.view_layer.objects.active = self.target
        self.report({'INFO'},
                    f"刃 '{cut.name}' を作成。'分割を実行' で切断します")
        return {'FINISHED'}


PREVIEW_PREFIX = "PARTSPLIT_PV_"
PREVIEW_COLL = "PARTSPLIT_DowelPreview"


def _ensure_preview_collection():
    coll = bpy.data.collections.get(PREVIEW_COLL)
    if coll is None:
        coll = bpy.data.collections.new(PREVIEW_COLL)
        bpy.context.scene.collection.children.link(coll)
    return coll


def _remove_preview_objects():
    for o in list(bpy.data.objects):
        if o.name.startswith(PREVIEW_PREFIX):
            bpy.data.objects.remove(o, do_unlink=True)


def clear_dowel_preview():
    """プレビューのワイヤーとキャッシュを完全消去(連動更新も止まる)。"""
    _remove_preview_objects()
    _PREVIEW_CACHE.clear()
    coll = bpy.data.collections.get(PREVIEW_COLL)
    if coll and not coll.objects:
        bpy.data.collections.remove(coll)


def _tag_view3d_redraw():
    """全3Dビューポートに再描画を要求(プレビュー変化を即反映)。"""
    wm = bpy.context.window_manager
    if not wm:
        return
    for win in wm.windows:
        scr = win.screen
        if not scr:
            continue
        for area in scr.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def _style_preview(obj):
    obj.display_type = 'WIRE'
    obj.show_in_front = True
    obj.hide_select = True


def rebuild_dowel_preview(props):
    """キャッシュ(point/normal/area/safe_max/cap_data/area_total)から、現在の
    ダボ設定でプレビューのワイヤーを作り直す。断面再計算なしで高速=スライダー連動。"""
    _remove_preview_objects()
    if not _PREVIEW_CACHE:
        _tag_view3d_redraw()
        return 0
    coll = _ensure_preview_collection()
    count = 0
    for pt, n, area_pd, safe_max, cap_data, area_tot, seat_loop in _PREVIEW_CACHE:
        if props.dowel_flip:            # オス側(ピン・座)の表示を反対側へ
            n = -n
        dims = compute_dowel_dims(props, area_pd, safe_max)
        P = dowel_taper_params(props, dims)
        if P is None:
            continue
        use_base = props.dowel_use_base
        height = (props.base_height_factor * (2.0 * P["r_peg"])
                  if use_base else 0.0)
        seat_r = props.base_dia_factor * P["r_peg"]
        seat_tip = seat_r * (1.0 - _seat_taper(props))
        use_loop_seat = (props.base_shape == 'LOOP' and seat_loop is not None
                         and len(seat_loop) >= 3)
        if use_base and height > 0.0 and use_loop_seat:   # ループ断面座のプレビュー
            s_root = props.base_loop_scale
            s_tip = s_root * (1.0 - _seat_taper(props))
            rm, tm, _mr = _loop_seat_rings(seat_loop, pt, n, 0.0, -height,
                                           s_root, s_tip)
            sv = build_loop_prism(rm, tm, PREVIEW_PREFIX + "seat", link_coll=coll)
            if sv is not None:
                _style_preview(sv)
        elif use_base and seat_r > 0.0 and height > 0.0:  # 座(円柱/角柱)のプレビュー
            seat_top = pt
            sv = make_peg_solid(props, seat_top + (-n) * height / 2.0, n,
                                seat_r, seat_tip, height,
                                PREVIEW_PREFIX + "seat", link_coll=coll,
                                shape=props.base_shape)
            _style_preview(sv)
        base_pt = pt + (-n) * height
        pv = make_peg_solid(props, _peg_center(base_pt, n, P), n,
                            P["peg_pz"], P["peg_mz"], P["peg_len"],
                            PREVIEW_PREFIX + "dowel", link_coll=coll)
        _style_preview(pv)
        count += 1
    _tag_view3d_redraw()
    return count


# プレビューの断面計算に使う軽量プロキシの上限トライ数。重い原型でもこの程度まで
# 落として高速にブーリアンする(プレビューは配置・寸法の目安なので粗くて十分)。
PREVIEW_PROXY_TRIS = 60000


class PARTSPLIT_OT_preview_dowels(Operator):
    bl_idname = "partsplit.preview_dowels"
    bl_label = "ダボをプレビュー"
    bl_description = ("分割せずに、各切断面のダボ位置・径・深さ・テーパーを"
                      "ワイヤーフレームで表示する(実行前の確認用)。カッター周辺の"
                      "局所領域だけで計算するので重いメッシュでも高速")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.partsplit
        target = context.active_object
        if target is None or target.type != 'MESH':
            self.report({'ERROR'}, "対象メッシュをアクティブにしてください")
            return {'CANCELLED'}
        if target.name.startswith(props.cut_prefix):
            self.report({'ERROR'}, "切断面ではなく対象メッシュを選択してください")
            return {'CANCELLED'}
        cuts = collect_cuts(props, target, selected=list(
            context.selected_objects))
        if not cuts:
            self.report({'ERROR'},
                        f"'{props.cut_prefix}' で始まる切断面がありません")
            return {'CANCELLED'}

        clear_dowel_preview()        # 既存プレビューとキャッシュを消去

        # プレビューは軽量プロキシ(デシメート複製)で計算する。重い原型でも高速で、
        # 本番と同じ footprint-bounded 分割なので配置・断面はほぼ一致する。
        tmp = duplicate_obj(target, "_fas_pv_tmp")
        bpy.ops.object.select_all(action='DESELECT')
        tmp.select_set(True)
        bpy.context.view_layer.objects.active = tmp
        bpy.ops.object.transform_apply(location=True, rotation=True,
                                       scale=True)
        n0 = len(tmp.data.polygons)
        if n0 > PREVIEW_PROXY_TRIS:
            md = tmp.modifiers.new("pvdec", 'DECIMATE')
            md.decimate_type = 'COLLAPSE'
            md.ratio = PREVIEW_PROXY_TRIS / float(n0)
            bpy.ops.object.modifier_apply(modifier=md.name)
            print(f"[PartSplit] preview proxy: {n0} -> {len(tmp.data.polygons)} polys")

        # 断面計算(重い)は一度だけ行い、配置をキャッシュする
        for cut in cuts:
            co, no = cut["co"], cut["no"]
            if not aabb_overlap(tmp, cut["obj"]):
                continue
            pos, neg, blade = split_part_by_blade(props, tmp, cut, co, no,
                                                  consume=False)
            try:
                if (pos is None or neg is None
                        or is_empty_mesh(pos) or is_empty_mesh(neg)):
                    continue
                pts, _dims, area, safe_max, cap_data = compute_cut_dowels(
                    props, pos, neg, cut, co, no, blade=blade)
                seat_loop = get_cut_loop(cut["obj"])   # ループ座プレビュー用
                n_pts = max(1, len(pts))
                for i, pt in enumerate(pts):
                    n = normal_at_point(cut, pt)
                    # 土台は1カット1個なので cap_data は先頭点のみに持たせる
                    cd = cap_data if i == 0 else None
                    _PREVIEW_CACHE.append((pt.copy(), n.copy(),
                                           area / n_pts, safe_max, cd, area,
                                           seat_loop))
            finally:
                for o in (pos, neg, blade):
                    if o is not None:
                        bpy.data.objects.remove(o, do_unlink=True)

        bpy.data.objects.remove(tmp, do_unlink=True)

        # キャッシュから現在のダボ設定でワイヤーを生成
        count = rebuild_dowel_preview(props)

        bpy.ops.object.select_all(action='DESELECT')
        target.select_set(True)
        bpy.context.view_layer.objects.active = target
        self.report({'INFO'},
                    f"ダボプレビュー {count} 個を表示。サイズ変更は即反映、"
                    f"'プレビュー消去' で削除")
        return {'FINISHED'}


class PARTSPLIT_OT_clear_preview(Operator):
    bl_idname = "partsplit.clear_preview"
    bl_label = "プレビュー消去"
    bl_description = "ダボのプレビュー表示を削除する"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        clear_dowel_preview()
        self.report({'INFO'}, "ダボプレビューを消去しました")
        return {'FINISHED'}


# リセット対象のダボ関連プロパティ
DOWEL_PROP_NAMES = (
    "dowel_flip", "dowel_shape", "dowel_taper",
    "dowel_use_base", "base_shape", "base_height_factor", "base_dia_factor",
    "base_loop_scale", "base_taper", "base_clearance",
    "dowel_auto_size", "dowel_area_ratio", "dowel_depth_factor",
    "dowel_base_factor", "dowel_min_mm", "dowel_max_mm",
    "dowel_diameter", "peg_depth", "base_depth",
    "dowel_clearance", "clamp_to_part", "peg_use_boolean",
    "axis_guide", "axis_guide_dia",
)


class PARTSPLIT_OT_reset_dowel_params(Operator):
    bl_idname = "partsplit.reset_dowel_params"
    bl_label = "ダボ設定を初期値に"
    bl_description = "ダボ関連のパラメータをすべて既定値に戻す"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.partsplit
        for name in DOWEL_PROP_NAMES:
            try:
                props.property_unset(name)
            except Exception:
                pass
        if _PREVIEW_CACHE:          # プレビュー中なら連動更新
            _schedule_preview_rebuild()
        self.report({'INFO'}, "ダボ設定を初期値に戻しました")
        return {'FINISHED'}


class PARTSPLIT_OT_split(Operator):
    bl_idname = "partsplit.split"
    bl_label = "分割を実行"
    bl_description = "アクティブなメッシュを切断面で分割しダボを生成"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.partsplit
        target = context.active_object
        if target is None or target.type != 'MESH':
            self.report({'ERROR'}, "分割するメッシュをアクティブにしてください")
            return {'CANCELLED'}
        if target.name.startswith(props.cut_prefix):
            self.report({'ERROR'}, "切断面ではなく対象メッシュを選択してください")
            return {'CANCELLED'}
        clear_dowel_preview()      # プレビューが残っていれば消す
        try:
            n = run_split(props, target)
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        self.report({'INFO'}, f"完了: {n} パーツを生成しました")
        return {'FINISHED'}


# ============================================================
# UI パネル
# ============================================================

# ------------------------------------------------------------
# 描画ヘルパー: サイドバーのサブパネルとポップアップで共用する。
# それぞれ 1 セクションを layout へ描くだけ(スクロール削減のため分割)。
# ------------------------------------------------------------

def _draw_actions(layout, props):
    """最重要の実行ボタン(常に上部・スクロール不要)。"""
    col = layout.column(align=True)
    col.scale_y = 1.3
    row = col.row(align=True)
    row.operator("partsplit.preview_dowels", icon='HIDE_OFF')
    row.operator("partsplit.clear_preview", text="", icon='TRASH')
    col.operator("partsplit.split", icon='MOD_BOOLEAN')
    # プレビュー中は実際に作られるダボ径(mm)を表示
    if _PREVIEW_CACHE:
        e = _PREVIEW_CACHE[0]
        d = compute_dowel_dims(props, e[2], e[3])
        col.label(text="→ 実ダボ径 ≈ %.1f mm"
                  % (2.0 * d[0] * _unit_mm_per_bu(props)), icon='INFO')


def _draw_cut(layout, props):
    col = layout.column(align=True)
    col.label(text="なぞってループカット:")
    col.operator("partsplit.draw_cut", text="表面をなぞって円で囲う",
                 icon='GREASEPENCIL')
    col.prop(props, "draw_cut_brush")
    col.prop(props, "draw_cut_expand")
    col.label(text="表面をなぞり円で囲む。視点を回して裏まで可。囲った断面で切断",
              icon='INFO')
    col.separator()
    col.label(text=f"手動: 面付きメッシュを '{props.cut_prefix}' 始まりにしても刃になる")

    layout.prop(props, "selected_cuts_only")
    if props.selected_cuts_only:
        layout.label(text="アクティブ=分割元 / 他の選択=刃", icon='INFO')
    else:
        layout.prop(props, "cut_prefix")
    layout.prop(props, "part_prefix")
    layout.prop(props, "auto_unit")
    if props.auto_unit:
        layout.label(text=f"→ 1単位 = {_unit_mm_per_bu(props):.1f} mm", icon='INFO')
    else:
        layout.prop(props, "unit_scale")
    layout.prop(props, "keep_original")
    layout.prop(props, "solver")
    layout.prop(props, "kerf_mm")
    layout.prop(props, "blade_subdiv")
    layout.label(text="切断面を平滑化(Subdiv)→厚み付け(Solidify)→ブーリアン分割",
                 icon='INFO')
    layout.prop(props, "remove_debris")
    rsub = layout.column(align=True)
    rsub.enabled = props.remove_debris
    rsub.prop(props, "debris_max_tris")


def _draw_dowel(layout, props):
    row = layout.row(align=True)
    row.prop(props, "add_dowels")
    row.operator("partsplit.reset_dowel_params", text="", icon='LOOP_BACK')
    sub = layout.column(align=True)
    sub.enabled = props.add_dowels
    sub.prop(props, "dowel_live", icon='GEOMETRY_NODES')
    sub.prop(props, "dowel_flip", icon='ARROW_LEFTRIGHT')
    sub.prop(props, "dowel_shape")
    sub.prop(props, "dowel_taper")
    sub.prop(props, "dowel_auto_size")
    if props.dowel_auto_size:
        sub.prop(props, "dowel_area_ratio")
        sub.prop(props, "dowel_depth_factor")
        sub.prop(props, "dowel_base_factor")
        r = sub.row(align=True)
        r.prop(props, "dowel_min_mm")
        r.prop(props, "dowel_max_mm")
    else:
        sub.prop(props, "dowel_diameter")
        sub.prop(props, "peg_depth")
        sub.prop(props, "base_depth")
    if _PREVIEW_CACHE:
        e = _PREVIEW_CACHE[0]
        d = compute_dowel_dims(props, e[2], e[3])
        sub.label(text="→ 実ダボ径 ≈ %.1f mm"
                  % (2.0 * d[0] * _unit_mm_per_bu(props)), icon='INFO')
    sub.prop(props, "dowel_clearance")
    sub.prop(props, "clamp_to_part")
    sub.separator()
    sub.prop(props, "dowel_use_base")
    bsub = sub.column(align=True)
    bsub.enabled = props.dowel_use_base
    bsub.prop(props, "base_shape")
    bsub.prop(props, "base_height_factor")
    if props.base_shape == 'LOOP':
        bsub.prop(props, "base_loop_scale")
    else:
        bsub.prop(props, "base_dia_factor")
    bsub.prop(props, "base_taper")
    bsub.prop(props, "base_clearance")
    sub.separator()
    sub.prop(props, "axis_guide")
    gsub = sub.column(align=True)
    gsub.enabled = props.axis_guide
    gsub.prop(props, "axis_guide_dia")
    sub.separator()
    adv = sub.column(align=True)
    adv.label(text="生成方式(通常は既定のまま):", icon='SETTINGS')
    adv.prop(props, "peg_use_boolean")


class PARTSPLIT_OT_export_parts(Operator):
    bl_idname = "partsplit.export_parts"
    bl_label = "パーツを一括エクスポート"
    bl_description = ("パーツ接頭辞で始まる全オブジェクトを、出力先へ1つずつ書き出す。"
                     "分割が終わってから押す")
    bl_options = {'REGISTER'}

    def execute(self, context):
        import os
        props = context.scene.partsplit
        parts = [o for o in bpy.data.objects
                 if o.type == 'MESH' and o.name.startswith(props.part_prefix)]
        if not parts:
            self.report({'ERROR'},
                        f"'{props.part_prefix}' で始まるパーツがありません")
            return {'CANCELLED'}
        out_dir = bpy.path.abspath(props.export_dir)
        try:
            os.makedirs(out_dir, exist_ok=True)
        except OSError as e:
            self.report({'ERROR'}, f"出力先を作成できません: {e}")
            return {'CANCELLED'}
        ext = props.export_format.lower()
        for p in parts:
            bpy.ops.object.select_all(action='DESELECT')
            p.select_set(True)
            context.view_layer.objects.active = p
            path = os.path.join(out_dir, f"{p.name}.{ext}")
            # apply_modifiers=True で非破壊(GN)ダボも書き出しに反映する
            if props.export_format == 'STL':
                bpy.ops.wm.stl_export(filepath=path, export_selected_objects=True,
                                      apply_modifiers=True)
            else:
                bpy.ops.wm.obj_export(filepath=path, export_selected_objects=True,
                                      apply_modifiers=True)
        self.report({'INFO'},
                    f"{len(parts)} パーツを {out_dir} へエクスポートしました")
        return {'FINISHED'}


def _draw_export(layout, props):
    col = layout.column(align=True)
    col.prop(props, "export_dir")
    col.prop(props, "export_format")
    layout.operator("partsplit.export_parts", icon='EXPORT')
    layout.label(text=f"'{props.part_prefix}' で始まる全パーツを書き出します",
                 icon='INFO')


class PARTSPLIT_OT_popup(Operator):
    bl_idname = "partsplit.popup"
    bl_label = "PartSplit パネル"
    bl_description = ("全設定と実行ボタンを、前面のフローティングウィンドウにまとめて"
                     "表示する。スクロール不要。作業が終わったらウィンドウ外を"
                     "クリック/Escで閉じる")
    bl_options = {'REGISTER'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=760)

    def draw(self, context):
        props = context.scene.partsplit
        layout = self.layout
        _draw_actions(layout, props)
        layout.separator()
        # 3カラムに並べてスクロールを不要にする
        split = layout.split(factor=0.34)
        c1 = split.column()
        rest = split.split(factor=0.5)
        c2 = rest.column()
        c3 = rest.column()
        c1.box().label(text="切断面・基本", icon='MOD_BOOLEAN')
        _draw_cut(c1.box().column(), props)
        c2.box().label(text="ダボ", icon='EMPTY_SINGLE_ARROW')
        _draw_dowel(c2.box().column(), props)
        c3.box().label(text="エクスポート", icon='EXPORT')
        _draw_export(c3.box().column(), props)

    def execute(self, context):
        return {'FINISHED'}


class PARTSPLIT_PT_panel(Panel):
    bl_label = "PartSplit"
    bl_idname = "PARTSPLIT_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PartSplit"

    def draw(self, context):
        layout = self.layout
        props = context.scene.partsplit
        # 前面フローティングウィンドウで開くボタン(スクロール回避)
        layout.operator("partsplit.popup", icon='WINDOW', text="ポップアップで開く")
        layout.separator()
        _draw_actions(layout, props)


class _PARTSPLIT_SubPanel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PartSplit"
    bl_parent_id = "PARTSPLIT_PT_panel"
    bl_options = {'DEFAULT_CLOSED'}


class PARTSPLIT_PT_cut(_PARTSPLIT_SubPanel, Panel):
    bl_label = "切断面・基本"
    bl_idname = "PARTSPLIT_PT_cut"

    def draw(self, context):
        _draw_cut(self.layout, context.scene.partsplit)


class PARTSPLIT_PT_dowel(_PARTSPLIT_SubPanel, Panel):
    bl_label = "ダボ"
    bl_idname = "PARTSPLIT_PT_dowel"

    def draw(self, context):
        _draw_dowel(self.layout, context.scene.partsplit)


class PARTSPLIT_PT_export(_PARTSPLIT_SubPanel, Panel):
    bl_label = "エクスポート"
    bl_idname = "PARTSPLIT_PT_export"

    def draw(self, context):
        _draw_export(self.layout, context.scene.partsplit)


# ============================================================
# 登録
# ============================================================

classes = (PARTSPLIT_Props, PARTSPLIT_OT_draw_cut,
           PARTSPLIT_OT_preview_dowels, PARTSPLIT_OT_clear_preview,
           PARTSPLIT_OT_reset_dowel_params, PARTSPLIT_OT_split,
           PARTSPLIT_OT_export_parts, PARTSPLIT_OT_popup,
           PARTSPLIT_PT_panel, PARTSPLIT_PT_cut, PARTSPLIT_PT_dowel, PARTSPLIT_PT_export)


def register():
    for c in classes:
        try:
            bpy.utils.register_class(c)
        except Exception:
            bpy.utils.unregister_class(c)
            bpy.utils.register_class(c)
    bpy.types.Scene.partsplit = bpy.props.PointerProperty(type=PARTSPLIT_Props)


def unregister():
    try:
        if bpy.app.timers.is_registered(_preview_rebuild_timer):
            bpy.app.timers.unregister(_preview_rebuild_timer)
    except Exception:
        pass
    try:
        clear_dowel_preview()
    except Exception:
        pass
    try:
        del bpy.types.Scene.partsplit
    except Exception:
        pass
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass


if __name__ == "__main__":
    register()
