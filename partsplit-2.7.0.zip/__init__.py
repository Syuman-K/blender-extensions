"""PartSplit — 拡張機能(Extension)エントリポイント。

Blender 4.2+/5.0 の拡張機能はマニフェスト(blender_manifest.toml)と
`__init__.py` を必要とする。本体は partsplit_addon.py にあるため、
ここから register / unregister を再公開する。
"""

from . import partsplit_addon


def register():
    partsplit_addon.register()


def unregister():
    partsplit_addon.unregister()
