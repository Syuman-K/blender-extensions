"""Operators wiring the UI to the core remesh pipeline."""

import bpy
from bpy.props import EnumProperty
from bpy.types import Operator

from . import core

# プリセット値。PRESPLIT はガレージキットの分割(PartSplit)前の下準備を想定:
# サブディビ/マルチレゾ適用後の高密度メッシュを、印刷品質を保ちつつ
# boolean 分割・undo が軽快に動く密度まで落とす。値はフィギュア実制作
# (eula, 2026-07)で分割作業が快適だった密度(パーツ合計 約500万tris)からの逆算。
# auto_detail は 256^3 ≒ 1,680万セルでボクセル安全上限(3,000万)内に収まる最大級の値。
_PRESETS = {
    'PRESPLIT': dict(
        voxel_mode='AUTO',
        auto_detail=256,
        merge_mode='INTERSECT',
        merge_tol=0.0,
        fill_holes=True,
        use_decimate=True,
        decimate_ratio=0.5,
        min_tris=1000,
        triangulate=False,
        smooth_shade=False,
        keep_original=True,
    ),
}

# DEFAULT リセットで初期値に戻すプロパティ群。
_RESETTABLE = (
    "voxel_mode", "auto_detail", "voxel_size", "merge_mode", "merge_tol",
    "fill_holes", "use_decimate", "decimate_ratio", "min_tris",
    "use_density_map", "density_threshold", "triangulate", "smooth_shade",
    "keep_original",
)


class EVENMESH_OT_apply_preset(Operator):
    bl_idname = "evenmesh.apply_preset"
    bl_label = "プリセットを適用"
    bl_description = "EvenMesh の設定をプリセット値にする(メッシュはまだ変更しない)"
    bl_options = {'REGISTER', 'UNDO'}

    preset: EnumProperty(
        name="プリセット",
        items=[
            ('PRESPLIT', "分割前の密度統一",
             "分割作業(PartSplit)前の下準備。サブディビ適用後の高密度メッシュを、"
             "印刷品質を保ちながら分割・undo が軽くなる密度へ統一する設定: "
             "自動解像度(ディテール256)+ Collapse 削減 0.5、交差パーツのみ結合、"
             "元オブジェクトは保持"),
            ('DEFAULT', "初期値に戻す", "全設定をアドインストール時の初期値に戻す"),
        ],
        default='PRESPLIT',
    )

    def execute(self, context):
        st = context.scene.evenmesh
        if self.preset == 'DEFAULT':
            for name in _RESETTABLE:
                st.property_unset(name)
            self.report({'INFO'}, "EvenMesh: 設定を初期値に戻しました")
            return {'FINISHED'}
        for name, value in _PRESETS[self.preset].items():
            setattr(st, name, value)
        self.report(
            {'INFO'},
            "EvenMesh: 分割前プリセットを適用しました — 対象を選択して"
            "「見積もり」で三角形数を確認し、「リメッシュ」を実行してください")
        return {'FINISHED'}


def _has_input(context):
    st = context.scene.evenmesh
    if st.scope == 'ALL':
        return any(o.type == 'MESH' for o in context.view_layer.objects)
    return any(o.type == 'MESH' for o in context.selected_objects)


class EVENMESH_OT_estimate(Operator):
    bl_idname = "evenmesh.estimate"
    bl_label = "見積もり"
    bl_description = ("使用されるボクセルサイズと現在の三角形数を、"
                      "メッシュを変更せずに表示する")
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return _has_input(context)

    def execute(self, context):
        st = context.scene.evenmesh
        objs = core.gather_objects(context, st.scope)
        if not objs:
            self.report({'WARNING'}, "処理対象のメッシュがありません")
            return {'CANCELLED'}
        voxel = core.compute_voxel_size(st, objs)
        groups = core.group_objects(objs, st.merge_mode, st.merge_tol)
        total = sum(core.tri_count(o.data) for o in objs)
        # ボクセルが細かすぎて安全上限に達するオブジェクトがあれば警告する。
        clamped = [o.name for o in objs
                   if core.safe_voxel_size(o, voxel)[1]]
        if clamped:
            self.report(
                {'WARNING'},
                "EvenMesh: ボクセル {:.4f} は {} 個のオブジェクトに対して"
                "細かすぎるため、フリーズ防止で自動的に粗くされます"
                "(例: '{}')。制御したい場合はボクセルサイズを大きく / "
                "ディテールを下げてください。".format(
                    voxel, len(clamped), clamped[0]))
        else:
            extra = ""
            if st.use_decimate:
                extra = " → デシメート後 約 {:,} 三角形".format(
                    int(round(total * st.decimate_ratio)))
            self.report(
                {'INFO'},
                "EvenMesh: {} オブジェクト → {} グループ, ボクセル {:.4f}, "
                "現在 {:,} 三角形{}".format(
                    len(objs), len(groups), voxel, total, extra))
        return {'FINISHED'}


class EVENMESH_OT_preview(Operator):
    bl_idname = "evenmesh.preview"
    bl_label = "プレビュー"
    bl_description = ("コピー上でリメッシュのライブプレビューを表示する。"
                      "元のオブジェクトは非表示になり、クリアまたは確定時に戻る")
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return core.preview_active() or _has_input(context)

    def execute(self, context):
        st = context.scene.evenmesh
        try:
            results, voxel = core.build_preview(context, st)
        except RuntimeError as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        except Exception as exc:  # noqa: BLE001 - surface any failure to the user
            self.report({'ERROR'}, "EvenMesh プレビュー失敗: {}".format(exc))
            return {'CANCELLED'}

        total = sum(core.tri_count(o.data) for o in results)
        self.report({'INFO'},
                    "EvenMesh プレビュー: ボクセル {:.4f}, {:,} 三角形".format(
                        voxel, total))
        return {'FINISHED'}


class EVENMESH_OT_clear_preview(Operator):
    bl_idname = "evenmesh.clear_preview"
    bl_label = "プレビューをクリア"
    bl_description = "プレビューを削除して元のオブジェクトを復元する"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return core.preview_active()

    def execute(self, context):
        core.clear_preview(context)
        return {'FINISHED'}


class EVENMESH_OT_paint_density(Operator):
    bl_idname = "evenmesh.paint_density"
    bl_label = "密度を塗る"
    bl_description = ("アクティブオブジェクトに密度頂点グループを追加して"
                      "ウェイトペイントに入る。ディテールを残したい場所を塗る")
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        if core.preview_active():
            self.report({'WARNING'},
                        "密度マップを塗る前にプレビューをクリアしてください")
            return {'CANCELLED'}
        vg = core.ensure_density_group(obj)
        obj.vertex_groups.active_index = vg.index
        context.scene.evenmesh.use_density_map = True
        if context.mode != 'PAINT_WEIGHT':
            bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
        self.report({'INFO'}, "'{}' に密度を塗っています".format(vg.name))
        return {'FINISHED'}


class EVENMESH_OT_remesh(Operator):
    bl_idname = "evenmesh.remesh"
    bl_label = "リメッシュ"
    bl_description = ("シーン全体のポリゴン密度を均一化する: 交差オブジェクトを"
                      "結合し、1つの密度でボクセルリメッシュ、Collapse デシメートで"
                      "ポリゴン削減。プレビュー中ならそれを確定する。"
                      "グループごとに進捗バー付きで実行(Esc でキャンセル)")
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    _gen = None

    @classmethod
    def poll(cls, context):
        return core.preview_active() or _has_input(context)

    def _report_result(self, results, voxel):
        total = sum(core.tri_count(o.data) for o in results)
        self.report(
            {'INFO'},
            "EvenMesh: {} オブジェクト, ボクセル {:.4f}, 合計 {:,} 三角形".format(
                len(results), voxel, total))

    # 同期パス: プレビュー確定、ヘッドレス、または EXEC_DEFAULT。
    def execute(self, context):
        st = context.scene.evenmesh
        try:
            results, voxel = core.process(context, st)
        except RuntimeError as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        except Exception as exc:  # noqa: BLE001 - surface any failure to the user
            self.report({'ERROR'}, "EvenMesh 失敗: {}".format(exc))
            return {'CANCELLED'}
        self._report_result(results, voxel)
        return {'FINISHED'}

    # Responsive path: process one group per timer tick with a progress bar.
    def invoke(self, context, event):
        if core.preview_active() or context.window is None:
            return self.execute(context)     # finalise / headless -> synchronous
        st = context.scene.evenmesh
        try:
            self._gen = core.iter_apply(context, st)
        except RuntimeError as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        self._done = 0
        self._total = 0
        wm = context.window_manager
        wm.progress_begin(0.0, 1.0)
        self._timer = wm.event_timer_add(0.01, window=context.window)
        wm.modal_handler_add(self)
        self._set_status(context)
        return {'RUNNING_MODAL'}

    def _set_status(self, context):
        n = self._total or 1
        filled = int(round(20 * self._done / n))
        bar = "█" * filled + "░" * (20 - filled)
        pct = int(round(100 * self._done / n)) if self._total else 0
        try:
            context.workspace.status_text_set(
                "EvenMesh: [{}] {}/{} グループ ({}%)  Esc でキャンセル".format(
                    bar, self._done, self._total, pct))
        except Exception:
            pass

    def modal(self, context, event):
        if event.type == 'ESC':
            self._cleanup(context)
            self.report({'WARNING'},
                        "EvenMesh をキャンセルしました({} グループ完了)".format(
                            self._done))
            return {'CANCELLED'}
        if event.type != 'TIMER':
            return {'RUNNING_MODAL'}
        try:
            self._done, self._total = next(self._gen)
            context.window_manager.progress_update(
                self._done / (self._total or 1))
            self._set_status(context)
        except StopIteration as stop:
            results, voxel = stop.value if stop.value else ([], 0.0)
            self._cleanup(context)
            self._report_result(results, voxel)
            return {'FINISHED'}
        except Exception as exc:  # noqa: BLE001
            self._cleanup(context)
            self.report({'ERROR'}, "EvenMesh 失敗: {}".format(exc))
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _cleanup(self, context):
        wm = context.window_manager
        if self._timer is not None:
            wm.event_timer_remove(self._timer)
            self._timer = None
        try:
            wm.progress_end()
        except Exception:
            pass
        try:
            context.workspace.status_text_set(None)
        except Exception:
            pass


CLASSES = (
    EVENMESH_OT_apply_preset,
    EVENMESH_OT_estimate,
    EVENMESH_OT_preview,
    EVENMESH_OT_clear_preview,
    EVENMESH_OT_paint_density,
    EVENMESH_OT_remesh,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    core.reset_preview_state()
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
