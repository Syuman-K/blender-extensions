"""EvenMesh — Blender add-on (extension).

Remesh objects so that polygon density is unified across the scene:

* a single scene-wide voxel size makes density (triangles per surface area)
  consistent, so large objects get more polygons and small ones fewer;
* a collapse decimation then reduces the polygon count to a target ratio,
  with painted density-map regions weighting the collapse so they keep detail;
* intersecting objects are merged into one watertight mesh;
* a minimum-triangle floor keeps small, detailed parts from collapsing.

Registered as a Blender 4.2+/5.0 extension; see blender_manifest.toml.
"""

from . import operators, properties, ui


def register():
    properties.register()
    operators.register()
    ui.register()


def unregister():
    ui.unregister()
    operators.unregister()
    properties.unregister()
