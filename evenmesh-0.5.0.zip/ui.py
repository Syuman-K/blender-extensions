"""N-panel UI for EvenMesh (View3D > Sidebar > EvenMesh)."""

import bpy
from bpy.types import Panel

from . import core

_CATEGORY = "EvenMesh"


class EVENMESH_PT_main(Panel):
    bl_idname = "EVENMESH_PT_main"
    bl_label = "EvenMesh"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = _CATEGORY

    def draw(self, context):
        st = context.scene.evenmesh
        layout = self.layout

        layout.prop(st, "scope", expand=True)

        box = layout.box()
        box.label(text="プリセット", icon='PRESET')
        row = box.row(align=True)
        op = row.operator("evenmesh.apply_preset",
                          text="分割前の密度統一", icon='MOD_DECIM')
        op.preset = 'PRESPLIT'
        op = row.operator("evenmesh.apply_preset", text="", icon='LOOP_BACK')
        op.preset = 'DEFAULT'

        box = layout.box()
        box.label(text="解像度(シーン密度)", icon='MOD_REMESH')
        box.prop(st, "voxel_mode", expand=True)
        objs = core.gather_objects(context, st.scope)
        if st.voxel_mode == 'AUTO':
            box.prop(st, "auto_detail")
            if objs:
                box.label(text="ボクセルサイズ: {:.4f}".format(
                    core.compute_voxel_size(st, objs)))
        else:
            box.prop(st, "voxel_size")
            box.label(text="= 実スケールでのディテール/面サイズ", icon='INFO')
        # 解像度がフリーズ防止の安全上限に達する場合は警告する。
        if objs:
            voxel = core.compute_voxel_size(st, objs)
            if any(core.safe_voxel_size(o, voxel)[1] for o in objs):
                box.label(text="細かすぎます — 自動で粗くします(フリーズ防止)",
                          icon='ERROR')
        box.prop(st, "min_tris")

        box = layout.box()
        box.label(text="結合", icon='MOD_BOOLEAN')
        box.prop(st, "merge_mode", text="")
        if st.merge_mode == 'INTERSECT':
            box.prop(st, "merge_tol")
        box.prop(st, "fill_holes")

        box = layout.box()
        box.label(text="メッシュ削減 (Collapse)", icon='MOD_DECIM')
        box.prop(st, "use_decimate")
        sub = box.column(align=True)
        sub.enabled = st.use_decimate
        sub.prop(st, "decimate_ratio", slider=True)
        if st.use_decimate and objs:
            before = sum(core.tri_count(o.data) for o in objs)
            after = int(round(before * st.decimate_ratio))
            sub.label(text="約 {:,} → {:,} 三角形".format(before, after),
                      icon='MESH_DATA')

        box = layout.box()
        box.label(text="密度マップ", icon='BRUSH_DATA')
        box.prop(st, "use_density_map")
        sub = box.column(align=True)
        sub.enabled = st.use_density_map
        sub.prop(st, "density_threshold")
        obj = context.active_object
        has_group = (obj is not None and obj.type == 'MESH'
                     and core.DENSITY_GROUP in obj.vertex_groups)
        sub.operator(
            "evenmesh.paint_density",
            text="密度を塗り直す" if has_group else "密度を塗る",
            icon='BRUSH_DATA')

        box = layout.box()
        box.label(text="出力", icon='OUTPUT')
        row = box.row(align=True)
        row.prop(st, "triangulate", toggle=True)
        row.prop(st, "smooth_shade", toggle=True)
        box.prop(st, "keep_original")

        box = layout.box()
        box.label(text="プレビュー", icon='HIDE_OFF')
        active = core.preview_active()
        row = box.row(align=True)
        row.operator("evenmesh.preview",
                     text="プレビュー更新" if active else "プレビュー",
                     icon='HIDE_OFF')
        row.operator("evenmesh.clear_preview", text="", icon='X')
        box.prop(st, "live_preview")
        if active:
            box.label(text="プレビュー中 — リメッシュで確定", icon='INFO')

        col = layout.column(align=True)
        col.operator("evenmesh.estimate", icon='INFO')
        col.operator("evenmesh.remesh",
                     text="プレビューを確定" if active else "リメッシュ",
                     icon='MOD_REMESH')


CLASSES = (
    EVENMESH_PT_main,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
