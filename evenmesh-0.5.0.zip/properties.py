"""EvenMesh のシーンレベル設定。"""

import bpy
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
)
from bpy.types import PropertyGroup


def _preview_update(self, context):
    """設定変更時にライブプレビューを(デバウンスして)再構築する。"""
    if self.live_preview:
        from . import core
        core.schedule_preview_rebuild()


class EvenMeshSettings(PropertyGroup):
    # --- 処理対象 ---
    scope: EnumProperty(
        name="対象",
        items=[
            ('SELECTED', "選択", "選択中のメッシュオブジェクトを処理"),
            ('ALL', "全メッシュ", "シーン内の全メッシュオブジェクトを処理"),
        ],
        default='SELECTED',
        update=_preview_update,
    )

    # --- 基準解像度(シーン全体の密度を決める) ---
    voxel_mode: EnumProperty(
        name="解像度",
        items=[
            ('AUTO', "自動",
             "最大オブジェクトの寸法からボクセルサイズを算出し、"
             "シーン全体で密度を揃える"),
            ('MANUAL', "手動", "シーン単位で絶対ボクセルサイズを指定"),
        ],
        default='AUTO',
        update=_preview_update,
    )
    auto_detail: IntProperty(
        name="ディテール",
        default=48, min=4, soft_max=512,
        description="最大オブジェクトの寸法に対するボクセル分割数。"
                    "大きいほど細かくなる。この1つの値を全オブジェクトに"
                    "適用することで、シーン全体の密度が均一化される",
        update=_preview_update)
    voxel_size: FloatProperty(
        name="ボクセルサイズ",
        default=0.05, min=1e-5, soft_max=1.0, precision=4, unit='LENGTH',
        description="実スケールでの絶対ボクセルサイズ(シーンの単位を印刷"
                    "サイズに合わせておけば、これがディテール/面のサイズ mm "
                    "になる)。小さいほど細かく重くなる。全オブジェクトに適用され、"
                    "安全上限を超える場合はオブジェクトごとに自動的に粗くなる",
        update=_preview_update)

    # --- 結合 / 水密化 ---
    merge_mode: EnumProperty(
        name="結合",
        items=[
            ('INTERSECT', "交差のみ",
             "バウンディングボックスが重なるオブジェクトを1つの水密メッシュに"
             "結合する。離れているオブジェクトは独立のまま"),
            ('ALL', "全て結合",
             "処理対象の全オブジェクトを1つの水密メッシュに結合する"),
            ('NONE', "なし", "各オブジェクトを独立してリメッシュする"),
        ],
        default='INTERSECT',
        update=_preview_update,
    )
    merge_tol: FloatProperty(
        name="重なり許容量",
        default=0.0, min=0.0, soft_max=1.0, precision=4, unit='LENGTH',
        description="重なり判定の際に各バウンディングボックスをこの量だけ"
                    "拡大する(交差のみモード)",
        update=_preview_update)
    fill_holes: BoolProperty(
        name="穴を自動で埋める", default=True,
        description="水密でないメッシュの境界ループ(穴)をリメッシュ前に"
                    "面で塞ぐ。穴あきのままボクセル化すると薄い二重殻に"
                    "なったり体積が消えたりするのを防ぐ",
        update=_preview_update)

    # --- メッシュ削減(Collapse デシメートでポリゴン数を減らす) ---
    use_decimate: BoolProperty(
        name="Collapse 削減", default=True,
        description="リメッシュ後に、Decimate モディファイアの Collapse と"
                    "同じ方法でポリゴン数を指定比率まで削減する。"
                    "密度マップを塗った領域は削減から保護される",
        update=_preview_update)
    decimate_ratio: FloatProperty(
        name="比率",
        default=0.5, min=0.0, max=1.0, precision=4,
        description="残すポリゴン(三角形)の割合。0.5 でおよそ半分になる。"
                    "Decimate モディファイアの Ratio と同じ意味",
        update=_preview_update)

    # --- 小さいパーツの例外 ---
    min_tris: IntProperty(
        name="最小三角形数",
        default=100, min=0, soft_max=100000,
        description="この三角形数を下回ってしまう小さなパーツは、"
                    "より細かいボクセルでリメッシュしてディテールを残す",
        update=_preview_update)

    # --- 密度マップ(ディテールを残す場所を塗る) ---
    use_density_map: BoolProperty(
        name="密度マップを使用", default=False,
        description="頂点グループ '" + "EvenMeshDensity" + "' に塗った領域を"
                    "Collapse 削減から保護し、リメッシュの密度を"
                    "維持する",
        update=_preview_update)
    density_threshold: FloatProperty(
        name="しきい値",
        default=0.5, min=0.0, max=1.0, precision=2,
        description="この値以上のウェイトを高密度(削減から保護)"
                    "として扱う",
        update=_preview_update)

    # --- 出力オプション ---
    triangulate: BoolProperty(
        name="三角面化", default=False,
        description="最終メッシュを三角面化する",
        update=_preview_update)
    smooth_shade: BoolProperty(
        name="スムーズシェード", default=False,
        description="結果をスムーズシェーディングにする",
        update=_preview_update)
    keep_original: BoolProperty(
        name="元を保持", default=False,
        description="コピーに対して処理し、元のオブジェクトはそのまま残す")

    # --- ライブプレビュー ---
    live_preview: BoolProperty(
        name="自動更新", default=True,
        description="設定を変更したときにプレビューを自動で再構築する")


def register():
    bpy.utils.register_class(EvenMeshSettings)
    bpy.types.Scene.evenmesh = PointerProperty(type=EvenMeshSettings)


def unregister():
    del bpy.types.Scene.evenmesh
    bpy.utils.unregister_class(EvenMeshSettings)
