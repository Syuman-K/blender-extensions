"""Core remesh algorithms for EvenMesh.

The pipeline, per group of objects:

0. bake every object's modifier stack (evaluated at viewport settings) so
   subsurf/multires/mirror etc. contribute to the result without the user
   pre-applying them -- this also covers objects merged into a group, whose
   modifiers would otherwise be silently dropped by the raw-mesh join;
1. optionally join intersecting objects into one mesh (bmesh merge, no ops so
   it is safe to run from a timer);
1b. fill boundary loops (holes) so open meshes enclose a well-defined volume
   before voxelisation -- without this, voxel remesh turns an open shell into
   a thin double-walled surface or loses the volume entirely;
2. voxel-remesh at a scene-wide voxel size (watertight + uniform density),
   refining the voxel for tiny parts that would fall below a triangle floor;
3. collapse-decimate to a target ratio (same behaviour as the Decimate
   modifier in Collapse mode) to shed polygons down to a budget -- regions
   painted into the density map weight the collapse so they resist it and keep
   their full remesh density;
4. clean up loose geometry and recalculate normals.

Also hosts the live-preview machinery: copies of the sources are remeshed into
tagged preview objects, and a debounced timer rebuilds them while the user
tweaks settings.  Functions take explicit arguments and avoid UI state so they
can be exercised head-less from a test script.
"""

import bmesh
import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from mathutils.interpolate import poly_3d_calc

# Custom property stamped on every object EvenMesh produces.
RESULT_TAG = "evenmesh_result"
# Custom property stamped on live-preview objects.
PREVIEW_TAG = "evenmesh_preview"
# Vertex group the density map is painted into.
DENSITY_GROUP = "EvenMeshDensity"

# Voxel-remesh triangle count grows roughly as area / voxel**2, so shrinking
# the voxel by this factor multiplies the count by ~1/factor**2 each retry.
_REFINE_FACTOR = 0.6
_REFINE_MAX_ITER = 6

# Safety cap on the voxel grid. If the requested voxel size is so fine that the
# grid would exceed this many cells for an object, Blender can freeze or crash
# while voxelising. We coarsen the voxel size just enough to stay under the cap.
_VOXEL_CAP = 30_000_000


def safe_voxel_size(obj, voxel_size):
    """Coarsen ``voxel_size`` for ``obj`` so its voxel grid stays under the cap.

    Returns ``(size, clamped)``. ``clamped`` is True when the size was raised.
    """
    d = obj.dimensions
    vs = max(voxel_size, 1e-9)
    est = (d.x / vs) * (d.y / vs) * (d.z / vs)
    if est > _VOXEL_CAP and est > 0.0:
        vs *= (est / _VOXEL_CAP) ** (1.0 / 3.0)
        return vs, True
    return vs, False


def voxel_grid_estimate(obj, voxel_size):
    """Approximate voxel-grid cell count for ``obj`` at ``voxel_size``."""
    d = obj.dimensions
    vs = max(voxel_size, 1e-9)
    return (d.x / vs) * (d.y / vs) * (d.z / vs)


# --------------------------------------------------------------------------- #
# Geometry helpers
# --------------------------------------------------------------------------- #
def tri_count(mesh):
    """Triangle count of ``mesh`` regardless of n-gon/quad topology."""
    return sum(len(p.vertices) - 2 for p in mesh.polygons)


def world_aabb(obj):
    """World-space axis-aligned bounding box as ``(min_v, max_v)`` Vectors."""
    mw = obj.matrix_world
    corners = [mw @ Vector(c) for c in obj.bound_box]
    mins = Vector((min(c[i] for c in corners) for i in range(3)))
    maxs = Vector((max(c[i] for c in corners) for i in range(3)))
    return mins, maxs


def _aabb_overlap(a, b, tol):
    (amin, amax), (bmin, bmax) = a, b
    return all(amin[i] <= bmax[i] + tol and bmin[i] <= amax[i] + tol
               for i in range(3))


def reference_dimension(objects):
    """Largest single-axis extent among ``objects`` (world scale applied)."""
    ref = 0.0
    for obj in objects:
        ref = max(ref, max(obj.dimensions))
    return ref


def compute_voxel_size(settings, objects):
    """Resolve the scene-wide voxel size from the settings."""
    if settings.voxel_mode == 'MANUAL':
        return max(settings.voxel_size, 1e-6)
    ref = reference_dimension(objects)
    if ref <= 0.0:
        return max(settings.voxel_size, 1e-6)
    return max(ref / max(settings.auto_detail, 1), 1e-6)


# --------------------------------------------------------------------------- #
# Density map sampling
# --------------------------------------------------------------------------- #
class DensitySampler:
    """Samples a painted density weight anywhere in world space.

    Built from the *source* objects (before remeshing).  After the voxel remesh
    replaces the topology, we resample each new vertex against the originals so
    the paint follows the surface rather than the old vertices.
    """

    def __init__(self, sources, group_name=DENSITY_GROUP):
        self.verts = []
        self.tris = []
        self.weights = []
        for obj in sources:
            self._add(obj, group_name)
        self.bvh = (BVHTree.FromPolygons(self.verts, self.tris,
                                         all_triangles=True)
                    if self.tris else None)

    def _add(self, obj, group_name):
        vg = obj.vertex_groups.get(group_name)
        if vg is None:
            return
        mw = obj.matrix_world
        mesh = obj.data
        base = len(self.verts)
        for v in mesh.vertices:
            self.verts.append(mw @ v.co)
            try:
                self.weights.append(vg.weight(v.index))
            except RuntimeError:
                self.weights.append(0.0)
        mesh.calc_loop_triangles()
        for lt in mesh.loop_triangles:
            self.tris.append((base + lt.vertices[0],
                              base + lt.vertices[1],
                              base + lt.vertices[2]))

    def active(self):
        return self.bvh is not None and any(w > 0.0 for w in self.weights)

    def sample(self, point):
        loc, _nrm, idx, _dist = self.bvh.find_nearest(point)
        if idx is None:
            return 0.0
        i0, i1, i2 = self.tris[idx]
        bw = poly_3d_calc([self.verts[i0], self.verts[i1], self.verts[i2]], loc)
        return (bw[0] * self.weights[i0]
                + bw[1] * self.weights[i1]
                + bw[2] * self.weights[i2])


def apply_density_group(obj, sampler, threshold):
    """Bake the sampled density into ``obj``'s density vertex group.

    Every vertex whose sampled weight meets ``threshold`` is written into the
    group at full weight.  The collapse decimation then reads this group so the
    painted regions resist collapsing and keep their remesh density.  Returns
    the group name if anything was written, else ``None``.
    """
    mw = obj.matrix_world
    protected = [v.index for v in obj.data.vertices
                 if sampler.sample(mw @ v.co) >= threshold]
    if not protected:
        return None
    vg = obj.vertex_groups.get(DENSITY_GROUP)
    if vg is None:
        vg = obj.vertex_groups.new(name=DENSITY_GROUP)
    vg.add(protected, 1.0, 'REPLACE')
    return vg.name


# --------------------------------------------------------------------------- #
# Grouping (which objects merge together)
# --------------------------------------------------------------------------- #
def group_objects(objects, merge_mode, tol):
    """Partition ``objects`` into groups that will each become one mesh."""
    if merge_mode == 'NONE':
        return [[o] for o in objects]
    if merge_mode == 'ALL':
        return [list(objects)]

    boxes = [world_aabb(o) for o in objects]
    parent = list(range(len(objects)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i in range(len(objects)):
        for j in range(i + 1, len(objects)):
            if _aabb_overlap(boxes[i], boxes[j], tol):
                parent[find(i)] = find(j)

    groups = {}
    for idx, obj in enumerate(objects):
        groups.setdefault(find(idx), []).append(obj)
    return list(groups.values())


# --------------------------------------------------------------------------- #
# Mesh operations
# --------------------------------------------------------------------------- #
def duplicate_object(context, obj):
    """Return an independent copy of ``obj`` linked to the active collection."""
    new = obj.copy()
    new.data = obj.data.copy()
    context.collection.objects.link(new)
    return new


def join_group(context, group):
    """Merge ``group`` into its first object with bmesh and return it.

    Uses bmesh rather than ``bpy.ops.object.join`` so it stays valid inside the
    preview timer, where operator context is unreliable.
    """
    main = group[0]
    if len(group) == 1:
        return main
    bm = bmesh.new()
    inv = main.matrix_world.inverted()
    for obj in group:
        tmp = obj.data.copy()
        tmp.transform(inv @ obj.matrix_world)
        bm.from_mesh(tmp)
        bpy.data.meshes.remove(tmp)
    bm.to_mesh(main.data)
    bm.free()
    main.data.update()
    for obj in group[1:]:
        mesh = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        if mesh.users == 0:
            bpy.data.meshes.remove(mesh)
    return main


def _bake_modifiers(context, obj):
    """Replace ``obj``'s mesh with its fully evaluated (modifier-applied) form."""
    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(depsgraph)
    new_mesh = bpy.data.meshes.new_from_object(eval_obj)
    old_mesh = obj.data
    obj.modifiers.clear()
    obj.data = new_mesh
    if old_mesh.users == 0:
        bpy.data.meshes.remove(old_mesh)


def _apply_voxel_remesh(context, obj, voxel_size):
    vs, clamped = safe_voxel_size(obj, voxel_size)
    if clamped:
        print("[EvenMesh] '{}': voxel auto-coarsened {:.5f} -> {:.5f} "
              "(requested size would exceed the {}M-cell safety cap)".format(
                  obj.name, voxel_size, vs, _VOXEL_CAP // 1_000_000))
    mod = obj.modifiers.new("EvenMesh_Voxel", 'REMESH')
    mod.mode = 'VOXEL'
    mod.voxel_size = vs
    mod.use_smooth_shade = False
    _bake_modifiers(context, obj)


def voxel_remesh_with_floor(context, obj, voxel_size, min_tris):
    """Voxel-remesh ``obj``; shrink the voxel until it clears ``min_tris``.

    The original mesh is stashed so each retry remeshes the source (not an
    already-coarsened result).  Returns the voxel size actually used.
    """
    backup = obj.data.copy()
    used = voxel_size
    try:
        for i in range(_REFINE_MAX_ITER):
            current = obj.data
            obj.data = backup.copy()
            if current.users == 0:
                bpy.data.meshes.remove(current)
            _apply_voxel_remesh(context, obj, used)
            if min_tris <= 0 or tri_count(obj.data) >= min_tris \
                    or i == _REFINE_MAX_ITER - 1:
                break
            used *= _REFINE_FACTOR
    finally:
        if backup.users == 0:
            bpy.data.meshes.remove(backup)
    return used


def fill_holes(obj):
    """境界ループ(穴)を面で塞ぎ、塞いだ面の数を返す。

    ボクセルリメッシュは閉じた体積を前提とするため、穴あきメッシュを
    そのまま通すと薄い二重殻になったり体積が消えたりする。境界エッジ
    (面が1つしか付いていないエッジ)のループを ``holes_fill`` で塞いで
    から後段に渡す。
    """
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    boundary = [e for e in bm.edges if e.is_boundary]
    if not boundary:
        bm.free()
        return 0
    result = bmesh.ops.holes_fill(bm, edges=boundary, sides=0)
    n_faces = len(result.get("faces", ()))
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()
    return n_faces


def count_boundary_edges(mesh):
    """境界エッジ数(0 なら水密の必要条件を満たす)。"""
    bm = bmesh.new()
    bm.from_mesh(mesh)
    n = sum(1 for e in bm.edges if e.is_boundary)
    bm.free()
    return n


def cleanup(obj, smooth_shade):
    """Drop loose geometry, recalc normals, optionally set smooth shading."""
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    loose = [v for v in bm.verts if not v.link_faces]
    if loose:
        bmesh.ops.delete(bm, geom=loose, context='VERTS')
    if bm.faces:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(mesh)
    bm.free()
    for poly in mesh.polygons:
        poly.use_smooth = smooth_shade
    mesh.update()


def triangulate(obj):
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bmesh.ops.triangulate(bm, faces=bm.faces)
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()


def decimate_collapse(context, obj, ratio, protect_group=None):
    """比率で ``obj`` をコラプス・デシメートする。

    実際の Decimate モディファイア(Collapse モード)を適用してベイクするので、
    挙動は Decimate モディファイアの Ratio 指定とまったく同じになる。
    ``ratio`` は残すポリゴンの割合(0.0〜1.0)。1.0 なら何もしない。
    ``protect_group`` に頂点グループ名(密度マップ)を渡すと、そのウェイトが
    高い領域ほど削減されにくくなり、塗った箇所のディテールが保持される。
    """
    r = max(0.0, min(ratio, 1.0))
    if r >= 1.0:
        return
    mod = obj.modifiers.new("EvenMesh_Decimate", 'DECIMATE')
    mod.decimate_type = 'COLLAPSE'
    mod.ratio = r
    if protect_group:
        mod.vertex_group = protect_group
        mod.vertex_group_factor = 1.0
    _bake_modifiers(context, obj)


# --------------------------------------------------------------------------- #
# Density map authoring
# --------------------------------------------------------------------------- #
def ensure_density_group(obj):
    """Return ``obj``'s density vertex group, creating it if needed."""
    vg = obj.vertex_groups.get(DENSITY_GROUP)
    if vg is None:
        vg = obj.vertex_groups.new(name=DENSITY_GROUP)
    return vg


# --------------------------------------------------------------------------- #
# Shared pipeline
# --------------------------------------------------------------------------- #
def gather_objects(context, scope):
    if scope == 'ALL':
        return [o for o in context.view_layer.objects if o.type == 'MESH']
    return [o for o in context.selected_objects if o.type == 'MESH']


def _process_group(context, group, voxel, settings, tag):
    """Remesh a single group of objects into one result object."""
    sampler = None
    if settings.use_density_map:
        # 元メッシュ(モディファイア適用前)の頂点グループから作る。適用後の
        # メッシュはデフォームレイヤーが保持されない場合があるため、先に構築する。
        sampler = DensitySampler(group)
        if not sampler.active():
            sampler = None
    # 全オブジェクトのモディファイアをビューポート設定で適用してから結合する。
    # join_group は素のメッシュを結合するため、ここで適用しないと先頭以外の
    # オブジェクトのモディファイアが結果に反映されない。
    for obj in group:
        if obj.modifiers:
            _bake_modifiers(context, obj)
    obj = join_group(context, group)
    if getattr(settings, "fill_holes", True):
        filled = fill_holes(obj)
        if filled:
            print("[EvenMesh] '{}': {} 個の穴を埋めてからリメッシュ".format(
                obj.name, filled))
    voxel_remesh_with_floor(context, obj, voxel, settings.min_tris)
    protect_group = None
    if sampler is not None:
        protect_group = apply_density_group(obj, sampler,
                                            settings.density_threshold)
    if settings.use_decimate:
        decimate_collapse(context, obj, settings.decimate_ratio, protect_group)
    cleanup(obj, settings.smooth_shade)
    if settings.triangulate:
        triangulate(obj)
    obj[tag] = True
    obj["evenmesh_tris"] = tri_count(obj.data)
    return obj


def _run_pipeline(context, work, settings, tag):
    """Remesh ``work`` objects in place; return ``(results, voxel_size)``."""
    voxel = compute_voxel_size(settings, work)
    groups = group_objects(work, settings.merge_mode, settings.merge_tol)
    results = [_process_group(context, g, voxel, settings, tag) for g in groups]
    return results, voxel


def iter_apply(context, settings):
    """Generator variant of the apply pipeline for the responsive modal.

    Processes one group per ``next()`` call and yields ``(done, total)`` after
    each. On completion it selects the results and returns ``(results, voxel)``
    (available via ``StopIteration.value``). Raises RuntimeError if there is no
    input. Assumes no live preview is active (the operator handles that case).
    """
    sources = gather_objects(context, settings.scope)
    if not sources:
        raise RuntimeError("処理対象のメッシュがありません"
                           "(メッシュを選択するか、対象を「全メッシュ」に切り替えてください)。")
    if settings.keep_original:
        work = [duplicate_object(context, o) for o in sources]
    else:
        work = list(sources)
    voxel = compute_voxel_size(settings, work)
    groups = group_objects(work, settings.merge_mode, settings.merge_tol)
    total = len(groups)
    results = []
    for i, group in enumerate(groups):
        results.append(_process_group(context, group, voxel, settings,
                                      RESULT_TAG))
        yield (i + 1, total)
    _select_only(context, results)
    return results, voxel


def _select_only(context, objects):
    for obj in context.selected_objects:
        obj.select_set(False)
    for obj in objects:
        obj.select_set(True)
    if objects:
        context.view_layer.objects.active = objects[0]


# --------------------------------------------------------------------------- #
# Apply (destructive) entry point
# --------------------------------------------------------------------------- #
def process(context, settings):
    """Remesh for real.  If a live preview is up, finalise it instead.

    Returns ``(results, voxel_size)``.
    """
    if _preview_active():
        return finalize_preview(context, settings)

    sources = gather_objects(context, settings.scope)
    if not sources:
        raise RuntimeError("処理対象のメッシュがありません"
                           "(メッシュを選択するか、対象を「全メッシュ」に切り替えてください)。")
    if settings.keep_original:
        work = [duplicate_object(context, o) for o in sources]
    else:
        work = list(sources)
    results, voxel = _run_pipeline(context, work, settings, RESULT_TAG)
    _select_only(context, results)
    return results, voxel


# --------------------------------------------------------------------------- #
# Live preview
# --------------------------------------------------------------------------- #
_preview_sources = []   # original objects, hidden while a preview is shown
_preview_voxel = 0.0
_rebuild_pending = False


def _preview_active():
    return bool(_preview_sources)


def preview_active():
    return _preview_active()


def preview_objects(context):
    return [o for o in context.view_layer.objects if o.get(PREVIEW_TAG)]


def _remove_preview_objects(context):
    for obj in preview_objects(context):
        mesh = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        if mesh and mesh.users == 0:
            bpy.data.meshes.remove(mesh)


def _make_preview(context, sources, settings):
    global _preview_voxel
    copies = [duplicate_object(context, o) for o in sources]
    results, voxel = _run_pipeline(context, copies, settings, PREVIEW_TAG)
    for obj in results:
        obj.name = "EvenMesh_Preview"
        obj.show_in_front = False
    _preview_voxel = voxel
    _select_only(context, results)
    return results, voxel


def build_preview(context, settings):
    """Create (or, if already up, rebuild) the live preview."""
    if _preview_active():
        rebuild_preview(context)
        return preview_objects(context), _preview_voxel

    sources = gather_objects(context, settings.scope)
    if not sources:
        raise RuntimeError("プレビュー対象のメッシュがありません"
                           "(メッシュを選択するか、対象を「全メッシュ」に切り替えてください)。")
    results, voxel = _make_preview(context, sources, settings)
    for obj in sources:
        obj.hide_set(True)
    _preview_sources[:] = sources
    return results, voxel


def rebuild_preview(context):
    """Regenerate the preview geometry from the cached sources."""
    if not _preview_active():
        return
    settings = context.scene.evenmesh
    _remove_preview_objects(context)
    _make_preview(context, list(_preview_sources), settings)


def clear_preview(context):
    """Remove the preview and restore the original objects."""
    _remove_preview_objects(context)
    for obj in _preview_sources:
        try:
            obj.hide_set(False)
        except ReferenceError:
            pass
    _preview_sources.clear()


def finalize_preview(context, settings):
    """Promote the preview objects to real results and drop the originals."""
    previews = preview_objects(context)
    for obj in previews:
        del obj[PREVIEW_TAG]
        obj[RESULT_TAG] = True
        obj.name = "EvenMesh_Result"
    if settings.keep_original:
        for obj in _preview_sources:
            try:
                obj.hide_set(False)
            except ReferenceError:
                pass
    else:
        for obj in list(_preview_sources):
            try:
                mesh = obj.data
                bpy.data.objects.remove(obj, do_unlink=True)
                if mesh and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)
            except ReferenceError:
                pass
    _preview_sources.clear()
    _select_only(context, previews)
    return previews, _preview_voxel


def schedule_preview_rebuild():
    """Queue one coalesced preview rebuild if a preview is active.

    Safe to call from a property ``update=`` callback; the rebuild runs on a
    short timer so dragging a slider coalesces into a single remesh.
    """
    global _rebuild_pending
    if not _preview_active() or _rebuild_pending:
        return
    _rebuild_pending = True
    bpy.app.timers.register(_preview_timer, first_interval=0.15)


def _preview_timer():
    global _rebuild_pending
    _rebuild_pending = False
    if _preview_active():
        try:
            rebuild_preview(bpy.context)
        except Exception:
            pass
    return None


def reset_preview_state():
    """Drop cached preview state (call on unregister)."""
    global _rebuild_pending
    _preview_sources.clear()
    _rebuild_pending = False
