"""Operators wiring the UI to core algorithms."""

import os

import bpy
from bpy.types import Operator

from . import core


def _has_target(context):
    st = context.scene.gks
    return bool(st.target) or (context.active_object is not None
                               and context.active_object.type == 'MESH')


def _has_planes(context):
    return any(o.get(core.PLANE_TAG) for o in context.scene.objects)


def _has_cuts(context):
    return any(o.get(core.PLANE_TAG) or o.get(core.CUTTER_TAG)
               for o in context.scene.objects)


def _has_parts(context):
    return any(o.get(core.PART_TAG) for o in context.scene.objects)

# Per-preset export settings.  All consumer SLA/MSLA slicers (PreForm, Photon
# Workshop, Chitubox) ingest millimetre STLs with Y-forward / Z-up, so the axes
# are shared; what actually differs between machines is the *build volume*, which
# is the whole reason we split.  ``build_volume`` is (X, Y, Z) in millimetres, or
# ``None`` for no limit.
def _p(build_volume):
    return {"scale": 1.0, "forward": 'Y', "up": 'Z', "build_volume": build_volume}


_PRESETS = {
    'GENERIC': _p(None),
    'FORMLABS': _p((145.0, 145.0, 185.0)),        # Form 3 / 3+
    'FORM4': _p((200.0, 125.0, 210.0)),           # Form 4
    'ANYCUBIC': _p((196.0, 122.0, 245.0)),        # Photon Mono X
    'ANYCUBIC_M5S': _p((218.0, 123.0, 200.0)),    # Photon Mono M5s
    'ELEGOO_SATURN4': _p((218.88, 122.88, 220.0)),  # Saturn 4 Ultra
    'ELEGOO_MARS4': _p((153.36, 77.76, 165.0)),   # Mars 4 Ultra
    'PHROZEN_MINI8K': _p((165.0, 72.0, 180.0)),   # Sonic Mini 8K
}


def _oversized_parts(parts, build_volume, scale):
    """Return [(part, (dx, dy, dz))] for parts that exceed ``build_volume``.

    Dimensions are compared in millimetres after ``scale`` is applied.  The
    part footprint is checked against the plate in an orientation-agnostic way:
    its two smallest dimensions must fit the plate's two smallest, and the
    largest must fit the plate height.
    """
    if not build_volume:
        return []
    plate = sorted(build_volume)
    oversized = []
    for part in parts:
        dims = tuple(d * scale for d in part.dimensions)
        sd = sorted(dims)
        if sd[0] > plate[0] or sd[1] > plate[1] or sd[2] > plate[2]:
            oversized.append((part, dims))
    return oversized


class GKS_OT_set_target(Operator):
    bl_idname = "gks.set_target"
    bl_label = "Use Active as Target"
    bl_description = "Set the active object as the split target"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.view_layer.objects.active
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Active object is not a mesh.")
            return {'CANCELLED'}
        context.scene.gks.target = obj
        return {'FINISHED'}


class GKS_OT_clean(Operator):
    bl_idname = "gks.clean_mesh"
    bl_label = "Clean Mesh"
    bl_description = "Merge doubles, recalc normals and report non-manifold edges"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not _has_target(context):
            cls.poll_message_set("Select a mesh, or set a Target")
            return False
        return True

    def execute(self, context):
        st = context.scene.gks
        target = core.resolve_target(context)
        if target is None:
            self.report({'ERROR'}, "No target mesh selected.")
            return {'CANCELLED'}
        rep = core.clean_mesh(target, st.clean_normals, st.clean_doubles,
                              st.clean_dist)
        msg = "Merged {merged_verts} verts.".format(**rep)
        if rep["non_manifold_edges"]:
            self.report({'WARNING'},
                        msg + " {non_manifold_edges} non-manifold edge(s) "
                        "detected – consider repairing before splitting."
                        .format(**rep))
        else:
            self.report({'INFO'}, msg + " Mesh is manifold.")
        return {'FINISHED'}


class GKS_OT_decimate(Operator):
    bl_idname = "gks.decimate"
    bl_label = "Decimate"
    bl_description = ("Collapse-decimate heavy meshes down to the target "
                     "triangle count so splitting and dowels stay fast")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        st = context.scene.gks
        if st.decimate_scope == 'TARGET' and not _has_target(context):
            cls.poll_message_set("Select a mesh, or set a Target")
            return False
        return True

    def execute(self, context):
        results = core.decimate_scene(context)
        if not results:
            self.report({'INFO'}, "Nothing to decimate (already under target).")
            return {'FINISHED'}
        before = sum(r[1] for r in results)
        after = sum(r[2] for r in results)
        self.report({'INFO'},
                    "Decimated {} mesh(es): {:,} -> {:,} tris.".format(
                        len(results), before, after))
        return {'FINISHED'}


class GKS_OT_add_plane(Operator):
    bl_idname = "gks.add_plane"
    bl_label = "Add Cut Plane"
    bl_description = "Add a movable cut plane centered on the target"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = core.add_cut_plane(context)
        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        self.report({'INFO'}, "Cut plane added. Move/rotate it into position.")
        return {'FINISHED'}


class GKS_OT_add_cutter(Operator):
    bl_idname = "gks.add_cutter"
    bl_label = "Add Curved Cutter"
    bl_description = ("Add a subdivided grid you can sculpt/proportional-edit "
                     "into a curved cut surface, then Split with it")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = core.add_cutter(context)
        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        self.report({'INFO'},
                    "Cutter added. Sculpt it into a curve (Proportional Edit), "
                    "then Split.")
        return {'FINISHED'}


class GKS_OT_set_cutter(Operator):
    bl_idname = "gks.set_cutter"
    bl_label = "Use Selected as Cutter"
    bl_description = ("Flag the selected mesh object(s) as curved cutters so you "
                     "can split with any shape you modelled (open surface or "
                     "closed solid)")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        sel = [o for o in context.selected_objects if o.type == 'MESH']
        if not sel:
            cls.poll_message_set("Select the mesh object(s) to use as cutters")
            return False
        return True

    def execute(self, context):
        n = core.set_cutter(context)
        if n == 0:
            self.report({'WARNING'},
                        "Nothing tagged — the selection is the target/parts or "
                        "already cutters.")
            return {'CANCELLED'}
        self.report({'INFO'}, "Tagged {} object(s) as cutter(s).".format(n))
        return {'FINISHED'}


class GKS_OT_clear_cutter(Operator):
    bl_idname = "gks.clear_cutter"
    bl_label = "Clear Cutters"
    bl_description = ("Stop using cutters. Add-on-created cutter grids are "
                     "deleted; your own objects are only untagged (kept)")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.get(core.CUTTER_TAG) for o in context.scene.objects)

    def execute(self, context):
        # clear the whole scene's cutters (not just selection) for convenience
        n = core.clear_cutter(context, selected_only=False)
        self.report({'INFO'}, "Cleared {} cutter(s).".format(n))
        return {'FINISHED'}


class GKS_OT_preview(Operator):
    bl_idname = "gks.preview"
    bl_label = "Preview Cuts"
    bl_description = "Highlight the cut lines for the current planes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not _has_planes(context):
            cls.poll_message_set("Add a cut plane first")
            return False
        return True

    def execute(self, context):
        try:
            core.build_preview(context)
        except RuntimeError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class GKS_OT_clear_preview(Operator):
    bl_idname = "gks.clear_preview"
    bl_label = "Clear Preview"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        core.clear_preview(context)
        return {'FINISHED'}


class GKS_OT_split(Operator):
    bl_idname = "gks.split"
    bl_label = "Split"
    bl_description = "Split the target along every cut plane into separate parts"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not _has_target(context):
            cls.poll_message_set("Select a mesh, or set a Target")
            return False
        if not _has_cuts(context):
            cls.poll_message_set("Add at least one cut plane or cutter")
            return False
        return True

    def execute(self, context):
        core.clear_preview(context)
        try:
            parts = core.split_object(context)
        except RuntimeError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        for o in context.selected_objects:
            o.select_set(False)
        for o in parts:
            o.select_set(True)
        if parts:
            context.view_layer.objects.active = parts[0]
        self.report({'INFO'}, "Split into {} part(s).".format(len(parts)))
        return {'FINISHED'}


class GKS_OT_preview_dowels(Operator):
    bl_idname = "gks.preview_dowels"
    bl_label = "Preview Dowels"
    bl_description = ("Show where pins would be placed without cutting, so you "
                     "can tune diameter/spacing first")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not _has_parts(context):
            cls.poll_message_set("Run Split first")
            return False
        return True

    def execute(self, context):
        try:
            n = core.preview_dowels(context)
        except RuntimeError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        if n == 0:
            self.report({'WARNING'},
                        "No pin positions fit — reduce spacing or diameter.")
        else:
            self.report({'INFO'}, "Preview: {} pin(s).".format(n))
        return {'FINISHED'}


class GKS_OT_clear_dowel_preview(Operator):
    bl_idname = "gks.clear_dowel_preview"
    bl_label = "Clear Dowel Preview"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        core.clear_dowel_preview(context)
        return {'FINISHED'}


class GKS_OT_add_dowel_point(Operator):
    bl_idname = "gks.add_dowel_point"
    bl_label = "Add Dowel Point"
    bl_description = ("Place a dowel marker at the 3D cursor, parented to the "
                     "active cut plane/cutter, to control exactly where a pin "
                     "goes (a cut with no markers auto-places pins on a grid)")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.view_layer.objects.active
        if obj is None or not (obj.get(core.PLANE_TAG)
                               or obj.get(core.CUTTER_TAG)):
            cls.poll_message_set("Select a cut plane or cutter first")
            return False
        return True

    def execute(self, context):
        try:
            empty = core.add_dowel_point(context)
        except RuntimeError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        for o in context.selected_objects:
            o.select_set(False)
        empty.select_set(True)
        context.view_layer.objects.active = empty
        self.report({'INFO'}, "Dowel point added (move it to fine-tune).")
        return {'FINISHED'}


class GKS_OT_dowels(Operator):
    bl_idname = "gks.generate_dowels"
    bl_label = "Generate Dowels"
    bl_description = "Add pins to one side and matching sockets to the other"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not _has_parts(context):
            cls.poll_message_set("Run Split first")
            return False
        return True

    def execute(self, context):
        try:
            n = core.generate_dowels(context)
        except RuntimeError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, "Generated {} pin/socket pair(s).".format(n))
        return {'FINISHED'}


class GKS_OT_orient(Operator):
    bl_idname = "gks.optimize_orientation"
    bl_label = "Optimize Orientation"
    bl_description = "Grid search for a low-support print orientation"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not _has_parts(context):
            cls.poll_message_set("Run Split first")
            return False
        return True

    def execute(self, context):
        try:
            top = core.optimize_orientation(context)
        except RuntimeError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        best = top[0]
        core.apply_orientation(context, best[1], best[2])
        lines = ["#{}: X={}° Y={}°  overhang={:.1f} vol={:.1f}".format(
            i + 1, r[1], r[2], r[3], r[4]) for i, r in enumerate(top)]
        self.report({'INFO'}, "Applied best. " + " | ".join(lines))
        return {'FINISHED'}


class GKS_OT_supports(Operator):
    bl_idname = "gks.generate_supports"
    bl_label = "Generate Supports"
    bl_description = "Create simple point or tree supports for overhangs"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not _has_parts(context):
            cls.poll_message_set("Run Split first")
            return False
        return True

    def execute(self, context):
        try:
            res = core.generate_supports(context)
        except RuntimeError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        n = res["contacts"]
        if n == 0:
            self.report({'INFO'}, "No overhangs needing support were found.")
        else:
            msg = "Created {} support contact(s).".format(n)
            if res["raft"]:
                msg += " Raft added."
            self.report({'INFO'}, msg)
        return {'FINISHED'}


class GKS_OT_add_marker(Operator):
    bl_idname = "gks.add_marker"
    bl_label = "Add Support Marker"
    bl_description = ("Place a marker at the 3D cursor; Generate Supports will "
                     "add a column there in addition to the automatic ones")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        core.add_marker(context)
        self.report({'INFO'}, "Marker added at 3D cursor.")
        return {'FINISHED'}


class GKS_OT_clear_markers(Operator):
    bl_idname = "gks.clear_markers"
    bl_label = "Clear Markers"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.get(core.MARKER_TAG) for o in context.scene.objects)

    def execute(self, context):
        n = core.clear_markers(context)
        self.report({'INFO'}, "Removed {} marker(s).".format(n))
        return {'FINISHED'}


class GKS_OT_paint_overhang(Operator):
    bl_idname = "gks.paint_overhang"
    bl_label = "Show Overhangs"
    bl_description = ("Weight-paint each mesh by overhang severity (blue = safe, "
                     "red = needs support) at the current orientation")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not (_has_parts(context) or _has_target(context)):
            cls.poll_message_set("Split first, or set a Target")
            return False
        return True

    def execute(self, context):
        try:
            n = core.paint_overhang(context)
        except RuntimeError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        self.report({'INFO'},
                    "Painted overhang weights on {} mesh(es).".format(n))
        return {'FINISHED'}


class GKS_OT_estimate_volume(Operator):
    bl_idname = "gks.estimate_volume"
    bl_label = "Estimate Resin"
    bl_description = ("Estimate resin volume (mL) of the parts plus supports "
                     "and raft; 1 Blender unit = 1 mm")
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        if not _has_parts(context):
            cls.poll_message_set("Run Split first")
            return False
        return True

    def execute(self, context):
        model_ml, supp_ml = core.estimate_resin_volume(context)
        self.report(
            {'INFO'},
            "Resin: parts {:.1f} mL + supports/raft {:.1f} mL = {:.1f} mL "
            "total.".format(model_ml, supp_ml, model_ml + supp_ml))
        return {'FINISHED'}


class GKS_OT_export(Operator):
    bl_idname = "gks.export_stl"
    bl_label = "Export STL"
    bl_description = "Export each part as an individual STL file"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        if not _has_parts(context):
            cls.poll_message_set("Run Split first")
            return False
        return True

    def execute(self, context):
        st = context.scene.gks
        preset = _PRESETS.get(st.export_preset, _PRESETS['GENERIC'])
        directory = bpy.path.abspath(st.export_dir)
        if not directory:
            self.report({'ERROR'}, "Set an output folder first.")
            return {'CANCELLED'}
        os.makedirs(directory, exist_ok=True)

        if not hasattr(bpy.ops.wm, "stl_export"):
            self.report({'ERROR'},
                        "STL exporter not available in this Blender build.")
            return {'CANCELLED'}

        if st.export_all:
            parts = core.get_parts(context)
        else:
            parts = [o for o in context.selected_objects
                     if o.type == 'MESH' and o.get(core.PART_TAG)]
        if not parts:
            self.report({'ERROR'}, "No parts to export.")
            return {'CANCELLED'}

        prev_selection = list(context.selected_objects)
        prev_active = context.view_layer.objects.active
        count = 0
        for part in parts:
            for o in context.selected_objects:
                o.select_set(False)
            part.select_set(True)
            context.view_layer.objects.active = part
            filepath = os.path.join(directory, part.name + ".stl")
            bpy.ops.wm.stl_export(
                filepath=filepath,
                ascii_format=st.ascii_stl,
                apply_modifiers=True,
                export_selected_objects=True,
                global_scale=st.export_scale * preset["scale"],
                forward_axis=preset["forward"],
                up_axis=preset["up"],
            )
            count += 1

        for o in context.selected_objects:
            o.select_set(False)
        for o in prev_selection:
            o.select_set(True)
        context.view_layer.objects.active = prev_active

        oversized = _oversized_parts(
            parts, preset["build_volume"], st.export_scale * preset["scale"])
        if oversized:
            names = ", ".join(
                "{} ({:.0f}x{:.0f}x{:.0f}mm)".format(p.name, *d)
                for p, d in oversized)
            self.report(
                {'WARNING'},
                "Exported {} STL(s) to {}. {} part(s) exceed the {} build "
                "volume: {} — split further.".format(
                    count, directory, len(oversized), st.export_preset, names))
        else:
            self.report({'INFO'}, "Exported {} STL file(s) to {}".format(
                count, directory))
        return {'FINISHED'}


class GKS_OT_make_gauge(Operator):
    bl_idname = "gks.make_gauge"
    bl_label = "Make Fit Gauge"
    bl_description = ("Create a two-piece clearance test print (pin comb + "
                     "socket comb) to calibrate the dowel fit before printing")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        clears = core.make_gauge(context)
        legend = ", ".join("{}t={:.2f}".format(i, c)
                           for i, c in enumerate(clears))
        self.report({'INFO'},
                    "Gauge created (n ticks = 0.05*n mm). Columns: " + legend)
        return {'FINISHED'}


class GKS_OT_toggle_explode(Operator):
    bl_idname = "gks.toggle_explode"
    bl_label = "Explode / Assemble"
    bl_description = "Push the split parts apart for review, or snap them back"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        parts = [o for o in context.scene.objects if o.get(core.PART_TAG)]
        if len(parts) < 2:
            cls.poll_message_set("Need at least two split parts")
            return False
        return True

    def execute(self, context):
        if core.is_exploded(context):
            n = core.assemble_parts(context)
            self.report({'INFO'}, "Assembled {} part(s).".format(n))
        else:
            n = core.explode_parts(context, context.scene.gks.explode_distance)
            self.report({'INFO'}, "Exploded {} part(s).".format(n))
        return {'FINISHED'}


class GKS_OT_cleanup(Operator):
    bl_idname = "gks.cleanup"
    bl_label = "Remove GKS Helpers"
    bl_description = ("Delete cut planes, previews and supports created by "
                     "GarageKit Splitter (keeps the split parts)")
    bl_options = {'REGISTER', 'UNDO'}

    TAGS = (core.PLANE_TAG, core.CUTTER_TAG, core.PREVIEW_TAG,
            core.DOWEL_PREVIEW_TAG, core.SUPPORT_TAG, core.RAFT_TAG,
            core.MARKER_TAG, core.GAUGE_TAG)

    @classmethod
    def poll(cls, context):
        return any(o.get(t) for o in context.scene.objects for t in cls.TAGS)

    def execute(self, context):
        removed = untagged = 0
        for o in list(context.scene.objects):
            # a user's own object used as a cutter must never be deleted; just
            # drop the tag so it stays in the scene as a normal object.
            if o.get(core.CUTTER_TAG) and not o.get(core.OWNED_TAG):
                del o[core.CUTTER_TAG]
                o.show_in_front = False
                untagged += 1
                continue
            if any(o.get(t) for t in self.TAGS):
                core.remove_object(o)
                removed += 1
        msg = "Removed {} helper object(s).".format(removed)
        if untagged:
            msg += " Untagged {} user cutter(s).".format(untagged)
        self.report({'INFO'}, msg)
        return {'FINISHED'}


CLASSES = (
    GKS_OT_set_target,
    GKS_OT_clean,
    GKS_OT_decimate,
    GKS_OT_add_plane,
    GKS_OT_add_cutter,
    GKS_OT_set_cutter,
    GKS_OT_clear_cutter,
    GKS_OT_preview,
    GKS_OT_clear_preview,
    GKS_OT_split,
    GKS_OT_preview_dowels,
    GKS_OT_clear_dowel_preview,
    GKS_OT_dowels,
    GKS_OT_orient,
    GKS_OT_supports,
    GKS_OT_add_marker,
    GKS_OT_clear_markers,
    GKS_OT_paint_overhang,
    GKS_OT_estimate_volume,
    GKS_OT_export,
    GKS_OT_make_gauge,
    GKS_OT_toggle_explode,
    GKS_OT_cleanup,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
