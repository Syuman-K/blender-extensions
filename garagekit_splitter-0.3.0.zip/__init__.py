"""GarageKit Splitter — Blender add-on (extension).

Split a 3D model at defined planes, auto-generate dowels (pins/sockets),
optimise print orientation, add simple supports and export per-part STLs.

Registered as a Blender 4.2+/5.0 extension; see blender_manifest.toml.
"""

from . import operators, properties, ui


def register():
    properties.register()
    operators.register()
    ui.register()


def unregister():
    ui.unregister()
    operators.unregister()
    properties.unregister()
