"""Core geometry algorithms for GarageKit Splitter.

Everything works in *world* coordinates.  Parts get their object transform
baked into the mesh at split time (matrix_world == Identity) so that pins,
sockets and supports built with world coordinates line up exactly.
"""

import math

import bmesh
import bpy
import mathutils
from mathutils import Euler, Matrix, Vector

Z_AXIS = Vector((0.0, 0.0, 1.0))
PART_TAG = "gks_part"
PLANE_TAG = "gks_plane"
CUTTER_TAG = "gks_cutter"  # a mesh object used as a curved-surface cutter
PREVIEW_TAG = "gks_preview"
DOWEL_PREVIEW_TAG = "gks_dowel_preview"
DOWELPT_TAG = "gks_dowel_pt"  # an Empty parented to a plane/cutter = manual dowel
SUPPORT_TAG = "gks_support"
RAFT_TAG = "gks_raft"
MARKER_TAG = "gks_marker"  # an Empty flagging a manual support location
GAUGE_TAG = "gks_gauge"
OWNED_TAG = "gks_owned"  # object created by the add-on (safe to delete on cleanup)
EXPLODE_TAG = "gks_explode"  # stores the world offset applied by "Explode"
OVERHANG_GROUP = "GKS_Overhang"  # vertex group holding overhang-severity weights


# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #
def plane_basis(no):
    """Return two orthonormal vectors spanning the plane with normal ``no``."""
    no = no.normalized()
    ref = Vector((1.0, 0.0, 0.0)) if abs(no.x) < 0.9 else Vector((0.0, 1.0, 0.0))
    u = (ref - no * ref.dot(no)).normalized()
    v = no.cross(u).normalized()
    return u, v


def get_collection(context, name):
    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
        context.scene.collection.children.link(coll)
    return coll


def bake_transform(obj):
    """Bake the object's world transform into its mesh data."""
    if obj.type != 'MESH':
        return
    obj.data.transform(obj.matrix_world)
    obj.matrix_world = Matrix.Identity(4)


def remove_object(obj):
    data = obj.data
    for coll in list(obj.users_collection):
        coll.objects.unlink(obj)
    bpy.data.objects.remove(obj, do_unlink=True)
    if data and data.users == 0:
        bpy.data.meshes.remove(data)


def get_parts(context):
    return [o for o in context.scene.objects
            if o.type == 'MESH' and o.get(PART_TAG)]


def resolve_target(context):
    st = context.scene.gks
    if st.target:
        return st.target
    obj = context.view_layer.objects.active
    if obj and obj.type == 'MESH':
        return obj
    return None


# --------------------------------------------------------------------------- #
# Prepare
# --------------------------------------------------------------------------- #
def clean_mesh(obj, do_normals=True, do_doubles=True, dist=1e-4):
    """Simple pre-processing.  Returns a small report dict."""
    me = obj.data
    bm = bmesh.new()
    bm.from_mesh(me)

    v0 = len(bm.verts)
    if do_doubles:
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=dist)
    if do_normals:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

    non_manifold = sum(1 for e in bm.edges if not e.is_manifold)
    removed = v0 - len(bm.verts)

    bm.to_mesh(me)
    bm.free()
    me.update()
    return {"merged_verts": removed, "non_manifold_edges": non_manifold}


# --------------------------------------------------------------------------- #
# Cut planes
# --------------------------------------------------------------------------- #
def add_cut_plane(context):
    st = context.scene.gks
    target = resolve_target(context)

    if target:
        corners = [target.matrix_world @ Vector(c) for c in target.bound_box]
        center = sum(corners, Vector()) / 8.0
        size = max(target.dimensions) * 1.3 or 1.0
    else:
        center = context.scene.cursor.location.copy()
        size = 1.0

    me = bpy.data.meshes.new("GKS_Plane")
    bm = bmesh.new()
    s = size * 0.5
    verts = [bm.verts.new((-s, -s, 0.0)), bm.verts.new((s, -s, 0.0)),
             bm.verts.new((s, s, 0.0)), bm.verts.new((-s, s, 0.0))]
    bm.faces.new(verts)
    bm.to_mesh(me)
    bm.free()

    obj = bpy.data.objects.new("GKS_Plane", me)
    obj[PLANE_TAG] = True
    obj.location = center
    obj.display_type = 'WIRE'
    obj.show_in_front = True
    obj.show_axis = True
    get_collection(context, "GKS_Cut_Planes").objects.link(obj)
    return obj


def get_cut_planes(context):
    planes = []
    for o in context.scene.objects:
        if o.get(PLANE_TAG):
            co = o.matrix_world.translation.copy()
            no = (o.matrix_world.to_3x3() @ Z_AXIS).normalized()
            planes.append((o, co, no))
    return planes


def surface_average_normal(obj):
    """Area-weighted mean face normal of a (possibly open) mesh, in world space.

    Used to pick the overall +/- direction of a curved cutter so the two halves
    and any dowels can be oriented consistently."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    bm.normal_update()
    acc = Vector((0.0, 0.0, 0.0))
    for f in bm.faces:
        acc += f.normal * f.calc_area()
    bm.free()
    if acc.length < 1e-9:
        return Z_AXIS.copy()
    return acc.normalized()


def get_cutters(context):
    """Return [(obj, center, avg_normal)] for every mesh tagged as a cutter."""
    cutters = []
    for o in context.scene.objects:
        if o.get(CUTTER_TAG) and o.type == 'MESH':
            corners = [o.matrix_world @ Vector(c) for c in o.bound_box]
            center = sum(corners, Vector()) / 8.0
            cutters.append((o, center, surface_average_normal(o)))
    return cutters


def add_cutter(context):
    """Create a subdivided grid the user can sculpt into a curved cut surface."""
    target = resolve_target(context)
    if target:
        corners = [target.matrix_world @ Vector(c) for c in target.bound_box]
        center = sum(corners, Vector()) / 8.0
        size = max(target.dimensions) * 1.4 or 1.0
    else:
        center = context.scene.cursor.location.copy()
        size = 1.0

    me = bpy.data.meshes.new("GKS_Cutter")
    bm = bmesh.new()
    n = 12  # grid resolution — enough vertices to sculpt a smooth curve
    s = size * 0.5
    grid = {}
    for iy in range(n + 1):
        for ix in range(n + 1):
            x = -s + size * ix / n
            y = -s + size * iy / n
            grid[(ix, iy)] = bm.verts.new((x, y, 0.0))
    for iy in range(n):
        for ix in range(n):
            bm.faces.new((grid[(ix, iy)], grid[(ix + 1, iy)],
                          grid[(ix + 1, iy + 1)], grid[(ix, iy + 1)]))
    bm.to_mesh(me)
    bm.free()

    obj = bpy.data.objects.new("GKS_Cutter", me)
    obj[CUTTER_TAG] = True
    obj[OWNED_TAG] = True  # add-on created it -> cleanup may delete it
    obj.location = center
    obj.show_in_front = True
    get_collection(context, "GKS_Cut_Planes").objects.link(obj)
    return obj


def set_cutter(context):
    """Flag every selected mesh (that isn't the target, a part or a plane) as a
    curved cutter, so the user can cut with any object they modelled.  Returns
    the number of objects newly tagged."""
    st = context.scene.gks
    protected = set(get_parts(context))
    if st.target:
        protected.add(st.target)
    n = 0
    for o in context.selected_objects:
        if (o.type == 'MESH' and o not in protected
                and not o.get(PLANE_TAG) and not o.get(CUTTER_TAG)):
            o[CUTTER_TAG] = True
            o.show_in_front = True
            n += 1
    return n


def clear_cutter(context, selected_only=True):
    """Stop using cutters: add-on-created grids are deleted, user objects are
    only untagged (kept in the scene).  Returns how many were cleared."""
    pool = context.selected_objects if selected_only else list(
        context.scene.objects)
    n = 0
    for o in list(pool):
        if not o.get(CUTTER_TAG):
            continue
        if o.get(OWNED_TAG):
            remove_object(o)
        else:
            del o[CUTTER_TAG]
            o.show_in_front = False
        n += 1
    return n


def _aabb_overlap(a, b):
    """True if the world AABBs of objects ``a`` and ``b`` overlap."""
    amn = [min(v) for v in zip(*[(a.matrix_world @ Vector(c))[:]
                                 for c in a.bound_box])]
    amx = [max(v) for v in zip(*[(a.matrix_world @ Vector(c))[:]
                                 for c in a.bound_box])]
    bmn = [min(v) for v in zip(*[(b.matrix_world @ Vector(c))[:]
                                 for c in b.bound_box])]
    bmx = [max(v) for v in zip(*[(b.matrix_world @ Vector(c))[:]
                                 for c in b.bound_box])]
    return all(amn[i] <= bmx[i] and bmn[i] <= amx[i] for i in range(3))


def make_surface_halfspace(cutter, normal, big):
    """Turn an open cutter surface into a closed solid filling the ``-normal``
    half-space, so a boolean INTERSECT/DIFFERENCE against it cleanly divides a
    part into the ``+normal`` and ``-normal`` pieces.

    Extrudes the surface's boundary loop by ``big`` along ``-normal`` and caps
    the far end.  Returns a new (unlinked) mesh object in world coordinates."""
    bm = bmesh.new()
    bm.from_mesh(cutter.data)
    bm.transform(cutter.matrix_world)
    boundary = [e for e in bm.edges if e.is_boundary]
    if boundary:
        res = bmesh.ops.extrude_edge_only(bm, edges=boundary)
        new_verts = [g for g in res["geom"]
                     if isinstance(g, bmesh.types.BMVert)]
        bmesh.ops.translate(bm, verts=new_verts, vec=-normal * big)
        far = [e for e in bm.edges if e.is_boundary]
        if far:
            try:
                bmesh.ops.holes_fill(bm, edges=far, sides=0)
            except (RuntimeError, ValueError):
                pass
        still = [e for e in bm.edges if e.is_boundary]
        if still:
            try:
                bmesh.ops.triangle_fill(bm, edges=still, use_beauty=True)
            except (RuntimeError, ValueError):
                pass
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    me = bpy.data.meshes.new("GKS_Halfspace")
    bm.to_mesh(me)
    bm.free()
    return bpy.data.objects.new("GKS_Halfspace", me)


def _split_by_cutter(context, part, cutter, normal, coll, solver='EXACT'):
    """Divide ``part`` (baked to identity) with a curved ``cutter`` surface.

    Returns ``[obj_pos, obj_neg]`` (the +normal / -normal halves) or ``[part]``
    if the cutter does not actually intersect the part."""
    if not _aabb_overlap(part, cutter):
        return [part]
    diag = (Vector(part.bound_box[6]) - Vector(part.bound_box[0])).length
    big = max(diag * 4.0, 1.0)
    solid = make_surface_halfspace(cutter, normal, big)
    context.scene.collection.objects.link(solid)

    mesh_pos = part.data.copy()
    mesh_neg = part.data.copy()
    obj_pos = bpy.data.objects.new(part.name + "_A", mesh_pos)
    obj_neg = bpy.data.objects.new(part.name + "_B", mesh_neg)
    coll.objects.link(obj_pos)
    coll.objects.link(obj_neg)
    # +normal side = part minus the (-normal) solid; -normal side = intersection
    apply_boolean(context, obj_pos, solid, 'DIFFERENCE', solver)
    apply_boolean(context, obj_neg, solid, 'INTERSECT', solver)
    remove_object(solid)

    halves = []
    for o in (obj_pos, obj_neg):
        o.data.calc_loop_triangles()
        if len(o.data.vertices) == 0 or len(o.data.polygons) == 0:
            remove_object(o)
        else:
            o[PART_TAG] = True
            halves.append(o)
    if len(halves) < 2:  # cutter missed the body — undo and keep original
        for o in halves:
            remove_object(o)
        return [part]
    remove_object(part)
    return halves


def _bbox_straddles(obj, co, no):
    lo = hi = None
    for corner in obj.bound_box:
        d = ((obj.matrix_world @ Vector(corner)) - co).dot(no)
        lo = d if lo is None else min(lo, d)
        hi = d if hi is None else max(hi, d)
    return lo is not None and lo < -1e-6 and hi > 1e-6


# --------------------------------------------------------------------------- #
# Split
# --------------------------------------------------------------------------- #
def _bisect_side(src_mesh, co, no, keep_positive):
    """Return a new mesh: ``src_mesh`` cut by the plane, one side kept & capped."""
    bm = bmesh.new()
    bm.from_mesh(src_mesh)
    geom = list(bm.verts) + list(bm.edges) + list(bm.faces)
    res = bmesh.ops.bisect_plane(
        bm, geom=geom, dist=1e-6, plane_co=co, plane_no=no,
        clear_inner=keep_positive, clear_outer=not keep_positive,
    )
    cut_edges = [g for g in res["geom_cut"] if isinstance(g, bmesh.types.BMEdge)]
    if cut_edges:
        try:
            bmesh.ops.holes_fill(bm, edges=cut_edges, sides=0)
        except (RuntimeError, ValueError):
            try:
                bmesh.ops.edgenet_fill(bm, edges=cut_edges)
            except (RuntimeError, ValueError):
                pass
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

    new_mesh = bpy.data.meshes.new(src_mesh.name + "_part")
    bm.to_mesh(new_mesh)
    bm.free()
    return new_mesh


def split_object(context):
    """Split the target by every cut plane.  Returns the list of part objects."""
    target = resolve_target(context)
    if target is None:
        raise RuntimeError("No target mesh selected.")
    # make sure any just-moved plane's matrix_world is up to date before we read
    # its normal (matters for scripted use with no interactive depsgraph tick).
    context.view_layer.update()
    planes = get_cut_planes(context)
    cutters = get_cutters(context)
    if not planes and not cutters:
        raise RuntimeError(
            "No cut planes or cutters found. Add at least one first.")

    st = context.scene.gks
    bake_transform(target)
    coll = (target.users_collection[0]
            if target.users_collection else context.scene.collection)

    parts = [target]
    for _plane_obj, co, no in planes:
        next_parts = []
        for part in parts:
            if not _bbox_straddles(part, co, no):
                next_parts.append(part)
                continue
            mesh_pos = _bisect_side(part.data, co, no, keep_positive=True)
            mesh_neg = _bisect_side(part.data, co, no, keep_positive=False)
            obj_a = bpy.data.objects.new(part.name + "_A", mesh_pos)
            obj_b = bpy.data.objects.new(part.name + "_B", mesh_neg)
            for o in (obj_a, obj_b):
                o[PART_TAG] = True
                coll.objects.link(o)
            remove_object(part)
            next_parts.extend((obj_a, obj_b))
        parts = next_parts

    for _cutter_obj, _co, no in cutters:
        next_parts = []
        for part in parts:
            next_parts.extend(
                _split_by_cutter(context, part, _cutter_obj, no, coll,
                                 st.bool_solver))
        parts = next_parts

    for o in parts:
        o[PART_TAG] = True
    return parts


# --------------------------------------------------------------------------- #
# Dowels
# --------------------------------------------------------------------------- #
def _sign_area(p1, p2, p3):
    return (p1.x - p3.x) * (p2.y - p3.y) - (p2.x - p3.x) * (p1.y - p3.y)


def _point_in_tri(p, a, b, c):
    d1 = _sign_area(p, a, b)
    d2 = _sign_area(p, b, c)
    d3 = _sign_area(p, c, a)
    has_neg = (d1 < 0) or (d2 < 0) or (d3 < 0)
    has_pos = (d1 > 0) or (d2 > 0) or (d3 > 0)
    return not (has_neg and has_pos)


def _seg_dist(p, a, b):
    ab = b - a
    ls = ab.length_squared
    t = 0.0 if ls == 0.0 else max(0.0, min(1.0, (p - a).dot(ab) / ls))
    return (p - (a + ab * t)).length


def _bbox_overlap(a, b):
    return not (a[2] < b[0] or b[2] < a[0] or a[3] < b[1] or b[3] < a[1])


def analyze_cap(obj, co, no, tol=1e-3):
    """Find the flat cut face(s) of ``obj`` lying on the plane (co, no).

    Returns a dict with 2D triangles / boundary segments / bbox in the plane
    basis, plus the dominant normal sign, or ``None`` if there is no cap.
    """
    u, v = plane_basis(no)
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    bm.normal_update()

    cap_faces = [
        f for f in bm.faces
        if abs((f.calc_center_median() - co).dot(no)) < tol
        and abs(f.normal.dot(no)) > 0.9
    ]
    if not cap_faces:
        bm.free()
        return None

    sign = 1.0 if sum(f.normal.dot(no) for f in cap_faces) >= 0.0 else -1.0
    cap_set = set(cap_faces)

    def to2d(p):
        d = p - co
        return Vector((d.dot(u), d.dot(v)))

    segs = []
    for f in cap_faces:
        for e in f.edges:
            if sum(1 for lf in e.link_faces if lf in cap_set) == 1:
                segs.append((to2d(e.verts[0].co), to2d(e.verts[1].co)))

    tris = []
    for f in cap_faces:
        pts = [to2d(vt.co) for vt in f.verts]
        if len(pts) == 3:
            tris.append((pts[0], pts[1], pts[2]))
        else:
            for a, b, c in mathutils.geometry.tessellate_polygon([pts]):
                tris.append((pts[a], pts[b], pts[c]))

    xs = [p.x for t in tris for p in t]
    ys = [p.y for t in tris for p in t]
    bm.free()
    return {
        "sign": sign,
        "tris": tris,
        "segs": segs,
        "bbox": (min(xs), min(ys), max(xs), max(ys)),
        "u": u, "v": v, "co": co, "no": no,
    }


def analyze_cap_curved(obj, cutter, co, no, tol=None):
    """Like :func:`analyze_cap` but for a curved cutter.

    Collects the faces of ``obj`` that lie on the cutter *surface* (found via
    ``closest_point_on_mesh``) rather than on a flat plane, then projects them
    onto the mean-plane basis (co, no) so the existing 2D grid-candidate and
    dowel machinery can be reused.  The returned dict carries ``"cutter"`` so the
    dowel pass knows to re-project each pin base back onto the real surface.
    """
    if tol is None:
        tol = max(cutter.dimensions.length * 0.02, 1e-3)
    u, v = plane_basis(no)
    mwi = cutter.matrix_world.inverted()
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    bm.normal_update()

    cap_faces = []
    for f in bm.faces:
        c = f.calc_center_median()
        ok, loc, _nrm, _idx = cutter.closest_point_on_mesh(mwi @ c)
        if ok and ((cutter.matrix_world @ loc) - c).length < tol:
            cap_faces.append(f)
    if not cap_faces:
        bm.free()
        return None

    sign = 1.0 if sum(f.normal.dot(no) for f in cap_faces) >= 0.0 else -1.0
    cap_set = set(cap_faces)

    def to2d(p):
        d = p - co
        return Vector((d.dot(u), d.dot(v)))

    segs = []
    for f in cap_faces:
        for e in f.edges:
            if sum(1 for lf in e.link_faces if lf in cap_set) == 1:
                segs.append((to2d(e.verts[0].co), to2d(e.verts[1].co)))

    tris = []
    for f in cap_faces:
        pts = [to2d(vt.co) for vt in f.verts]
        if len(pts) == 3:
            tris.append((pts[0], pts[1], pts[2]))
        else:
            for a, b, c in mathutils.geometry.tessellate_polygon([pts]):
                tris.append((pts[a], pts[b], pts[c]))

    xs = [p.x for t in tris for p in t]
    ys = [p.y for t in tris for p in t]
    bm.free()
    return {
        "sign": sign, "tris": tris, "segs": segs,
        "bbox": (min(xs), min(ys), max(xs), max(ys)),
        "u": u, "v": v, "co": co, "no": no, "cutter": cutter,
    }


def _project_to_cutter(cutter, base, no):
    """Snap a mean-plane point ``base`` onto the cutter surface and return
    ``(surface_point, surface_normal)`` with the normal aligned to ``+no``.
    Falls back to ``(base, no)`` if the projection misses."""
    if cutter is None:
        return base, no
    ok, loc, nrm, _idx = cutter.closest_point_on_mesh(
        cutter.matrix_world.inverted() @ base)
    if not ok:
        return base, no
    p = cutter.matrix_world @ loc
    n = (cutter.matrix_world.to_3x3() @ nrm).normalized()
    if n.dot(no) < 0.0:
        n = -n
    return p, n


def _body_side(obj, co, no):
    """-1 if the part's body sits on the -no side of the plane, else +1.
    Uses the bounding-box centre, so it is robust to messy cap normals."""
    center = sum((obj.matrix_world @ Vector(c) for c in obj.bound_box),
                 Vector()) / 8.0
    return -1.0 if (center - co).dot(no) < 0.0 else 1.0


def find_interfaces(context, parts):
    """Match parts that share a cut plane -> list of interface dicts.

    Which part is A (pin host, cap normal +no) vs B is decided from the part's
    *body position* relative to the plane, not from the cut-face normal -- so it
    still works when the input mesh has inconsistent/flipped normals."""
    planes = get_cut_planes(context)
    cutters = get_cutters(context)
    interfaces = []
    for plane_obj, co, no in planes:
        a_side, b_side = [], []
        for p in parts:
            cap = analyze_cap(p, co, no)
            if cap is None:
                continue
            # body on -no side -> its cap faces +no -> it is the pin host A
            (a_side if _body_side(p, co, no) < 0 else b_side).append((p, cap))
        for pa, cap_a in a_side:
            for pb, _cap_b in b_side:
                if pa is pb:
                    continue
                interfaces.append({"A": pa, "B": pb, "co": co, "no": no,
                                   "cap": cap_a, "cut": plane_obj})
    for cutter_obj, co, no in cutters:
        a_side, b_side = [], []
        for p in parts:
            cap = analyze_cap_curved(p, cutter_obj, co, no)
            if cap is None:
                continue
            (a_side if _body_side(p, co, no) < 0 else b_side).append((p, cap))
        for pa, cap_a in a_side:
            for pb, _cap_b in b_side:
                if pa is pb:
                    continue
                interfaces.append({"A": pa, "B": pb, "co": co, "no": no,
                                   "cap": cap_a, "cut": cutter_obj})
    return interfaces


def cut_dowel_points(cut_obj):
    """World positions of the manual dowel Empties parented to a cut object."""
    if cut_obj is None:
        return []
    return [c.matrix_world.translation.copy()
            for c in cut_obj.children if c.type == 'EMPTY']


def _interface_points_2d(iface, st):
    """2D (u,v) dowel points for an interface: the manual dowel Empties if the
    cut object has any, otherwise the automatic grid."""
    cap = iface["cap"]
    manual = cut_dowel_points(iface.get("cut"))
    if manual:
        co, u, v = cap["co"], cap["u"], cap["v"]
        return [Vector(((mp - co).dot(u), (mp - co).dot(v))) for mp in manual]
    return _grid_candidates(cap, st)


def _grid_candidates(cap, st):
    minx, miny, maxx, maxy = cap["bbox"]
    margin = max(st.pin_diameter * 0.5 + max(st.clearance, 0.0) + 0.4, 0.2)
    step = max(st.pin_spacing, st.pin_diameter + 1.0)
    pts = []
    x = minx + step * 0.5
    while x < maxx:
        y = miny + step * 0.5
        while y < maxy:
            p = Vector((x, y))
            if any(_point_in_tri(p, *t) for t in cap["tris"]):
                if not cap["segs"] or min(_seg_dist(p, a, b)
                                          for a, b in cap["segs"]) >= margin:
                    pts.append(p)
            y += step
        x += step

    if not pts:  # fall back to the centroid
        c = Vector(((minx + maxx) * 0.5, (miny + maxy) * 0.5))
        if any(_point_in_tri(c, *t) for t in cap["tris"]):
            pts.append(c)

    return pts[: st.pin_max_count]


def _add_cone(bm, center, direction, height, r1, r2, segments):
    rot = direction.to_track_quat('Z', 'Y').to_matrix().to_4x4()
    mat = Matrix.Translation(center) @ rot
    bmesh.ops.create_cone(
        bm, cap_ends=True, cap_tris=False, segments=segments,
        radius1=r1, radius2=r2, depth=height, matrix=mat,
    )


def _add_box(bm, center, size):
    mat = (Matrix.Translation(center)
           @ Matrix.Diagonal((size.x, size.y, size.z, 1.0)))
    bmesh.ops.create_cube(bm, size=1.0, matrix=mat)


def _bake_modifier(context, obj, mod):
    """Evaluate ``obj`` with ``mod`` applied and replace its mesh in place.

    Uses the depsgraph rather than ``bpy.ops.object.modifier_apply`` so it works
    without an active object / correct mode (safe for headless scripting)."""
    dg = context.evaluated_depsgraph_get()
    new_mesh = bpy.data.meshes.new_from_object(obj.evaluated_get(dg))
    old_mesh = obj.data
    obj.modifiers.remove(mod)
    obj.data = new_mesh
    if old_mesh.users == 0:
        bpy.data.meshes.remove(old_mesh)


def apply_boolean(context, obj, cutter, operation='DIFFERENCE', solver='EXACT'):
    mod = obj.modifiers.new("gks_bool", 'BOOLEAN')
    mod.operation = operation
    mod.object = cutter
    try:
        mod.solver = solver
    except TypeError:
        pass
    _bake_modifier(context, obj, mod)


def decimate_object(context, obj, target_tris, skip_under=True):
    """Collapse-decimate ``obj`` down to about ``target_tris`` triangles.

    Returns ``(before, after)`` triangle counts, or ``None`` if the mesh was
    already at/under the target and ``skip_under`` is set.  Destructive (the
    modifier is baked into the mesh)."""
    me = obj.data
    me.calc_loop_triangles()
    before = len(me.loop_triangles)
    if before <= target_tris:
        if skip_under:
            return None
        ratio = 1.0
    else:
        ratio = max(0.0005, target_tris / float(before))
    mod = obj.modifiers.new("gks_decimate", 'DECIMATE')
    mod.decimate_type = 'COLLAPSE'
    mod.ratio = ratio
    _bake_modifier(context, obj, mod)
    obj.data.calc_loop_triangles()
    return before, len(obj.data.loop_triangles)


def decimate_scene(context):
    """Decimate the meshes chosen by the ``decimate_scope`` setting.

    Returns a list of ``(obj, before, after)`` for every mesh actually reduced."""
    st = context.scene.gks
    if st.decimate_scope == 'TARGET':
        target = resolve_target(context)
        objs = [target] if target else []
    elif st.decimate_scope == 'SELECTED':
        objs = [o for o in context.selected_objects if o.type == 'MESH']
    else:
        objs = [o for o in context.scene.objects if o.type == 'MESH'
                and not o.get(SUPPORT_TAG) and not o.get(RAFT_TAG)]
    results = []
    for o in objs:
        res = decimate_object(context, o, st.decimate_target_tris)
        if res is not None:
            results.append((o, res[0], res[1]))
    return results


def _ray_depth(obj, origin, direction, eps=1e-3, max_dist=1e5):
    """Distance from ``origin`` to the first surface of ``obj`` along
    ``direction`` (object-local == world here, meshes are baked). None on miss."""
    hit, loc, _nrm, _idx = obj.ray_cast(origin + direction * eps, direction,
                                        distance=max_dist)
    if not hit:
        return None
    return (loc - origin).length


def _axis_clearance(obj, base, axis, radius, u, v, samples=6):
    """Usable material depth along ``+axis`` over the whole dowel footprint.

    Casts from the centre plus a ring of ``samples`` points at ``radius`` and
    returns the MIN depth, so a pin near a sloped/curved wall is shortened to
    where its *edge* would exit -- not just its centre.  Returns None if the
    centre misses (no material); a ring ray that misses counts as depth 0."""
    d0 = _ray_depth(obj, base, axis)
    if d0 is None:
        return None
    depths = [d0]
    for k in range(samples):
        a = 2.0 * math.pi * k / samples
        off = (u * math.cos(a) + v * math.sin(a)) * radius
        d = _ray_depth(obj, base + off, axis)
        depths.append(d if d is not None else 0.0)
    return min(depths)


# depth-fit tolerances (mm)
_WALL_MARGIN = 0.8      # keep pin tip this far from the far wall
_MIN_SOCKET = 1.8       # skip a point if the socket side is thinner than this
_MIN_EMBED_MAT = 0.6    # skip a point if the pin side is thinner than this


def generate_dowels(context):
    """Generate dowels across every cut.

    Pins are boolean-UNIONed into their host part and matching sockets are
    DIFFERENCEd from the mating part, so both stay single watertight manifolds.
    With ``pin_two_sided`` the pin direction alternates per point (both parts
    carry pins).  With ``pin_auto_depth`` the depth/embed are clamped to the
    local wall thickness (ray-cast) and too-thin points are skipped.
    """
    st = context.scene.gks
    clear_dowel_preview(context)
    parts = get_parts(context)
    if not parts:
        raise RuntimeError("No split parts found. Run Split first.")
    for p in parts:
        bake_transform(p)

    interfaces = find_interfaces(context, parts)
    if not interfaces:
        raise RuntimeError(
            "No cut interfaces found. Keep the cut planes in the scene.")

    pin_r = max((st.pin_diameter - st.clearance) * 0.5, 0.05)
    socket_r = st.pin_diameter * 0.5
    tip_r = pin_r * (0.6 if st.pin_type == 'TAPER' else 1.0)
    seg = st.pin_segments

    # Accumulate all pin / socket geometry per host object, then apply one
    # UNION and one DIFFERENCE per object at the end.
    pin_bm = {}
    sock_bm = {}

    def _acc(store, obj):
        bm = store.get(obj.name)
        if bm is None:
            bm = store[obj.name] = bmesh.new()
        return bm

    total_pins = 0
    for iface in interfaces:
        obj_a, obj_b = iface["A"], iface["B"]
        co, no = iface["co"], iface["no"]
        cap = iface["cap"]
        u, v = cap["u"], cap["v"]
        cutter = cap.get("cutter")
        points = _interface_points_2d(iface, st)

        for i, p2d in enumerate(points):
            base = co + u * p2d.x + v * p2d.y
            axis = no
            if cutter is not None:  # curved cut: follow the real surface
                base, axis = _project_to_cutter(cutter, base, no)
            if st.pin_two_sided and (i % 2 == 1):
                pin_host, sock_host, pdir = obj_b, obj_a, -axis
            else:
                pin_host, sock_host, pdir = obj_a, obj_b, axis

            protrude, embed = st.pin_depth, st.pin_embed
            if st.pin_auto_depth:
                if cutter is not None:
                    # Curved cut: a u,v ring leaves the surface and hits the near
                    # wall, so measure wall thickness with a single axial ray
                    # from the (surface-projected) base along the local normal.
                    d_into = _ray_depth(sock_host, base, pdir)
                    d_back = _ray_depth(pin_host, base, -pdir)
                else:
                    # Flat cut: sample the whole socket footprint (radius
                    # socket_r) so the pin never pokes through a sloped wall.
                    d_into = _axis_clearance(sock_host, base, pdir, socket_r, u, v)
                    d_back = _axis_clearance(pin_host, base, -pdir, socket_r, u, v)
                if (d_into is None or d_back is None
                        or d_into < _MIN_SOCKET or d_back < _MIN_EMBED_MAT):
                    continue
                protrude = min(st.pin_depth, max(1.0, d_into - _WALL_MARGIN))
                embed = min(st.pin_embed, max(0.0, d_back - _MIN_EMBED_MAT))
                sock_depth = min(protrude + 0.5, d_into - 0.3)
            else:
                sock_depth = protrude + max(st.clearance, 0.0) + 0.2

            # pin: from base - pdir*embed (into pin_host) to base + pdir*protrude
            height = protrude + embed
            center = base + pdir * ((protrude - embed) * 0.5)
            _add_cone(_acc(pin_bm, pin_host), center, pdir, height,
                      pin_r, tip_r, seg)

            # socket cutter: from base - pdir*0.3 to base + pdir*sock_depth
            s_center = base + pdir * ((sock_depth - 0.3) * 0.5)
            _add_cone(_acc(sock_bm, sock_host), s_center, pdir, sock_depth + 0.3,
                      socket_r, socket_r, seg)
            total_pins += 1

    objs = {o.name: o for o in parts}
    # UNION pins first, then DIFFERENCE sockets (independent xy locations).
    for name, bm in pin_bm.items():
        if len(bm.verts) == 0:
            bm.free()
            continue
        mesh = bpy.data.meshes.new("GKS_Pins")
        bm.to_mesh(mesh)
        bm.free()
        adder = bpy.data.objects.new("GKS_Pins", mesh)
        context.scene.collection.objects.link(adder)
        apply_boolean(context, objs[name], adder, 'UNION', st.bool_solver)
        remove_object(adder)
    for name, bm in sock_bm.items():
        if len(bm.verts) == 0:
            bm.free()
            continue
        mesh = bpy.data.meshes.new("GKS_SocketCutter")
        bm.to_mesh(mesh)
        bm.free()
        cutter = bpy.data.objects.new("GKS_SocketCutter", mesh)
        context.scene.collection.objects.link(cutter)
        apply_boolean(context, objs[name], cutter, 'DIFFERENCE', st.bool_solver)
        remove_object(cutter)

    return total_pins


# Heavy interface extraction is cached here so that changing a dowel setting (or
# adding/moving a manual dowel Empty) only re-runs the cheap wireframe geometry.
_PREVIEW_CACHE = []   # list of {"cap","co","no","cutter_name","cut_name"}
_PREVIEW_COUNT = 0    # pins drawn in the last rebuild (panel readout)
_rebuild_pending = False


def dowel_preview_active():
    return bool(_PREVIEW_CACHE)


def dowel_preview_count():
    return _PREVIEW_COUNT


def _remove_dowel_preview_objects(context):
    for o in list(context.scene.objects):
        if o.get(DOWEL_PREVIEW_TAG):
            remove_object(o)


def clear_dowel_preview(context):
    """Remove the preview geometry AND stop live updates (empties the cache)."""
    global _PREVIEW_COUNT
    _remove_dowel_preview_objects(context)
    _PREVIEW_CACHE.clear()
    _PREVIEW_COUNT = 0


def preview_dowels(context):
    """Non-destructively show where pins would go, and start live updates.

    The interface cross-sections are computed once and cached; afterwards any
    dowel-setting change (or added/removed manual dowel point) rebuilds only the
    wireframe via :func:`schedule_dowel_preview_rebuild`.  Returns the pin count.
    """
    clear_dowel_preview(context)
    parts = get_parts(context)
    if not parts:
        raise RuntimeError("No split parts found. Run Split first.")
    interfaces = find_interfaces(context, parts)
    if not interfaces:
        raise RuntimeError(
            "No cut interfaces found. Keep the cut planes/cutters in the scene.")
    for iface in interfaces:
        cut = iface.get("cut")
        cutter = iface["cap"].get("cutter")
        _PREVIEW_CACHE.append({
            "cap": iface["cap"], "co": iface["co"], "no": iface["no"],
            "cutter_name": cutter.name if cutter else None,
            "cut_name": cut.name if cut else None,
        })
    return _redraw_dowel_preview(context)


def _redraw_dowel_preview(context):
    """Cheap rebuild of the wireframe pins from the cache + current settings."""
    global _PREVIEW_COUNT
    _remove_dowel_preview_objects(context)
    st = context.scene.gks
    pin_r = max((st.pin_diameter - st.clearance) * 0.5, 0.05)
    tip_r = pin_r * (0.6 if st.pin_type == 'TAPER' else 1.0)
    out = bmesh.new()
    total = 0
    for e in _PREVIEW_CACHE:
        cap, co, no = e["cap"], e["co"], e["no"]
        u, v = cap["u"], cap["v"]
        cutter = (bpy.data.objects.get(e["cutter_name"])
                  if e["cutter_name"] else None)
        cut = bpy.data.objects.get(e["cut_name"]) if e["cut_name"] else None
        manual = cut_dowel_points(cut)
        if manual:
            pts = [Vector(((mp - co).dot(u), (mp - co).dot(v))) for mp in manual]
        else:
            pts = _grid_candidates(cap, st)
        for p2d in pts:
            base = co + u * p2d.x + v * p2d.y
            axis = no
            if cutter is not None:
                base, axis = _project_to_cutter(cutter, base, no)
            height = st.pin_depth + st.pin_embed
            center = base + axis * ((st.pin_depth - st.pin_embed) * 0.5)
            _add_cone(out, center, axis, height, pin_r, tip_r, st.pin_segments)
            total += 1
    if total:
        mesh = bpy.data.meshes.new("GKS_DowelPreview")
        out.to_mesh(mesh)
        out.free()
        obj = bpy.data.objects.new("GKS_DowelPreview", mesh)
        obj[DOWEL_PREVIEW_TAG] = True
        obj.display_type = 'WIRE'
        obj.show_in_front = True
        obj.hide_select = True
        get_collection(context, "GKS_Preview").objects.link(obj)
    else:
        out.free()
    _PREVIEW_COUNT = total
    _tag_view3d_redraw()
    return total


def _tag_view3d_redraw():
    wm = bpy.context.window_manager
    if wm is None:
        return
    for win in wm.windows:
        for area in win.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def schedule_dowel_preview_rebuild():
    """Queue one coalesced preview rebuild if a preview is active.  Safe to call
    from a property ``update=`` callback (the actual rebuild runs on a timer)."""
    global _rebuild_pending
    if not _PREVIEW_CACHE or _rebuild_pending:
        return
    _rebuild_pending = True
    bpy.app.timers.register(_dowel_preview_timer, first_interval=0.0)


def _dowel_preview_timer():
    global _rebuild_pending
    _rebuild_pending = False
    if _PREVIEW_CACHE:
        try:
            _redraw_dowel_preview(bpy.context)
        except Exception:
            pass
    return None


def add_dowel_point(context):
    """Drop a manual dowel marker (Empty) at the 3D cursor, parented to the
    active cut plane/cutter so its position rides along with the cut."""
    cut = context.view_layer.objects.active
    if cut is None or not (cut.get(PLANE_TAG) or cut.get(CUTTER_TAG)):
        raise RuntimeError("Select a cut plane or cutter first, then add a "
                           "dowel point.")
    empty = bpy.data.objects.new("GKS_DowelPt", None)
    empty.empty_display_type = 'SPHERE'
    empty.empty_display_size = max(context.scene.gks.pin_diameter, 1.0)
    empty[DOWELPT_TAG] = True
    for coll in cut.users_collection:
        coll.objects.link(empty)
        break
    else:
        context.scene.collection.objects.link(empty)
    empty.matrix_world = Matrix.Translation(context.scene.cursor.location)
    empty.parent = cut
    empty.matrix_parent_inverse = cut.matrix_world.inverted()
    schedule_dowel_preview_rebuild()
    return empty


def reset_preview_state():
    """Drop cached preview state (call on unregister)."""
    global _PREVIEW_COUNT, _rebuild_pending
    _PREVIEW_CACHE.clear()
    _PREVIEW_COUNT = 0
    _rebuild_pending = False


# --------------------------------------------------------------------------- #
# Orientation optimization
# --------------------------------------------------------------------------- #
def _collect_triangles(objs):
    import numpy as np
    tris = []
    for o in objs:
        bm = bmesh.new()
        bm.from_mesh(o.data)
        bm.transform(o.matrix_world)
        bmesh.ops.triangulate(bm, faces=bm.faces)
        for f in bm.faces:
            tris.append([[c for c in vt.co] for vt in f.verts])
        bm.free()
    return np.asarray(tris, dtype="f8")  # (M, 3, 3)


def _rot_matrix(ax_deg, ay_deg):
    import numpy as np
    m = Euler((math.radians(ax_deg), math.radians(ay_deg), 0.0), 'XYZ').to_matrix()
    return np.asarray(m, dtype="f8")


def _orient_eval(V, ax, ay, down_thr):
    """Evaluate one orientation. Returns (metric, overhang_area, support_vol)."""
    import numpy as np
    R = _rot_matrix(ax, ay)
    Vr = V @ R.T
    e1 = Vr[:, 1] - Vr[:, 0]
    e2 = Vr[:, 2] - Vr[:, 0]
    n = np.cross(e1, e2)
    area = 0.5 * np.linalg.norm(n, axis=1)
    nz = np.divide(n[:, 2], 2.0 * area + 1e-12)
    zc = Vr[:, :, 2].mean(axis=1)
    plate_z = Vr[:, :, 2].min()
    down = nz < -down_thr
    oh_area = float(area[down].sum())
    supp_vol = float((area[down] * (zc[down] - plate_z)).sum())
    height = float(Vr[:, :, 2].max() - plate_z)
    metric = oh_area + 0.1 * supp_vol + 0.5 * height
    return metric, oh_area, supp_vol


_ORIENT_NEIGHBORS = ((1, 0), (-1, 0), (0, 1), (0, -1),
                     (1, 1), (1, -1), (-1, 1), (-1, -1))


def _orient_refine(V, ax0, ay0, down_thr, step0, min_step=1.0):
    """Pattern-search refinement from a coarse start; shrinks the step until
    no neighbour improves.  Returns (metric, ax, ay)."""
    best = (_orient_eval(V, ax0, ay0, down_thr)[0], float(ax0), float(ay0))
    step = step0 * 0.5
    while step >= min_step:
        cand = min(
            ((_orient_eval(V, best[1] + dx * step, best[2] + dy * step,
                           down_thr)[0], best[1] + dx * step, best[2] + dy * step)
             for dx, dy in _ORIENT_NEIGHBORS),
            key=lambda c: c[0])
        if cand[0] < best[0] - 1e-9:
            best = cand
        else:
            step *= 0.5
    return best


def _angles_close(a, b, tol=4.0):
    da = abs(((a[0] - b[0] + 180.0) % 360.0) - 180.0)
    db = abs(((a[1] - b[1] + 180.0) % 360.0) - 180.0)
    return da <= tol and db <= tol


def optimize_orientation(context, top=3):
    """Coarse grid search followed by local pattern-search refinement of the
    best starts.  Returns top candidates [(metric, ax, ay, oh, vol)]."""
    st = context.scene.gks
    objs = [o for o in context.selected_objects
            if o.type == 'MESH' and o.get(PART_TAG)] or get_parts(context)
    if not objs:
        raise RuntimeError("No parts to orient.")

    V = _collect_triangles(objs)
    if V.size == 0:
        raise RuntimeError("Selected parts have no geometry.")

    down_thr = math.cos(math.radians(90.0 - st.overhang_angle))
    step = st.orient_step

    coarse = []
    for ax in range(0, 180, step):
        for ay in range(0, 360, step):
            m, oh, vol = _orient_eval(V, ax, ay, down_thr)
            coarse.append((m, float(ax), float(ay), oh, vol))
    coarse.sort(key=lambda r: r[0])

    # locally refine the best few coarse starts, then merge with the grid
    candidates = list(coarse)
    for m, ax, ay, _oh, _vol in coarse[:max(top, 3)]:
        rm, rax, ray = _orient_refine(V, ax, ay, down_thr, step)
        _m, roh, rvol = _orient_eval(V, rax, ray, down_thr)
        candidates.append((rm, round(rax % 360, 1), round(ray % 360, 1),
                           roh, rvol))
    candidates.sort(key=lambda r: r[0])

    out = []
    for c in candidates:
        if not any(_angles_close((c[1], c[2]), (o[1], o[2])) for o in out):
            out.append(c)
        if len(out) >= top:
            break
    return out


def apply_orientation(context, ax_deg, ay_deg):
    objs = [o for o in context.selected_objects
            if o.type == 'MESH' and o.get(PART_TAG)] or get_parts(context)
    corners = [o.matrix_world @ Vector(c) for o in objs for c in o.bound_box]
    center = sum(corners, Vector()) / len(corners)
    R = Euler((math.radians(ax_deg), math.radians(ay_deg), 0.0),
              'XYZ').to_matrix().to_4x4()
    pivot = Matrix.Translation(center) @ R @ Matrix.Translation(-center)
    for o in objs:
        o.matrix_world = pivot @ o.matrix_world


# --------------------------------------------------------------------------- #
# Supports (simplified)
# --------------------------------------------------------------------------- #
def _overhang_contacts(objs, overhang_angle, spacing):
    """Return sampled (contact_point, plate_z) for downward-facing faces."""
    down_thr = math.cos(math.radians(90.0 - overhang_angle))
    plate_z = min(
        (o.matrix_world @ Vector(c)).z for o in objs for c in o.bound_box)

    raw = []
    for o in objs:
        bm = bmesh.new()
        bm.from_mesh(o.data)
        bm.transform(o.matrix_world)
        bmesh.ops.triangulate(bm, faces=bm.faces)
        bm.normal_update()
        for f in bm.faces:
            if f.normal.z < -down_thr:
                c = f.calc_center_median()
                if c.z > plate_z + max(spacing * 0.25, 0.5):
                    raw.append(c.copy())
        bm.free()

    # greedy spatial thinning
    kept = []
    for p in sorted(raw, key=lambda v: v.z):
        if all((p - q).xy.length >= spacing for q in kept):
            kept.append(p)
    return kept, plate_z


def _model_bvh(objs):
    """Combined BVH tree of all part meshes in world space (baked == local)."""
    from mathutils.bvhtree import BVHTree
    verts, faces = [], []
    for o in objs:
        base = len(verts)
        mw = o.matrix_world
        me = o.data
        verts.extend(mw @ v.co for v in me.vertices)
        for poly in me.polygons:
            faces.append([base + i for i in poly.vertices])
    return BVHTree.FromPolygons(verts, faces)


def _clear_path(bvh, a, b, skin=0.5):
    """True if the segment a->b does not pass through the model (endpoints,
    which may sit on the surface, are excluded via ``skin``)."""
    d = b - a
    length = d.length
    if length <= 2.0 * skin:
        return True
    direction = d / length
    hit = bvh.ray_cast(a + direction * skin, direction, length - 2.0 * skin)
    return hit[0] is None


def _ray_down_hit(bvh, top, plate_z, skin=0.5):
    span = top.z - plate_z
    if span <= skin:
        return None
    hit = bvh.ray_cast(top + Vector((0, 0, -skin)), Vector((0, 0, -1.0)),
                       span - skin)
    return hit[0].copy() if hit[0] is not None else None


def _drop_to_plate(bvh, top, plate_z, max_angle_deg):
    """Find where a support from ``top`` should land.

    Returns (landing, reached_plate).  Prefers a clear vertical drop; if the
    model is in the way, tries progressively wider angled landings (within
    ``max_angle_deg`` of vertical); if still blocked, rests on the model
    surface directly below."""
    plate = Vector((top.x, top.y, plate_z))
    if bvh is None or _clear_path(bvh, top, plate):
        return plate, True
    max_r = max((top.z - plate_z) * math.tan(math.radians(max_angle_deg)), 0.0)
    r = 2.0
    while r <= max_r:
        for k in range(8):
            ang = 2.0 * math.pi * k / 8.0
            land = Vector((top.x + r * math.cos(ang),
                           top.y + r * math.sin(ang), plate_z))
            if _clear_path(bvh, top, land):
                return land, True
        r += 2.0
    hit = _ray_down_hit(bvh, top, plate_z)
    if hit is not None:
        return hit, False
    return plate, True


def _cones_to_mesh(cones, segs=8):
    """Build one mesh from a list of tapered cones (start, end, r_start, r_end)."""
    bm = bmesh.new()
    for a, b, r1, r2 in cones:
        direction = (b - a)
        length = direction.length
        if length < 1e-4:
            continue
        _add_cone(bm, (a + b) * 0.5, direction.normalized(), length,
                  max(r1, 1e-3), max(r2, 1e-3), segs)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    mesh = bpy.data.meshes.new("GKS_Supports")
    bm.to_mesh(mesh)
    bm.free()
    return mesh


def _foot_cone(bvh, node, plate_z, angle_deg, tip_r):
    """A node's drop to the plate, routed around the model when ``bvh`` given."""
    land, reached = _drop_to_plate(bvh, node["pos"], plate_z, angle_deg)
    base_r = max(node["r"] * 1.6, tip_r) if reached else node["r"]
    return (node["pos"].copy(), land, node["r"], base_r)


def _build_tree(contacts, plate_z, tip_r, angle_deg, max_span, bvh=None):
    """Agglomerative support tree.

    Repeatedly merge the closest pair of nodes into a junction placed as high
    as the branch-angle limit allows, growing the radius to preserve
    cross-sectional area (area-preserving Murray-style taper).  A pair is only
    merged when both branches clear the model (``bvh``); otherwise, or when the
    pair is farther apart than ``max_span``, one node is dropped to the plate.
    Returns a list of tapered cones (start, end, r_start, r_end)."""
    tan_t = max(math.tan(math.radians(angle_deg)), 1e-3)
    nodes = [{"pos": c.copy(), "r": tip_r} for c in contacts]
    cones = []

    while len(nodes) > 1:
        best = None
        for i in range(len(nodes)):
            for j in range(i + 1, len(nodes)):
                d = (nodes[i]["pos"].xy - nodes[j]["pos"].xy).length
                if best is None or d < best[0]:
                    best = (d, i, j)
        dxy, i, j = best
        ni, nj = nodes[i], nodes[j]
        merged = None
        if dxy <= max_span:
            wi, wj = ni["r"] ** 2, nj["r"] ** 2
            jx = (ni["pos"].x * wi + nj["pos"].x * wj) / (wi + wj)
            jy = (ni["pos"].y * wi + nj["pos"].y * wj) / (wi + wj)
            hi = math.hypot(ni["pos"].x - jx, ni["pos"].y - jy)
            hj = math.hypot(nj["pos"].x - jx, nj["pos"].y - jy)
            jz = max(min(ni["pos"].z - hi / tan_t, nj["pos"].z - hj / tan_t),
                     plate_z)
            junction = Vector((jx, jy, jz))
            if bvh is None or (_clear_path(bvh, ni["pos"], junction)
                               and _clear_path(bvh, nj["pos"], junction)):
                merged = junction
        if merged is not None:
            merged_r = min(math.sqrt(ni["r"] ** 2 + nj["r"] ** 2), tip_r * 3.0)
            cones.append((ni["pos"].copy(), merged.copy(), ni["r"], merged_r))
            cones.append((nj["pos"].copy(), merged.copy(), nj["r"], merged_r))
            nodes = [n for k, n in enumerate(nodes) if k not in (i, j)]
            nodes.append({"pos": merged, "r": merged_r})
        else:
            # cannot merge this pair: drop one node to the plate and move on
            cones.append(_foot_cone(bvh, nodes.pop(i), plate_z, angle_deg, tip_r))

    for n in nodes:
        cones.append(_foot_cone(bvh, n, plate_z, angle_deg, tip_r))
    return cones


def add_marker(context):
    """Drop an Empty at the 3D cursor marking a manual support location."""
    empty = bpy.data.objects.new("GKS_Marker", None)
    empty.empty_display_type = 'SPHERE'
    empty.empty_display_size = 2.0
    empty.location = context.scene.cursor.location.copy()
    empty[MARKER_TAG] = True
    get_collection(context, "GKS_Markers").objects.link(empty)
    return empty


def clear_markers(context):
    n = 0
    for o in list(context.scene.objects):
        if o.get(MARKER_TAG):
            remove_object(o)
            n += 1
    return n


def _marker_contacts(context):
    return [o.matrix_world.translation.copy()
            for o in context.scene.objects if o.get(MARKER_TAG)]


def _base_points(cones, drop_z, tol=1e-3):
    """XY of every support foot that reached the plate/raft top (z ~= drop_z)."""
    return [(c[1].x, c[1].y) for c in cones if abs(c[1].z - drop_z) <= tol]


def _build_raft(context, base_points, plate_z, st):
    """Box platform under the supports, from ``plate_z`` up ``raft_thickness``,
    optionally perforated with a hole grid (holes kept clear of support feet)."""
    if not base_points:
        return None
    thick = st.raft_thickness
    margin = st.raft_margin
    xs = [p[0] for p in base_points]
    ys = [p[1] for p in base_points]
    x0, x1 = min(xs) - margin, max(xs) + margin
    y0, y1 = min(ys) - margin, max(ys) + margin
    top = plate_z + thick
    cz = (plate_z + top) * 0.5

    bm = bmesh.new()
    _add_box(bm, Vector(((x0 + x1) * 0.5, (y0 + y1) * 0.5, cz)),
             Vector((x1 - x0, y1 - y0, thick)))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    mesh = bpy.data.meshes.new("GKS_Raft")
    bm.to_mesh(mesh)
    bm.free()
    raft = bpy.data.objects.new("GKS_Raft", mesh)
    raft[RAFT_TAG] = True
    get_collection(context, "GKS_Supports").objects.link(raft)

    if st.raft_perforate:
        pitch = st.raft_hole_pitch
        hole = st.raft_hole_size
        clear = hole * 0.5 + st.support_radius * 1.5
        cbm = bmesh.new()
        holes = 0
        x = x0 + pitch
        while x < x1:
            y = y0 + pitch
            while y < y1:
                edge_ok = (x - x0 > hole and x1 - x > hole
                           and y - y0 > hole and y1 - y > hole)
                far_ok = all((x - bx) ** 2 + (y - by) ** 2 >= clear ** 2
                             for bx, by in base_points)
                if edge_ok and far_ok:
                    _add_box(cbm, Vector((x, y, cz)),
                             Vector((hole, hole, thick + 0.4)))
                    holes += 1
                y += pitch
            x += pitch
        if holes:
            cmesh = bpy.data.meshes.new("GKS_RaftHoles")
            cbm.to_mesh(cmesh)
            cbm.free()
            cutter = bpy.data.objects.new("GKS_RaftHoles", cmesh)
            context.scene.collection.objects.link(cutter)
            apply_boolean(context, raft, cutter, 'DIFFERENCE', st.bool_solver)
            remove_object(cutter)
        else:
            cbm.free()
    return raft


def generate_supports(context):
    """Build supports for every overhang plus any manual markers, optionally on
    a raft.  Returns ``{"contacts": n, "raft": bool}``."""
    st = context.scene.gks
    objs = [o for o in context.selected_objects
            if o.type == 'MESH' and o.get(PART_TAG)] or get_parts(context)
    if not objs:
        raise RuntimeError("No parts to support.")
    for o in objs:
        bake_transform(o)

    contacts, plate_z = _overhang_contacts(objs, st.overhang_angle,
                                           st.support_spacing)
    contacts = contacts + _marker_contacts(context)
    if not contacts:
        return {"contacts": 0, "raft": False}

    # With a raft, supports bottom out on the raft top rather than the plate.
    drop_z = plate_z + st.raft_thickness if st.raft_enable else plate_z
    bvh = _model_bvh(objs) if st.support_avoid_collision else None

    if st.support_type == 'POINT':
        # independent columns; route around the model and flare the foot
        cones = []
        for c in contacts:
            land, reached = _drop_to_plate(bvh, c, drop_z, 45.0)
            base_r = st.support_radius * 1.6 if reached else st.support_radius
            cones.append((c.copy(), land, st.support_radius, base_r))
    else:  # TREE
        cones = _build_tree(contacts, drop_z, st.support_radius,
                            st.tree_angle, st.support_spacing * 3.0, bvh)

    mesh = _cones_to_mesh(cones)
    obj = bpy.data.objects.new("GKS_Supports", mesh)
    obj[SUPPORT_TAG] = True
    get_collection(context, "GKS_Supports").objects.link(obj)

    raft = None
    if st.raft_enable:
        raft = _build_raft(context, _base_points(cones, drop_z), plate_z, st)
    return {"contacts": len(contacts), "raft": raft is not None}


def estimate_resin_volume(context):
    """Estimate resin usage as ``(model_ml, support_ml)``.

    1 Blender unit is treated as 1 mm (GENERIC preset); overlapping support
    solids are counted twice so the support figure is a slight over-estimate."""
    dg = context.evaluated_depsgraph_get()

    def vol(o):
        ev = o.evaluated_get(dg)
        me = ev.to_mesh()
        bm = bmesh.new()
        bm.from_mesh(me)
        bm.transform(o.matrix_world)
        v = bm.calc_volume(signed=False)
        bm.free()
        ev.to_mesh_clear()
        return v

    factor = 1.0 / 1000.0  # mm^3 -> mL
    model = sum(vol(o) for o in get_parts(context))
    supp = sum(vol(o) for o in context.scene.objects
               if o.get(SUPPORT_TAG) or o.get(RAFT_TAG))
    return model * factor, supp * factor


# --------------------------------------------------------------------------- #
# Overhang visualization (weight paint)
# --------------------------------------------------------------------------- #
def _overhang_severity(normal_z, sin_thresh):
    down = -normal_z
    if down <= sin_thresh:
        return 0.0
    return (down - sin_thresh) / (1.0 - sin_thresh + 1e-9)


def compute_vertex_weights(obj, overhang_angle, bottom_emphasis):
    """Per-vertex 0..1 weight = worst overhang severity of its adjacent faces,
    boosted for lower faces.  Index-aligned with ``obj.data.vertices``."""
    me = obj.data
    n = len(me.vertices)
    weights = [0.0] * n
    if n == 0:
        return weights
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.transform(obj.matrix_world)
    bm.normal_update()
    bm.verts.ensure_lookup_table()
    sin_thresh = math.sin(math.radians(overhang_angle))
    zs = [v.co.z for v in bm.verts]
    z_min, z_max = min(zs), max(zs)
    span = z_max - z_min
    for f in bm.faces:
        sev = _overhang_severity(f.normal.z, sin_thresh)
        if sev <= 0.0:
            continue
        cz = f.calc_center_median().z
        lowness = (z_max - cz) / span if span > 1e-9 else 1.0
        score = min(1.0, sev + bottom_emphasis * lowness)
        for v in f.verts:
            if score > weights[v.index]:
                weights[v.index] = score
    bm.free()
    return weights


def paint_overhang(context):
    """Write overhang severity into the ``GKS_Overhang`` vertex group and switch
    to Weight Paint so Blender's blue->red ramp shows where support is needed."""
    st = context.scene.gks
    objs = [o for o in context.selected_objects
            if o.type == 'MESH' and o.get(PART_TAG)] or get_parts(context)
    if not objs:
        tgt = resolve_target(context)
        objs = [tgt] if tgt else []
    if not objs:
        raise RuntimeError("No mesh to analyze. Split first or set a Target.")

    for obj in objs:
        weights = compute_vertex_weights(obj, st.overhang_angle,
                                         st.bottom_emphasis)
        vg = (obj.vertex_groups.get(OVERHANG_GROUP)
              or obj.vertex_groups.new(name=OVERHANG_GROUP))
        for i, w in enumerate(weights):
            vg.add([i], w, 'REPLACE')
        obj.vertex_groups.active_index = vg.index

    first = objs[0]
    for o in context.selected_objects:
        o.select_set(False)
    first.select_set(True)
    context.view_layer.objects.active = first
    try:
        if context.mode != 'PAINT_WEIGHT':
            bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
    except RuntimeError:
        pass
    return len(objs)


# --------------------------------------------------------------------------- #
# Fit gauge  (calibration test print)
# --------------------------------------------------------------------------- #
GAUGE_CLEARANCES = [round(0.05 * i, 3) for i in range(7)]  # 0.00 .. 0.30 mm


def make_gauge(context):
    """Build a two-piece tolerance gauge: a pin comb whose pins step through
    GAUGE_CLEARANCES and a socket comb of nominal holes.  Print both, seat each
    pin column into its socket column and pick the clearance whose fit you like.
    Columns are labelled by raised ticks (n ticks = 0.05*n mm).  Returns the
    clearance list."""
    st = context.scene.gks
    clears = GAUGE_CLEARANCES
    dia = st.pin_diameter
    depth = max(st.pin_depth, 4.0)
    seg = st.pin_segments
    n = len(clears)
    pitch = dia + 6.0
    length = pitch * n + 4.0
    base_h = 2.5
    width = dia + 10.0
    x0 = -pitch * (n - 1) / 2.0
    coll = get_collection(context, "GKS_Gauge")
    origin = context.scene.cursor.location.copy()

    def _ticks(bm, x, count, z_top):
        for t in range(count):
            _add_box(bm, Vector((x, width / 2.0 - 1.5 - t * 1.6, z_top - 0.4)),
                     Vector((1.0, 1.0, 1.2)))

    # --- pin comb: base + upright pins (sunk 0.5 mm into the base) + ticks ---
    bm = bmesh.new()
    _add_box(bm, Vector((0.0, 0.0, base_h / 2.0)), Vector((length, width, base_h)))
    for i, c in enumerate(clears):
        x = x0 + i * pitch
        pr = max((dia - c) / 2.0, 0.1)
        _add_cone(bm, Vector((x, 0.0, base_h - 0.5 + depth / 2.0)),
                  Vector((0, 0, 1)), depth, pr, pr, seg)
        _ticks(bm, x, i, base_h)
    pin_mesh = bpy.data.meshes.new("GKS_Gauge_Pins")
    bm.to_mesh(pin_mesh)
    bm.free()
    pin_obj = bpy.data.objects.new("GKS_Gauge_Pins", pin_mesh)
    pin_obj[GAUGE_TAG] = True
    pin_obj.location = origin
    coll.objects.link(pin_obj)

    # --- socket comb: solid base (+ticks), then drill nominal holes ---
    top_z = depth + base_h
    bm = bmesh.new()
    _add_box(bm, Vector((0.0, 0.0, top_z / 2.0)), Vector((length, width, top_z)))
    for i in range(n):
        _ticks(bm, x0 + i * pitch, i, top_z)
    sock_mesh = bpy.data.meshes.new("GKS_Gauge_Sockets")
    bm.to_mesh(sock_mesh)
    bm.free()
    sock_obj = bpy.data.objects.new("GKS_Gauge_Sockets", sock_mesh)
    sock_obj[GAUGE_TAG] = True
    sock_obj.location = origin + Vector((0.0, width + 6.0, 0.0))
    coll.objects.link(sock_obj)

    bm = bmesh.new()
    for i in range(n):
        x = x0 + i * pitch
        _add_cone(bm, Vector((x, 0.0, top_z - depth / 2.0 + 0.3)),
                  Vector((0, 0, 1)), depth + 0.6, dia / 2.0, dia / 2.0, seg)
    cut_mesh = bpy.data.meshes.new("GKS_GaugeCutter")
    bm.to_mesh(cut_mesh)
    bm.free()
    cutter = bpy.data.objects.new("GKS_GaugeCutter", cut_mesh)
    cutter.location = sock_obj.location
    context.scene.collection.objects.link(cutter)
    apply_boolean(context, sock_obj, cutter, 'DIFFERENCE', st.bool_solver)
    remove_object(cutter)
    return clears


# --------------------------------------------------------------------------- #
# Assemble / explode (review)
# --------------------------------------------------------------------------- #
def is_exploded(context):
    return any(o.get(EXPLODE_TAG) for o in get_parts(context))


def explode_parts(context, distance):
    """Push each part radially away from the assembly centre; store the offset
    so it can be reversed.  Returns the number of parts moved."""
    parts = [o for o in get_parts(context) if not o.get(EXPLODE_TAG)]
    if len(get_parts(context)) < 2:
        return 0
    centers = [sum((o.matrix_world @ Vector(c) for c in o.bound_box),
                   Vector()) / 8.0 for o in parts]
    overall = sum(centers, Vector()) / max(len(centers), 1)
    moved = 0
    for o, c in zip(parts, centers):
        d = c - overall
        direction = d.normalized() if d.length > 1e-6 else Vector((0, 0, 1))
        off = direction * distance
        o.location = o.location + off
        o[EXPLODE_TAG] = off[:]
        moved += 1
    return moved


def assemble_parts(context):
    moved = 0
    for o in get_parts(context):
        off = o.get(EXPLODE_TAG)
        if off is None:
            continue
        o.location = o.location - Vector(off[:])
        del o[EXPLODE_TAG]
        moved += 1
    return moved


# --------------------------------------------------------------------------- #
# Preview
# --------------------------------------------------------------------------- #
def clear_preview(context):
    for o in list(context.scene.objects):
        if o.get(PREVIEW_TAG):
            remove_object(o)


def build_preview(context):
    clear_preview(context)
    target = resolve_target(context)
    if target is None:
        raise RuntimeError("No target mesh selected.")
    context.view_layer.update()  # reflect any just-moved plane
    planes = get_cut_planes(context)
    if not planes:
        raise RuntimeError("No cut planes to preview.")

    out = bmesh.new()
    for _plane_obj, co, no in planes:
        bm = bmesh.new()
        bm.from_mesh(target.data)
        bm.transform(target.matrix_world)
        geom = list(bm.verts) + list(bm.edges) + list(bm.faces)
        res = bmesh.ops.bisect_plane(
            bm, geom=geom, dist=1e-6, plane_co=co, plane_no=no,
            clear_inner=False, clear_outer=False)
        vmap = {}
        for g in res["geom_cut"]:
            if isinstance(g, bmesh.types.BMEdge):
                nv = []
                for vt in g.verts:
                    if vt not in vmap:
                        vmap[vt] = out.verts.new(vt.co.copy())
                    nv.append(vmap[vt])
                try:
                    out.edges.new((nv[0], nv[1]))
                except ValueError:
                    pass
        bm.free()

    mesh = bpy.data.meshes.new("GKS_Preview")
    out.to_mesh(mesh)
    out.free()
    obj = bpy.data.objects.new("GKS_Preview", mesh)
    obj[PREVIEW_TAG] = True
    obj.show_in_front = True
    obj.display_type = 'WIRE'
    get_collection(context, "GKS_Preview").objects.link(obj)
    return obj
