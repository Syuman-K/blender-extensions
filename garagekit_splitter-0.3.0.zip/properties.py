"""Scene-level settings for GarageKit Splitter."""

import bpy
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import PropertyGroup


def _mesh_poll(self, obj):
    return obj.type == 'MESH'


def _dowel_preview_update(self, context):
    """Live-refresh the dowel preview when a dowel setting changes."""
    from . import core
    core.schedule_dowel_preview_rebuild()


class GKS_Settings(PropertyGroup):
    # --- Prepare ---
    target: PointerProperty(
        name="Target",
        description="Object to split (defaults to active object if empty)",
        type=bpy.types.Object,
        poll=_mesh_poll,
    )
    clean_normals: BoolProperty(name="Recalc Normals", default=True)
    clean_doubles: BoolProperty(name="Merge Doubles", default=True)
    clean_dist: FloatProperty(
        name="Merge Distance", default=1e-4, min=0.0, precision=5, unit='LENGTH')
    decimate_target_tris: IntProperty(
        name="Target Triangles", default=200000, min=1000, soft_max=5000000,
        description="Reduce heavy meshes to about this many triangles "
                    "(COLLAPSE decimation) so downstream ops stay fast")
    decimate_scope: EnumProperty(
        name="Scope",
        items=[
            ('TARGET', "Target", "Decimate only the split target"),
            ('SELECTED', "Selected", "Decimate every selected mesh"),
            ('ALL', "All Meshes", "Decimate every mesh in the scene"),
        ],
        default='TARGET',
    )

    # --- Dowel ---
    pin_diameter: FloatProperty(
        name="Pin Diameter (mm)", default=2.0, min=0.1, soft_max=20.0,
        update=_dowel_preview_update)
    pin_depth: FloatProperty(
        name="Pin Depth (mm)", default=6.0, min=0.5, soft_max=50.0,
        update=_dowel_preview_update)
    clearance: FloatProperty(
        name="Clearance (mm)", default=0.1, min=-1.0, max=2.0, precision=3,
        description="Radial gap between pin and socket (socket is wider)",
        update=_dowel_preview_update)
    pin_spacing: FloatProperty(
        name="Min Spacing (mm)", default=8.0, min=1.0, soft_max=100.0,
        update=_dowel_preview_update)
    pin_embed: FloatProperty(
        name="Embed Depth (mm)", default=1.5, min=0.0, soft_max=20.0,
        description="How far the pin sinks into its own part",
        update=_dowel_preview_update)
    pin_type: EnumProperty(
        name="Pin Type",
        items=[
            ('CYLINDER', "Cylinder", "Straight cylindrical pin"),
            ('TAPER', "Taper", "Tapered pin (easier to seat)"),
        ],
        default='CYLINDER',
        update=_dowel_preview_update,
    )
    pin_segments: IntProperty(name="Segments", default=24, min=6, max=128,
                              update=_dowel_preview_update)
    pin_max_count: IntProperty(name="Max Pins / Cut", default=20, min=1, max=200,
                               update=_dowel_preview_update)
    pin_two_sided: BoolProperty(
        name="Two-Sided Pins", default=True,
        description="Alternate pin direction across the joint so both parts "
                    "carry pins (stronger, non-directional joint)")
    pin_auto_depth: BoolProperty(
        name="Auto Depth (fit thickness)", default=True,
        description="Clamp pin depth/embed to the local wall thickness via "
                    "ray-cast, and skip points where material is too thin")
    bool_solver: EnumProperty(
        name="Boolean Solver",
        items=[
            ('EXACT', "Exact", "Robust, slower"),
            ('FAST', "Fast", "Fast, less robust"),
        ],
        default='EXACT',
    )

    # --- Print / Orient ---
    orient_step: IntProperty(
        name="Orient Step (deg)", default=15, min=1, max=90)
    overhang_angle: FloatProperty(
        name="Overhang Angle (deg)", default=45.0, min=1.0, max=89.0,
        description="Faces steeper than this need support")
    support_type: EnumProperty(
        name="Support Type",
        items=[
            ('POINT', "Point", "Independent columns to the build plate"),
            ('TREE', "Tree", "Clustered branches merging into a trunk"),
        ],
        default='POINT',
    )
    support_radius: FloatProperty(
        name="Support Radius (mm)", default=0.6, min=0.05, soft_max=5.0)
    support_spacing: FloatProperty(
        name="Support Spacing (mm)", default=4.0, min=0.5, soft_max=50.0)
    tree_angle: FloatProperty(
        name="Tree Branch Angle (deg)", default=40.0, min=5.0, max=75.0,
        description="Max branch tilt from vertical; larger merges more "
                    "aggressively (Tree supports only)")
    support_avoid_collision: BoolProperty(
        name="Avoid Model Collision", default=True,
        description="Route supports around the model (or rest them on it) so "
                    "they never pass straight through the part")
    bottom_emphasis: FloatProperty(
        name="Bottom Emphasis", default=0.3, min=0.0, max=1.0,
        description="Extra overhang-visualization weight given to lower faces "
                    "(they are harder to support), 0 = pure angle")

    # --- Raft ---
    raft_enable: BoolProperty(
        name="Generate Raft", default=False,
        description="Build a base platform under the supports for better plate "
                    "adhesion; supports then land on the raft, not the plate")
    raft_thickness: FloatProperty(
        name="Raft Thickness (mm)", default=1.5, min=0.2, soft_max=10.0)
    raft_margin: FloatProperty(
        name="Raft Margin (mm)", default=3.0, min=0.0, soft_max=30.0,
        description="How far the raft extends past the outermost support foot")
    raft_perforate: BoolProperty(
        name="Perforate", default=True,
        description="Punch a hole grid through the raft to save resin and ease "
                    "removal (holes are skipped around support feet)")
    raft_hole_pitch: FloatProperty(
        name="Hole Pitch (mm)", default=4.0, min=1.0, soft_max=30.0)
    raft_hole_size: FloatProperty(
        name="Hole Size (mm)", default=2.5, min=0.3, soft_max=20.0)

    # --- Review / fit ---
    explode_distance: FloatProperty(
        name="Explode Distance (mm)", default=15.0, min=0.0, soft_max=200.0,
        description="How far apart to push the parts when exploding for review")

    # --- Export ---
    export_dir: StringProperty(
        name="Output Folder", subtype='DIR_PATH', default="//")
    export_preset: EnumProperty(
        name="Preset",
        items=[
            ('GENERIC', "Generic", "1 Blender unit = 1 mm, no build-volume check"),
            ('FORMLABS', "Formlabs Form 3", "145 x 145 x 185 mm"),
            ('FORM4', "Formlabs Form 4", "200 x 125 x 210 mm"),
            ('ANYCUBIC', "Anycubic Photon Mono X", "196 x 122 x 245 mm"),
            ('ANYCUBIC_M5S', "Anycubic Photon Mono M5s", "218 x 123 x 200 mm"),
            ('ELEGOO_SATURN4', "Elegoo Saturn 4 Ultra", "219 x 123 x 220 mm"),
            ('ELEGOO_MARS4', "Elegoo Mars 4 Ultra", "153 x 78 x 165 mm"),
            ('PHROZEN_MINI8K', "Phrozen Sonic Mini 8K", "165 x 72 x 180 mm"),
        ],
        default='GENERIC',
    )
    export_scale: FloatProperty(name="Scale", default=1.0, min=1e-4)
    ascii_stl: BoolProperty(name="ASCII STL", default=False)
    export_all: BoolProperty(
        name="Export All Parts", default=True,
        description="Export every GarageKit part; otherwise only selected")


def register():
    bpy.utils.register_class(GKS_Settings)
    bpy.types.Scene.gks = PointerProperty(type=GKS_Settings)


def unregister():
    del bpy.types.Scene.gks
    bpy.utils.unregister_class(GKS_Settings)
