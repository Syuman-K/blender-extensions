"""N-panel UI for GarageKit Splitter (View3D > Sidebar > GarageKit)."""

import bpy
from bpy.types import Panel

_CATEGORY = "GarageKit"


class _Base:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = _CATEGORY


class GKS_PT_prepare(_Base, Panel):
    bl_idname = "GKS_PT_prepare"
    bl_label = "1 · Prepare"

    def draw(self, context):
        st = context.scene.gks
        layout = self.layout

        row = layout.row(align=True)
        row.prop(st, "target", text="Target")
        row.operator("gks.set_target", text="", icon='EYEDROPPER')

        box = layout.box()
        box.label(text="Mesh Cleaning")
        box.prop(st, "clean_doubles")
        box.prop(st, "clean_dist")
        box.prop(st, "clean_normals")
        box.operator("gks.clean_mesh", icon='BRUSH_DATA')

        box = layout.box()
        box.label(text="Decimate (heavy meshes)")
        box.prop(st, "decimate_scope")
        box.prop(st, "decimate_target_tris")
        box.operator("gks.decimate", icon='MOD_DECIM')

        row = layout.row(align=True)
        row.operator("gks.add_plane", icon='MESH_PLANE')
        row.operator("gks.add_cutter", text="Add Cutter", icon='SURFACE_NCURVE')
        layout.operator("gks.set_cutter", text="Use Selected as Cutter",
                        icon='MOD_BOOLEAN')


class GKS_PT_split(_Base, Panel):
    bl_idname = "GKS_PT_split"
    bl_label = "2 · Split"

    def draw(self, context):
        st = context.scene.gks
        layout = self.layout

        planes = [o for o in context.scene.objects if o.get("gks_plane")]
        cutters = [o for o in context.scene.objects if o.get("gks_cutter")]
        box = layout.box()
        box.label(text="Cuts: {} plane(s), {} cutter(s)".format(
            len(planes), len(cutters)))
        for p in planes:
            box.label(text=p.name, icon='MESH_PLANE')
        for c in cutters:
            box.label(text=c.name, icon='SURFACE_NCURVE')
        if cutters:
            box.operator("gks.clear_cutter", text="Clear Cutters", icon='X')

        row = layout.row(align=True)
        row.operator("gks.preview", icon='HIDE_OFF')
        row.operator("gks.clear_preview", text="", icon='X')

        layout.operator("gks.split", icon='MOD_BOOLEAN')

        parts = [o for o in context.scene.objects if o.get("gks_part")]
        if parts:
            box = layout.box()
            box.label(text="Parts: {}".format(len(parts)))
            for p in parts[:12]:
                box.label(text=p.name, icon='MESH_CUBE')
            if len(parts) >= 2:
                exploded = any(o.get("gks_explode") for o in parts)
                row = box.row(align=True)
                row.prop(st, "explode_distance")
                row.enabled = not exploded
                box.operator(
                    "gks.toggle_explode",
                    text="Assemble Parts" if exploded else "Explode Parts",
                    icon='SNAP_ON' if exploded else 'MOD_EXPLODE')


class GKS_PT_dowel(_Base, Panel):
    bl_idname = "GKS_PT_dowel"
    bl_label = "3 · Dowel"

    def draw(self, context):
        st = context.scene.gks
        layout = self.layout
        col = layout.column(align=True)
        col.prop(st, "pin_type")
        col.prop(st, "pin_diameter")
        col.prop(st, "pin_depth")
        col.prop(st, "clearance")
        col.prop(st, "pin_spacing")
        col.prop(st, "pin_embed")

        col = layout.column(align=True)
        col.prop(st, "pin_two_sided")
        col.prop(st, "pin_auto_depth")

        box = layout.box()
        box.prop(st, "pin_segments")
        box.prop(st, "pin_max_count")
        box.prop(st, "bool_solver")

        row = layout.row(align=True)
        row.operator("gks.preview_dowels", icon='HIDE_OFF')
        row.operator("gks.clear_dowel_preview", text="", icon='X')
        layout.operator("gks.generate_dowels", icon='EMPTY_SINGLE_ARROW')

        layout.separator()
        layout.operator("gks.make_gauge", icon='DRIVER_DISTANCE')


class GKS_PT_print(_Base, Panel):
    bl_idname = "GKS_PT_print"
    bl_label = "4 · Print"

    def draw(self, context):
        st = context.scene.gks
        layout = self.layout

        box = layout.box()
        box.label(text="Orientation")
        box.prop(st, "orient_step")
        box.prop(st, "overhang_angle")
        box.operator("gks.optimize_orientation", icon='ORIENTATION_GIMBAL')
        row = box.row(align=True)
        row.prop(st, "bottom_emphasis")
        row.operator("gks.paint_overhang", text="Show", icon='BRUSH_DATA')

        box = layout.box()
        box.label(text="Supports")
        box.prop(st, "support_type")
        box.prop(st, "support_radius")
        box.prop(st, "support_spacing")
        if st.support_type == 'TREE':
            box.prop(st, "tree_angle")
        box.prop(st, "support_avoid_collision")

        markers = [o for o in context.scene.objects if o.get("gks_marker")]
        row = box.row(align=True)
        row.operator("gks.add_marker",
                     text="Add Marker ({})".format(len(markers)),
                     icon='EMPTY_DATA')
        row.operator("gks.clear_markers", text="", icon='X')

        sub = box.box()
        sub.prop(st, "raft_enable")
        if st.raft_enable:
            sub.prop(st, "raft_thickness")
            sub.prop(st, "raft_margin")
            sub.prop(st, "raft_perforate")
            if st.raft_perforate:
                row = sub.row(align=True)
                row.prop(st, "raft_hole_pitch")
                row.prop(st, "raft_hole_size")

        box.operator("gks.generate_supports", icon='OUTLINER_OB_FORCE_FIELD')
        box.operator("gks.estimate_volume", icon='MOD_FLUIDSIM')

        box = layout.box()
        box.label(text="STL Export")
        box.prop(st, "export_preset")
        box.prop(st, "export_dir")
        box.prop(st, "export_scale")
        box.prop(st, "ascii_stl")
        box.prop(st, "export_all")
        box.operator("gks.export_stl", icon='EXPORT')

        layout.separator()
        layout.operator("gks.cleanup", icon='TRASH')


CLASSES = (
    GKS_PT_prepare,
    GKS_PT_split,
    GKS_PT_dowel,
    GKS_PT_print,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
