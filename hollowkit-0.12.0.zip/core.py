"""HollowKit のコア: Geometry Nodes ノードグループの生成、モディファイアと
マーカー・キャッシュ・プレビューの管理。

処理は 2 段階に分かれ、それぞれ独立した Geometry Nodes ノードグループ/
モディファイアで行う(ユーザ要望の段階分け):

【① 中空化 "HollowKit中空化"】
    ジオメトリ → SDF化 → 内側オフセット → 空洞面メッシュ化 → 小空洞選別
      → (キャッシュ切替) → 軸柱を差し引き → 面反転 → 元ジオメトリと結合
    「中空化を確定」でメッシュへ焼き込んで段階①を終える。

【② 穴あけ "HollowKit穴あけ"】
    ジオメトリ → [穴マーカー → 直方体を矢印方向へ → ブーリアン差(Manifold、
      失敗時 EXACT 自動フォールバック)]
    穴マーカー追加時に自動でモディファイアが付く。確定済みのシェルに対する
    単独ブーリアンだけなので軽い。「穴あけを確定」で焼き込む。

パラメータはグループ入力として公開し、モディファイア入力値として設定する。
"""

import bpy
from mathutils import Vector

# ---- 定数 -------------------------------------------------------------------

NODE_GROUP_HOLLOW = "HollowKit中空化"
NODE_GROUP_DRILL = "HollowKit穴あけ"
NODE_GROUP_HOLEPREV = "HollowKit穴形状"
MOD_HOLLOW = "HollowKit 中空化"
MOD_DRILL = "HollowKit 穴あけ"
MOD_HOLEPREV = "HollowKit 穴形状"
LEGACY_MODIFIER = "HollowKit"     # v0.8 以前の一体型モディファイア名
NG_VERSION = 12                   # ノードグループ構造のバージョン(変更時に再生成)
# 軸穴が中実柱を確実に貫通するよう、前後に足す余裕(mm 相当・シーン単位)。
_BORE_MARGIN = 1.0
# 円柱カッターの分割数。Manifold ソルバーならこの程度でも十分軽い。
_CYL_SEGMENTS = 24

HOLE_COLL_PREFIX = "HK_穴_"       # オブジェクトごとの穴マーカーコレクション接頭辞
HOLE_MARKER_PREFIX = "HK_穴マーカー"
SOLID_COLL_PREFIX = "HK_軸_"      # 軸打ち用・中実柱マーカーコレクション接頭辞
SOLID_MARKER_PREFIX = "HK_軸マーカー"
CACHE_PREFIX = "HK_cache_"        # 中空化キャッシュ(隠しメッシュ)接頭辞
PREVIEW_PREFIX = "HK_プレビュー_"  # 空洞プレビュー物体の接頭辞
HOLEPREV_PREFIX = "HK_穴形状_"    # 穴形状ワイヤプレビュー物体の接頭辞

# グループ入力ソケット名
S_GEO = "ジオメトリ"
S_HOLLOW = "中空化"
S_WALL = "壁厚"
S_VOXEL = "解像度(ボクセル)"
S_ADAPT = "滑らかさ"
S_MIN_CAV = "最小空洞径"
S_ONLY_LARGEST = "最大の空洞のみ"
S_SOLID_COLL = "軸コレクション"
S_SOLID_DIA = "軸柱の幅"
S_SOLID_LEN = "軸柱の長さ"
S_SOLID_BORE = "軸穴の径"
S_SOLID_DRILL = "軸穴を空ける"
S_USE_CACHE = "キャッシュ使用"
S_CACHE_OBJ = "キャッシュ"
S_PREVIEW = "プレビュー出力"     # 内部用: 空洞(+柱)だけを出力(プレビュー物体)
S_CAPTURE = "キャッシュ取得"     # 内部用: 柱を引く前の生空洞を出力(freeze 用)
S_HOLE_DIA = "穴の幅"
S_HOLE_LEN = "穴の長さ"
S_HOLE_COLL = "穴コレクション"


# ---- オブジェクト収集 -------------------------------------------------------

def gather_objects(context, scope):
    """処理対象のメッシュオブジェクトを返す。"""
    if scope == 'ALL':
        pool = context.view_layer.objects
    else:
        pool = context.selected_objects
    return [o for o in pool if o.type == 'MESH']


def max_dimension(obj):
    """オブジェクトのワールド寸法の最大辺を返す(0 は避ける)。"""
    d = obj.dimensions
    return max(d.x, d.y, d.z, 1e-6)


# ---- ノードグループ生成 -----------------------------------------------------

def _new_input(ng, name, socket_type, default=None, min_value=None,
               max_value=None, subtype=None):
    s = ng.interface.new_socket(name, in_out='INPUT', socket_type=socket_type)
    if default is not None:
        s.default_value = default
    if min_value is not None:
        s.min_value = min_value
    if max_value is not None:
        s.max_value = max_value
    if subtype is not None:
        try:
            s.subtype = subtype
        except Exception:
            pass
    return s


def input_identifiers(ng):
    """入力ソケット名 → identifier のマッピングを返す(モディファイア値設定用)。"""
    mapping = {}
    for item in ng.interface.items_tree:
        if getattr(item, 'in_out', None) == 'INPUT' and item.item_type == 'SOCKET':
            mapping[item.name] = item.identifier
    return mapping


def _ensure_group(name, builder, mod_name):
    """ノードグループを取得(無い/構造が古ければ再生成し、モディファイアを移行)。"""
    ng = bpy.data.node_groups.get(name)
    if (ng is not None and ng.bl_idname == 'GeometryNodeTree'
            and ng.get("hk_version") == NG_VERSION):
        return ng
    new = builder()
    if ng is not None:
        for obj in bpy.data.objects:
            mod = obj.modifiers.get(mod_name)
            if mod is not None and mod.type == 'NODES' and mod.node_group == ng:
                mod.node_group = new
        bpy.data.node_groups.remove(ng)
        new.name = name
    return new


def ensure_hollow_group():
    return _ensure_group(NODE_GROUP_HOLLOW, _build_hollow_group, MOD_HOLLOW)


def ensure_drill_group():
    return _ensure_group(NODE_GROUP_DRILL, _build_drill_group, MOD_DRILL)


def ensure_holeprev_group():
    return _ensure_group(NODE_GROUP_HOLEPREV, _build_holeprev_group,
                         MOD_HOLEPREV)


def _make_sampled_rotation(ng, instances_out):
    """マーカーインスタンスの回転を取り出すフィールドを作る。

    Instances to Points は回転属性を運ばないため、Instance on Points の
    Rotation に Input Instance Rotation を直結すると常に単位回転になる。
    ポイント index = 元インスタンス index を利用し、Sample Index
    (QUATERNION, INSTANCE ドメイン)で元から回転を引く。
    """
    N = ng.nodes.new
    L = ng.links.new
    rot = N("GeometryNodeInputInstanceRotation")
    idx = N("GeometryNodeInputIndex")
    si = N("GeometryNodeSampleIndex")
    si.data_type = 'QUATERNION'
    si.domain = 'INSTANCE'
    L(instances_out, si.inputs["Geometry"])
    L(rot.outputs["Rotation"], si.inputs["Value"])
    L(idx.outputs["Index"], si.inputs["Index"])
    return si.outputs["Value"]


def _build_hollow_group():
    """段階①: 中空化 + 小空洞選別 + 軸柱 のノードグループを作る。"""
    ng = bpy.data.node_groups.new(NODE_GROUP_HOLLOW, "GeometryNodeTree")

    _new_input(ng, S_GEO, 'NodeSocketGeometry')
    _new_input(ng, S_HOLLOW, 'NodeSocketBool', default=True)
    _new_input(ng, S_WALL, 'NodeSocketFloat', default=2.0, min_value=0.0,
               subtype='DISTANCE')
    _new_input(ng, S_VOXEL, 'NodeSocketFloat', default=0.3, min_value=1e-5,
               subtype='DISTANCE')
    _new_input(ng, S_ADAPT, 'NodeSocketFloat', default=0.0, min_value=0.0,
               max_value=1.0)
    _new_input(ng, S_ONLY_LARGEST, 'NodeSocketBool', default=True)
    _new_input(ng, S_MIN_CAV, 'NodeSocketFloat', default=3.0, min_value=0.0,
               subtype='DISTANCE')
    _new_input(ng, S_SOLID_COLL, 'NodeSocketCollection')
    _new_input(ng, S_SOLID_DIA, 'NodeSocketFloat', default=5.0, min_value=0.0,
               subtype='DISTANCE')
    _new_input(ng, S_SOLID_LEN, 'NodeSocketFloat', default=10.0, min_value=0.0,
               subtype='DISTANCE')
    _new_input(ng, S_USE_CACHE, 'NodeSocketBool', default=False)
    _new_input(ng, S_CACHE_OBJ, 'NodeSocketObject')
    _new_input(ng, S_PREVIEW, 'NodeSocketBool', default=False)
    _new_input(ng, S_CAPTURE, 'NodeSocketBool', default=False)
    ng.interface.new_socket(S_GEO, in_out='OUTPUT',
                            socket_type='NodeSocketGeometry')

    N = ng.nodes.new
    L = ng.links.new
    gin = N("NodeGroupInput")
    gout = N("NodeGroupOutput")
    gin.location = (-800, 0)
    gout.location = (1400, 0)

    def gi(name):
        return gin.outputs[name]

    # === 空洞の生成 =========================================================
    sdf = N("GeometryNodeMeshToSDFGrid")
    L(gi(S_GEO), sdf.inputs["Mesh"])
    L(gi(S_VOXEL), sdf.inputs["Voxel Size"])

    # バンド幅(ボクセル数) = 壁厚 / ボクセル + 余裕。int ソケットへ暗黙変換。
    band = N("ShaderNodeMath"); band.operation = 'DIVIDE'
    L(gi(S_WALL), band.inputs[0])
    L(gi(S_VOXEL), band.inputs[1])
    band_pad = N("ShaderNodeMath"); band_pad.operation = 'ADD'
    band_pad.inputs[1].default_value = 6.0
    L(band.outputs[0], band_pad.inputs[0])
    L(band_pad.outputs[0], sdf.inputs["Band Width"])

    # 内側へ壁厚ぶんオフセット(距離は負)。
    neg = N("ShaderNodeMath"); neg.operation = 'MULTIPLY'
    neg.inputs[1].default_value = -1.0
    L(gi(S_WALL), neg.inputs[0])
    offset = N("GeometryNodeSDFGridOffset")
    L(sdf.outputs["SDF Grid"], offset.inputs["Grid"])
    L(neg.outputs[0], offset.inputs["Distance"])

    # 空洞面だけメッシュ化する。外側は元メッシュをそのまま使うので、
    # 元のディテールは一切変わらない。
    g2m = N("GeometryNodeGridToMesh")
    g2m.inputs["Threshold"].default_value = 0.0
    L(offset.outputs["Grid"], g2m.inputs["Grid"])
    L(gi(S_ADAPT), g2m.inputs["Adaptivity"])

    # --- 小さい空洞(レジン溜まり)の選別 ---------------------------------
    # 空洞メッシュをアイランド(独立した閉空間)ごとに符号付き体積で測る。
    # 三角形ごとの体積寄与 dot(p0, p1×p2)/6 をアイランド単位で合算する。
    tri = N("GeometryNodeTriangulate")
    L(g2m.outputs["Mesh"], tri.inputs["Mesh"])

    face_idx = N("GeometryNodeInputIndex")
    positions = N("GeometryNodeInputPosition")
    corner_p = []
    for sort in range(3):
        cof = N("GeometryNodeCornersOfFace")
        cof.inputs["Sort Index"].default_value = sort
        L(face_idx.outputs["Index"], cof.inputs["Face Index"])
        voc = N("GeometryNodeVertexOfCorner")
        L(cof.outputs["Corner Index"], voc.inputs["Corner Index"])
        smp = N("GeometryNodeSampleIndex")
        smp.data_type = 'FLOAT_VECTOR'
        smp.domain = 'POINT'
        L(tri.outputs["Mesh"], smp.inputs["Geometry"])
        L(positions.outputs["Position"], smp.inputs["Value"])
        L(voc.outputs["Vertex Index"], smp.inputs["Index"])
        corner_p.append(smp.outputs["Value"])

    cross = N("ShaderNodeVectorMath"); cross.operation = 'CROSS_PRODUCT'
    L(corner_p[1], cross.inputs[0])
    L(corner_p[2], cross.inputs[1])
    dot = N("ShaderNodeVectorMath"); dot.operation = 'DOT_PRODUCT'
    L(corner_p[0], dot.inputs[0])
    L(cross.outputs["Vector"], dot.inputs[1])
    sixth = N("ShaderNodeMath"); sixth.operation = 'DIVIDE'
    sixth.inputs[1].default_value = 6.0
    L(dot.outputs["Value"], sixth.inputs[0])

    island = N("GeometryNodeInputMeshIsland")
    acc = N("GeometryNodeAccumulateField")
    acc.data_type = 'FLOAT'
    acc.domain = 'FACE'
    L(sixth.outputs[0], acc.inputs["Value"])
    L(island.outputs["Island Index"], acc.inputs["Group ID"])
    vol_abs = N("ShaderNodeMath"); vol_abs.operation = 'ABSOLUTE'
    L(acc.outputs["Total"], vol_abs.inputs[0])

    # しきい値体積 = π/6 × 径³ (径の球の体積)。
    d2 = N("ShaderNodeMath"); d2.operation = 'MULTIPLY'
    L(gi(S_MIN_CAV), d2.inputs[0])
    L(gi(S_MIN_CAV), d2.inputs[1])
    d3 = N("ShaderNodeMath"); d3.operation = 'MULTIPLY'
    L(d2.outputs[0], d3.inputs[0])
    L(gi(S_MIN_CAV), d3.inputs[1])
    thr = N("ShaderNodeMath"); thr.operation = 'MULTIPLY'
    thr.inputs[1].default_value = 0.5235988  # π/6
    L(d3.outputs[0], thr.inputs[0])

    small = N("FunctionNodeCompare")
    small.data_type = 'FLOAT'
    small.operation = 'LESS_THAN'
    L(vol_abs.outputs[0], small.inputs[0])
    L(thr.outputs[0], small.inputs[1])

    # 「最大の空洞のみ」モード: 全アイランド中の最大体積を求め、それ未満の
    # アイランドをすべて削除する(同一アイランド内は Accumulate の Total が
    # 全く同じ値になるため、最大アイランドだけが等値=残る)。
    stat = N("GeometryNodeAttributeStatistic")
    stat.data_type = 'FLOAT'
    stat.domain = 'FACE'
    L(tri.outputs["Mesh"], stat.inputs["Geometry"])
    L(vol_abs.outputs[0], stat.inputs["Attribute"])
    not_largest = N("FunctionNodeCompare")
    not_largest.data_type = 'FLOAT'
    not_largest.operation = 'LESS_THAN'
    L(vol_abs.outputs[0], not_largest.inputs[0])
    L(stat.outputs["Max"], not_largest.inputs[1])

    sel = N("GeometryNodeSwitch"); sel.input_type = 'BOOLEAN'
    L(gi(S_ONLY_LARGEST), sel.inputs["Switch"])
    L(small.outputs["Result"], sel.inputs["False"])
    L(not_largest.outputs["Result"], sel.inputs["True"])

    del_small = N("GeometryNodeDeleteGeometry")
    del_small.domain = 'FACE'
    del_small.mode = 'ALL'
    L(tri.outputs["Mesh"], del_small.inputs["Geometry"])
    L(sel.outputs["Output"], del_small.inputs["Selection"])

    # --- 空洞キャッシュ切替 ---------------------------------------------
    # 「キャッシュ使用」時は、確定済みの生空洞(柱を引く前・隠しメッシュ)を
    # 使い、重い SDF 計算を飛ばす。柱はキャッシュの後段なので、軸マーカーは
    # 軽いブーリアンだけで再計算される。
    cache_info = N("GeometryNodeObjectInfo")
    cache_info.transform_space = 'RELATIVE'
    L(gi(S_CACHE_OBJ), cache_info.inputs["Object"])
    sw_cav = N("GeometryNodeSwitch"); sw_cav.input_type = 'GEOMETRY'
    L(gi(S_USE_CACHE), sw_cav.inputs["Switch"])
    L(del_small.outputs["Geometry"], sw_cav.inputs["False"])
    L(cache_info.outputs["Geometry"], sw_cav.inputs["True"])

    # --- 軸打ち用の中実柱(軸マーカー) -----------------------------------
    # 軸マーカーの位置から矢印(+Z)方向へ「軸柱の長さ」の四角柱を作り、
    # 空洞から差し引く。柱の部分は中実のまま残るので軸打ちができる。
    s_col = N("GeometryNodeCollectionInfo")
    s_col.transform_space = 'RELATIVE'
    s_col.inputs["Separate Children"].default_value = True
    s_col.inputs["Reset Children"].default_value = False
    L(gi(S_SOLID_COLL), s_col.inputs["Collection"])
    s_i2p = N("GeometryNodeInstancesToPoints")
    L(s_col.outputs["Instances"], s_i2p.inputs["Instances"])

    # 柱は直方体(8頂点)。曲面のカッターを SDF 由来の空洞メッシュに
    # Manifold ブーリアンすると、ソルバー内部(SplitPinchedVerts)で
    # Blender ごと落ちることを実測で確認したため、ここは直方体のまま。
    # 軸穴(丸穴)は穴あけ段階で空けるので、真鍮線を挿す穴自体は円形になる。
    # 最小肉厚は平らな辺の中央で (軸柱の幅 - 軸穴の径) / 2。
    s_size = N("ShaderNodeCombineXYZ")
    L(gi(S_SOLID_DIA), s_size.inputs["X"])
    L(gi(S_SOLID_DIA), s_size.inputs["Y"])
    L(gi(S_SOLID_LEN), s_size.inputs["Z"])
    s_cube = N("GeometryNodeMeshCube")
    L(s_size.outputs["Vector"], s_cube.inputs["Size"])
    s_half = N("ShaderNodeMath"); s_half.operation = 'DIVIDE'
    s_half.inputs[1].default_value = 2.0
    L(gi(S_SOLID_LEN), s_half.inputs[0])
    s_off = N("ShaderNodeCombineXYZ")
    L(s_half.outputs[0], s_off.inputs["Z"])
    s_tr = N("GeometryNodeTransform")
    L(s_cube.outputs["Mesh"], s_tr.inputs["Geometry"])
    L(s_off.outputs["Vector"], s_tr.inputs["Translation"])

    s_iop = N("GeometryNodeInstanceOnPoints")
    L(s_i2p.outputs["Points"], s_iop.inputs["Points"])
    L(s_tr.outputs["Geometry"], s_iop.inputs["Instance"])
    L(_make_sampled_rotation(ng, s_col.outputs["Instances"]),
      s_iop.inputs["Rotation"])
    s_real = N("GeometryNodeRealizeInstances")
    L(s_iop.outputs["Instances"], s_real.inputs["Geometry"])

    # 空洞(GridToMesh 由来)と直方体は常に水密なので Manifold ソルバーで
    # 高速・水密にくり抜ける。軸マーカーが 0 個ならブーリアン自体を
    # スキップする(空のカッターでソルバーを走らせない)。
    s_bool = N("GeometryNodeMeshBoolean")
    s_bool.operation = 'DIFFERENCE'
    if hasattr(s_bool, "solver"):
        s_bool.solver = 'MANIFOLD'
    L(sw_cav.outputs["Output"], s_bool.inputs["Mesh 1"])
    L(s_real.outputs["Geometry"], s_bool.inputs["Mesh 2"])

    sp_size = N("GeometryNodeAttributeDomainSize")
    sp_size.component = 'POINTCLOUD'
    L(s_i2p.outputs["Points"], sp_size.inputs["Geometry"])
    has_pillars = N("FunctionNodeCompare")
    has_pillars.data_type = 'INT'
    has_pillars.operation = 'GREATER_THAN'
    L(sp_size.outputs["Point Count"], has_pillars.inputs[2])
    has_pillars.inputs[3].default_value = 0
    sw_pil = N("GeometryNodeSwitch"); sw_pil.input_type = 'GEOMETRY'
    L(has_pillars.outputs["Result"], sw_pil.inputs["Switch"])
    L(sw_cav.outputs["Output"], sw_pil.inputs["False"])
    L(s_bool.outputs["Mesh"], sw_pil.inputs["True"])

    # 面を反転して空洞(内向き法線)にし、元ジオメトリと結合して殻にする。
    flip = N("GeometryNodeFlipFaces")
    L(sw_pil.outputs["Output"], flip.inputs["Mesh"])
    join = N("GeometryNodeJoinGeometry")
    L(gi(S_GEO), join.inputs[0])
    L(flip.outputs["Mesh"], join.inputs[0])

    sw_hollow = N("GeometryNodeSwitch"); sw_hollow.input_type = 'GEOMETRY'
    L(gi(S_HOLLOW), sw_hollow.inputs["Switch"])
    L(gi(S_GEO), sw_hollow.inputs["False"])
    L(join.outputs[0], sw_hollow.inputs["True"])

    # --- 出力切替(内部用) -----------------------------------------------
    # プレビュー出力: 空洞(+柱)だけを出す(プレビュー物体のワイヤ表示用)。
    # キャッシュ取得: 柱を引く前の生空洞を出す(freeze がこれを保存する)。
    sw_prev = N("GeometryNodeSwitch"); sw_prev.input_type = 'GEOMETRY'
    L(gi(S_PREVIEW), sw_prev.inputs["Switch"])
    L(sw_hollow.outputs["Output"], sw_prev.inputs["False"])
    L(sw_pil.outputs["Output"], sw_prev.inputs["True"])
    sw_cap = N("GeometryNodeSwitch"); sw_cap.input_type = 'GEOMETRY'
    L(gi(S_CAPTURE), sw_cap.inputs["Switch"])
    L(sw_prev.outputs["Output"], sw_cap.inputs["False"])
    L(del_small.outputs["Geometry"], sw_cap.inputs["True"])

    L(sw_cap.outputs["Output"], gout.inputs[0])
    ng["hk_version"] = NG_VERSION
    return ng


def _make_hole_boxes(ng, gi):
    """穴コレクションのマーカー位置・向きに直方体ドリルを並べるノード列。

    (RealizeInstances ノード, InstancesToPoints ノード) を返す。
    ドリルは直方体(8頂点)。幅=穴の幅、奥行=穴の長さ。マーカー位置から
    矢印(+Z)方向へ伸び、表面ぴったりでも壁を確実に切れるよう後方に
    穴幅ぶんだけはみ出す。
    """
    N = ng.nodes.new
    L = ng.links.new

    colinfo = N("GeometryNodeCollectionInfo")
    colinfo.transform_space = 'RELATIVE'
    colinfo.inputs["Separate Children"].default_value = True
    colinfo.inputs["Reset Children"].default_value = False
    L(gi(S_HOLE_COLL), colinfo.inputs["Collection"])

    i2p = N("GeometryNodeInstancesToPoints")
    L(colinfo.outputs["Instances"], i2p.inputs["Instances"])

    h_size = N("ShaderNodeCombineXYZ")
    L(gi(S_HOLE_DIA), h_size.inputs["X"])
    L(gi(S_HOLE_DIA), h_size.inputs["Y"])
    L(gi(S_HOLE_LEN), h_size.inputs["Z"])
    h_cube = N("GeometryNodeMeshCube")
    L(h_size.outputs["Vector"], h_cube.inputs["Size"])

    h_half = N("ShaderNodeMath"); h_half.operation = 'DIVIDE'
    h_half.inputs[1].default_value = 2.0
    L(gi(S_HOLE_LEN), h_half.inputs[0])
    h_back = N("ShaderNodeMath"); h_back.operation = 'SUBTRACT'
    L(h_half.outputs[0], h_back.inputs[0])
    L(gi(S_HOLE_DIA), h_back.inputs[1])
    h_off = N("ShaderNodeCombineXYZ")
    L(h_back.outputs[0], h_off.inputs["Z"])
    h_tr = N("GeometryNodeTransform")
    L(h_cube.outputs["Mesh"], h_tr.inputs["Geometry"])
    L(h_off.outputs["Vector"], h_tr.inputs["Translation"])

    iop = N("GeometryNodeInstanceOnPoints")
    L(i2p.outputs["Points"], iop.inputs["Points"])
    L(h_tr.outputs["Geometry"], iop.inputs["Instance"])
    L(_make_sampled_rotation(ng, colinfo.outputs["Instances"]),
      iop.inputs["Rotation"])

    realize = N("GeometryNodeRealizeInstances")
    L(iop.outputs["Instances"], realize.inputs["Geometry"])
    return realize, i2p


def _make_axis_bores(ng, gi):
    """軸マーカー位置に「軸打ち用の貫通穴」の円柱ドリルを並べるノード列。

    (RealizeInstances ノード, InstancesToPoints ノード) を返す。

    中実柱(軸柱)の中心を、マーカー位置から矢印(+Z)方向へ貫く円柱。
    柱より前後に ``_BORE_MARGIN`` ぶん長くして、外皮を確実に切り、
    反対側は空洞まで抜けるようにする(貫通型)。こうすると差し込んだ
    真鍮線が空洞に届き、未硬化レジンも軸穴から抜ける。
    """
    N = ng.nodes.new
    L = ng.links.new

    colinfo = N("GeometryNodeCollectionInfo")
    colinfo.transform_space = 'RELATIVE'
    colinfo.inputs["Separate Children"].default_value = True
    colinfo.inputs["Reset Children"].default_value = False
    L(gi(S_SOLID_COLL), colinfo.inputs["Collection"])

    i2p = N("GeometryNodeInstancesToPoints")
    L(colinfo.outputs["Instances"], i2p.inputs["Instances"])

    b_rad = N("ShaderNodeMath"); b_rad.operation = 'DIVIDE'
    b_rad.inputs[1].default_value = 2.0
    L(gi(S_SOLID_BORE), b_rad.inputs[0])
    # 全長 = 軸柱の長さ + 前後の余裕
    b_len = N("ShaderNodeMath"); b_len.operation = 'ADD'
    b_len.inputs[1].default_value = _BORE_MARGIN * 2.0
    L(gi(S_SOLID_LEN), b_len.inputs[0])

    b_cyl = N("GeometryNodeMeshCylinder")
    b_cyl.fill_type = 'TRIANGLE_FAN'
    b_cyl.inputs["Vertices"].default_value = _CYL_SEGMENTS
    L(b_rad.outputs[0], b_cyl.inputs["Radius"])
    L(b_len.outputs[0], b_cyl.inputs["Depth"])

    # 中心原点なので +Z へ半分ずらし、さらに余裕ぶん手前へ戻す。
    b_half = N("ShaderNodeMath"); b_half.operation = 'DIVIDE'
    b_half.inputs[1].default_value = 2.0
    L(b_len.outputs[0], b_half.inputs[0])
    b_back = N("ShaderNodeMath"); b_back.operation = 'SUBTRACT'
    b_back.inputs[1].default_value = _BORE_MARGIN
    L(b_half.outputs[0], b_back.inputs[0])
    b_off = N("ShaderNodeCombineXYZ")
    L(b_back.outputs[0], b_off.inputs["Z"])
    b_tr = N("GeometryNodeTransform")
    L(b_cyl.outputs["Mesh"], b_tr.inputs["Geometry"])
    L(b_off.outputs["Vector"], b_tr.inputs["Translation"])

    iop = N("GeometryNodeInstanceOnPoints")
    L(i2p.outputs["Points"], iop.inputs["Points"])
    L(b_tr.outputs["Geometry"], iop.inputs["Instance"])
    L(_make_sampled_rotation(ng, colinfo.outputs["Instances"]),
      iop.inputs["Rotation"])

    realize = N("GeometryNodeRealizeInstances")
    L(iop.outputs["Instances"], realize.inputs["Geometry"])

    # 「軸穴を空ける」が off なら空のジオメトリを返す(カッターに含めない)。
    sw = N("GeometryNodeSwitch"); sw.input_type = 'GEOMETRY'
    L(gi(S_SOLID_DRILL), sw.inputs["Switch"])
    L(realize.outputs["Geometry"], sw.inputs["True"])
    return sw, i2p


def _build_holeprev_group():
    """穴形状のワイヤプレビュー用ノードグループ(ブーリアン無し=超軽量)。

    マーカー位置・向きに穴の直方体を並べて出すだけ。ワイヤ表示の
    プレビュー物体に載せ、マーカー配置を視覚化する。
    """
    ng = bpy.data.node_groups.new(NODE_GROUP_HOLEPREV, "GeometryNodeTree")
    _new_input(ng, S_GEO, 'NodeSocketGeometry')   # 未使用(モディファイア用)
    _new_input(ng, S_HOLE_DIA, 'NodeSocketFloat', default=2.5, min_value=0.0,
               subtype='DISTANCE')
    _new_input(ng, S_HOLE_LEN, 'NodeSocketFloat', default=30.0, min_value=0.0,
               subtype='DISTANCE')
    _new_input(ng, S_HOLE_COLL, 'NodeSocketCollection')
    ng.interface.new_socket(S_GEO, in_out='OUTPUT',
                            socket_type='NodeSocketGeometry')
    gin = ng.nodes.new("NodeGroupInput")
    gout = ng.nodes.new("NodeGroupOutput")

    def gi(name):
        return gin.outputs[name]

    realize, _ = _make_hole_boxes(ng, gi)
    ng.links.new(realize.outputs["Geometry"], gout.inputs[0])
    ng["hk_version"] = NG_VERSION
    return ng


def _build_drill_group():
    """段階②: 穴あけ専用のノードグループを作る。

    確定済みシェルへの単独ブーリアンだけなので軽い。マーカー 0 個なら
    ブーリアン自体をスキップ。Manifold の結果が空(=対象が水密でない)なら
    EXACT に自動フォールバックする。
    """
    ng = bpy.data.node_groups.new(NODE_GROUP_DRILL, "GeometryNodeTree")

    _new_input(ng, S_GEO, 'NodeSocketGeometry')
    _new_input(ng, S_HOLE_DIA, 'NodeSocketFloat', default=2.5, min_value=0.0,
               subtype='DISTANCE')
    _new_input(ng, S_HOLE_LEN, 'NodeSocketFloat', default=30.0, min_value=0.0,
               subtype='DISTANCE')
    _new_input(ng, S_HOLE_COLL, 'NodeSocketCollection')
    _new_input(ng, S_SOLID_COLL, 'NodeSocketCollection')
    _new_input(ng, S_SOLID_BORE, 'NodeSocketFloat', default=1.2, min_value=0.0,
               subtype='DISTANCE')
    _new_input(ng, S_SOLID_LEN, 'NodeSocketFloat', default=10.0, min_value=0.0,
               subtype='DISTANCE')
    _new_input(ng, S_SOLID_DRILL, 'NodeSocketBool', default=True)
    ng.interface.new_socket(S_GEO, in_out='OUTPUT',
                            socket_type='NodeSocketGeometry')

    N = ng.nodes.new
    L = ng.links.new
    gin = N("NodeGroupInput")
    gout = N("NodeGroupOutput")
    gin.location = (-800, 0)
    gout.location = (1000, 0)

    def gi(name):
        return gin.outputs[name]

    realize, i2p = _make_hole_boxes(ng, gi)
    bores, b_i2p = _make_axis_bores(ng, gi)

    # 排出穴と軸穴をまとめて 1 回のブーリアンで抜く。
    cutters = N("GeometryNodeJoinGeometry")
    L(realize.outputs["Geometry"], cutters.inputs[0])
    L(bores.outputs["Output"], cutters.inputs[0])

    drill_fast = N("GeometryNodeMeshBoolean")
    drill_fast.operation = 'DIFFERENCE'
    if hasattr(drill_fast, "solver"):
        drill_fast.solver = 'MANIFOLD'
    L(gi(S_GEO), drill_fast.inputs["Mesh 1"])
    L(cutters.outputs[0], drill_fast.inputs["Mesh 2"])

    drill_exact = N("GeometryNodeMeshBoolean")
    drill_exact.operation = 'DIFFERENCE'
    if "Self Intersection" in drill_exact.inputs:
        drill_exact.inputs["Self Intersection"].default_value = True
    L(gi(S_GEO), drill_exact.inputs["Mesh 1"])
    L(cutters.outputs[0], drill_exact.inputs["Mesh 2"])

    fast_size = N("GeometryNodeAttributeDomainSize")
    fast_size.component = 'MESH'
    L(drill_fast.outputs["Mesh"], fast_size.inputs["Geometry"])
    fast_failed = N("FunctionNodeCompare")
    fast_failed.data_type = 'INT'
    fast_failed.operation = 'EQUAL'
    L(fast_size.outputs["Point Count"], fast_failed.inputs[2])
    fast_failed.inputs[3].default_value = 0
    sw_fallback = N("GeometryNodeSwitch"); sw_fallback.input_type = 'GEOMETRY'
    L(fast_failed.outputs["Result"], sw_fallback.inputs["Switch"])
    L(drill_fast.outputs["Mesh"], sw_fallback.inputs["False"])
    L(drill_exact.outputs["Mesh"], sw_fallback.inputs["True"])

    # 穴マーカーも軸穴も無いならブーリアン自体をスキップする。
    hp_size = N("GeometryNodeAttributeDomainSize")
    hp_size.component = 'POINTCLOUD'
    L(i2p.outputs["Points"], hp_size.inputs["Geometry"])
    has_holes = N("FunctionNodeCompare")
    has_holes.data_type = 'INT'
    has_holes.operation = 'GREATER_THAN'
    L(hp_size.outputs["Point Count"], has_holes.inputs[2])
    has_holes.inputs[3].default_value = 0

    bp_size = N("GeometryNodeAttributeDomainSize")
    bp_size.component = 'POINTCLOUD'
    L(b_i2p.outputs["Points"], bp_size.inputs["Geometry"])
    n_bores = N("FunctionNodeCompare")
    n_bores.data_type = 'INT'
    n_bores.operation = 'GREATER_THAN'
    L(bp_size.outputs["Point Count"], n_bores.inputs[2])
    n_bores.inputs[3].default_value = 0
    has_bores = N("FunctionNodeBooleanMath")
    has_bores.operation = 'AND'
    L(n_bores.outputs["Result"], has_bores.inputs[0])
    L(gi(S_SOLID_DRILL), has_bores.inputs[1])

    any_cutter = N("FunctionNodeBooleanMath")
    any_cutter.operation = 'OR'
    L(has_holes.outputs["Result"], any_cutter.inputs[0])
    L(has_bores.outputs[0], any_cutter.inputs[1])

    sw_drill = N("GeometryNodeSwitch"); sw_drill.input_type = 'GEOMETRY'
    L(any_cutter.outputs[0], sw_drill.inputs["Switch"])
    L(gi(S_GEO), sw_drill.inputs["False"])
    L(sw_fallback.outputs["Output"], sw_drill.inputs["True"])

    L(sw_drill.outputs["Output"], gout.inputs[0])
    ng["hk_version"] = NG_VERSION
    return ng


# ---- モディファイア管理 -----------------------------------------------------

def _get_nodes_mod(obj, name):
    mod = obj.modifiers.get(name)
    if mod is not None and mod.type == 'NODES':
        return mod
    return None


def get_hollow_modifier(obj):
    return _get_nodes_mod(obj, MOD_HOLLOW)


def get_drill_modifier(obj):
    return _get_nodes_mod(obj, MOD_DRILL)


def _fix_order(obj):
    """中空化モディファイアが穴あけより前に来るよう並べ替える。"""
    names = [m.name for m in obj.modifiers]
    if MOD_HOLLOW in names and MOD_DRILL in names:
        hi = names.index(MOD_HOLLOW)
        di = names.index(MOD_DRILL)
        if hi > di:
            obj.modifiers.move(hi, di)


def ensure_hollow_modifier(obj):
    mod = get_hollow_modifier(obj)
    if mod is None:
        mod = obj.modifiers.new(MOD_HOLLOW, 'NODES')
    mod.node_group = ensure_hollow_group()
    _fix_order(obj)
    return mod


def ensure_drill_modifier(obj, st):
    """穴あけモディファイア(段階②)を用意して設定を同期する。

    ブーリアンは重いので既定でライブ計算しない(show_viewport=False)。
    マーカーは配置のみ行い、穴形状はワイヤプレビュー物体で視覚化する。
    実際に穴が開くのは「穴あけを確定」時(またはライブ表示を ON にした時)。
    """
    mod = get_drill_modifier(obj)
    if mod is None:
        mod = obj.modifiers.new(MOD_DRILL, 'NODES')
        mod.show_viewport = False   # 既定はライブ計算オフ(配置のみ)
    mod.node_group = ensure_drill_group()
    _fix_order(obj)
    get_hole_collection(obj, create=True)
    ensure_hole_preview(obj)
    sync_modifier(obj, st)
    return mod


def _hollow_values(st, obj):
    return {
        S_HOLLOW: st.use_hollow,
        S_WALL: st.wall_thickness,
        S_VOXEL: resolve_voxel(st, obj),
        S_ADAPT: st.adaptivity,
        S_ONLY_LARGEST: st.cavity_mode == 'LARGEST',
        S_MIN_CAV: (st.min_cavity_size
                    if st.cavity_mode == 'THRESHOLD' else 0.0),
        S_SOLID_COLL: get_solid_collection(obj, create=False),
        S_SOLID_DIA: st.solid_diameter,
        S_SOLID_LEN: st.solid_length,
    }


def _drill_values(st, obj):
    return {
        S_HOLE_DIA: st.hole_diameter,
        S_HOLE_LEN: resolve_depth(st, obj),
        S_HOLE_COLL: get_hole_collection(obj, create=False),
        S_SOLID_COLL: get_solid_collection(obj, create=False),
        S_SOLID_BORE: st.solid_bore,
        S_SOLID_LEN: st.solid_length,
        S_SOLID_DRILL: st.solid_drill,
    }


def _write_values(mod, ids, values):
    for name, val in values.items():
        ident = ids.get(name)
        if ident is None:
            continue
        try:
            mod[ident] = val
        except Exception:
            pass


def sync_modifier(obj, st):
    """シーン設定の値を両モディファイア(とプレビュー物体)へ書き込む。
    S_USE_CACHE / S_CACHE_OBJ は freeze/unfreeze が管理する。"""
    any_mod = False
    hmod = get_hollow_modifier(obj)
    if hmod is not None and hmod.node_group is not None:
        ids = input_identifiers(hmod.node_group)
        values = _hollow_values(st, obj)
        _write_values(hmod, ids, values)
        # 空洞プレビュー中は本体の再計算を止め、プレビュー物体だけ更新する。
        pv = get_preview(obj)
        hmod.show_viewport = (pv is None)
        if pv is not None:
            pmod = pv.modifiers.get(MOD_HOLLOW)
            if pmod is not None and pmod.type == 'NODES' \
                    and pmod.node_group is not None:
                pids = input_identifiers(pmod.node_group)
                _write_values(pmod, pids, values)
                try:
                    pmod[pids[S_PREVIEW]] = True
                    pmod[pids[S_USE_CACHE]] = hmod[ids[S_USE_CACHE]]
                    pmod[pids[S_CACHE_OBJ]] = hmod[ids[S_CACHE_OBJ]]
                except Exception:
                    pass
            pv.update_tag()
        any_mod = True
    dmod = get_drill_modifier(obj)
    if dmod is not None and dmod.node_group is not None:
        dids = input_identifiers(dmod.node_group)
        _write_values(dmod, dids, _drill_values(st, obj))
        any_mod = True
    # 穴形状ワイヤプレビューにも同じ穴設定を書き込む。
    hp = get_hole_preview(obj)
    if hp is not None:
        hpm = hp.modifiers.get(MOD_HOLEPREV)
        if hpm is not None and hpm.type == 'NODES' \
                and hpm.node_group is not None:
            _write_values(hpm, input_identifiers(hpm.node_group),
                          _drill_values(st, obj))
        hp.update_tag()
    if any_mod:
        obj.update_tag()
    return any_mod


def resolve_voxel(st, obj):
    """解像度(ボクセルサイズ)を解決する。自動なら最大寸法 / ディテール。"""
    if st.voxel_mode == 'AUTO':
        return max_dimension(obj) / max(st.detail, 1)
    return st.voxel_size


def resolve_depth(st, obj):
    """穴の長さを解決する。

    自動のとき: 中空化中は「壁を貫いて空洞に届くだけ」の長さ(壁厚×2 +
    穴幅×2)にし、反対側の壁や途中の形状まで貫通させない。斜め刺しでも
    届くようマージンを含む。中空化しない場合のみ全体を貫通させる。
    """
    if st.hole_len_mode == 'AUTO':
        if st.use_hollow:
            return st.wall_thickness * 2.0 + st.hole_diameter * 2.0
        return max_dimension(obj) * 2.0
    return st.hole_length


def apply_to_objects(context, st, objs):
    """対象オブジェクトへ中空化モディファイア(段階①)を付与し値を同期する。"""
    done = []
    for obj in objs:
        # v0.8 以前の一体型モディファイアは除去(二重適用防止)。
        legacy = obj.modifiers.get(LEGACY_MODIFIER)
        if legacy is not None and legacy.type == 'NODES':
            obj.modifiers.remove(legacy)
        ensure_hollow_modifier(obj)
        get_solid_collection(obj, create=True)  # 軸コレクションを用意
        unfreeze_object(obj)                    # 更新時はキャッシュを作り直し
        sync_modifier(obj, st)
        done.append(obj)
    return done


def sync_active(context):
    """アクティブオブジェクトにモディファイアがあれば設定を反映(ライブ更新)。"""
    obj = context.active_object
    if obj is None or obj.type != 'MESH':
        return
    sync_modifier(obj, context.scene.hollowkit)


def remove_from_object(obj, remove_markers=True):
    remove_preview(obj)
    remove_hole_preview(obj)
    for name in (MOD_HOLLOW, MOD_DRILL, LEGACY_MODIFIER):
        mod = obj.modifiers.get(name)
        if mod is not None and mod.type == 'NODES':
            obj.modifiers.remove(mod)
    delete_cache(obj)
    if remove_markers:
        delete_hole_collection(obj)
        delete_solid_collection(obj)


def _apply_modifier(context, obj, mod):
    mod.show_viewport = True
    obj.update_tag()
    with context.temp_override(object=obj, active_object=obj,
                               selected_objects=[obj]):
        bpy.ops.object.modifier_apply(modifier=mod.name)


def bake_hollow_object(context, obj):
    """段階①(中空化+軸柱)をメッシュへ焼き込み、関連物を片付ける。"""
    mod = get_hollow_modifier(obj)
    if mod is None:
        return False
    remove_preview(obj)
    if mod.node_group is not None:
        ids = input_identifiers(mod.node_group)
        try:
            mod[ids[S_PREVIEW]] = False
            mod[ids[S_CAPTURE]] = False
        except Exception:
            pass
    _apply_modifier(context, obj, mod)
    delete_solid_collection(obj)
    delete_cache(obj)
    return True


def bake_drill_object(context, obj):
    """段階②(穴あけ)をメッシュへ焼き込み、穴マーカーを片付ける。

    ライブ表示がオフでも _apply_modifier が有効化してから適用するので、
    穴はこの確定時に必ず開く。
    """
    mod = get_drill_modifier(obj)
    if mod is None:
        return False
    remove_hole_preview(obj)
    _apply_modifier(context, obj, mod)
    delete_hole_collection(obj)
    return True


# ---- 穴/軸マーカー(Empty)管理 ----------------------------------------------

def _root_collection():
    """HollowKit の管理物(マーカー/キャッシュ/プレビュー)用の親コレクション。"""
    parent = bpy.data.collections.get("HollowKit")
    if parent is None:
        parent = bpy.data.collections.new("HollowKit")
        bpy.context.scene.collection.children.link(parent)
    return parent


def _marker_collection(obj, prefix, create=True):
    """オブジェクト専用のマーカーコレクションを返す。"""
    name = prefix + obj.name
    coll = bpy.data.collections.get(name)
    if coll is None and create:
        coll = bpy.data.collections.new(name)
        parent = _root_collection()
        if name not in [c.name for c in parent.children]:
            parent.children.link(coll)
    return coll


def get_hole_collection(obj, create=True):
    return _marker_collection(obj, HOLE_COLL_PREFIX, create)


def get_solid_collection(obj, create=True):
    return _marker_collection(obj, SOLID_COLL_PREFIX, create)


def _delete_marker_collection(obj, prefix):
    coll = bpy.data.collections.get(prefix + obj.name)
    if coll is None:
        return
    for o in list(coll.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.data.collections.remove(coll)


def delete_hole_collection(obj):
    _delete_marker_collection(obj, HOLE_COLL_PREFIX)


def delete_solid_collection(obj):
    _delete_marker_collection(obj, SOLID_COLL_PREFIX)


def _add_marker(context, obj, coll, name, location, normal):
    """矢印 Empty マーカーを追加し、コレクションへ入れて対象に親付けする。

    矢印(+Z)がモデル内側=掘る/柱を伸ばす向きになる。
    """
    size = max_dimension(obj) * 0.15
    empty = bpy.data.objects.new(name, None)
    empty.empty_display_type = 'SINGLE_ARROW'
    empty.empty_display_size = size
    coll.objects.link(empty)

    if location is None:
        location = obj.matrix_world.translation.copy()
    empty.matrix_world.translation = location

    # 向き: 法線があればその逆向き(内側)、無ければ下向き。
    if normal is not None and normal.length > 1e-6:
        _aim_z(empty, -normal.normalized())
    else:
        _aim_z(empty, Vector((0.0, 0.0, -1.0)))

    # 親付け(オフセットを保ったまま)。
    empty.parent = obj
    empty.matrix_parent_inverse = obj.matrix_world.inverted()
    return empty


def add_hole_marker(context, obj, location=None, normal=None):
    """穴(排出/エア抜き)マーカーを追加する。段階②のモディファイアも用意する。"""
    ensure_drill_modifier(obj, context.scene.hollowkit)
    coll = get_hole_collection(obj, create=True)
    return _add_marker(context, obj, coll, HOLE_MARKER_PREFIX, location, normal)


def add_solid_marker(context, obj, location=None, normal=None):
    """軸打ち用の中実柱マーカーを追加する。柱は矢印方向へ伸びる。

    柱の差し引きはキャッシュの後段なので、固定中でもライブに反映される。
    """
    coll = get_solid_collection(obj, create=True)
    return _add_marker(context, obj, coll, SOLID_MARKER_PREFIX, location, normal)


def _aim_z(obj, direction):
    """オブジェクトの +Z が direction を向くよう回転を設定する。"""
    z = Vector((0.0, 0.0, 1.0))
    quat = z.rotation_difference(direction.normalized())
    obj.rotation_euler = quat.to_euler()


def count_markers(obj):
    coll = bpy.data.collections.get(HOLE_COLL_PREFIX + obj.name)
    return len(coll.objects) if coll else 0


def count_solid_markers(obj):
    coll = bpy.data.collections.get(SOLID_COLL_PREFIX + obj.name)
    return len(coll.objects) if coll else 0


# ---- 中空化キャッシュ(調整の軽量化) ----------------------------------------

def _cache_name(obj):
    return CACHE_PREFIX + obj.name


def is_frozen(obj):
    """中空化キャッシュが有効かどうか。"""
    mod = get_hollow_modifier(obj)
    if mod is None or mod.node_group is None:
        return False
    ids = input_identifiers(mod.node_group)
    ident = ids.get(S_USE_CACHE)
    if ident is None:
        return False
    try:
        return bool(mod[ident])
    except Exception:
        return False


def _preview_mod(obj):
    pv = get_preview(obj)
    if pv is None:
        return None
    pmod = pv.modifiers.get(MOD_HOLLOW)
    if pmod is not None and pmod.type == 'NODES' \
            and pmod.node_group is not None:
        return pmod
    return None


def _set_cache_inputs(obj, use, cache):
    """本体とプレビュー両方のモディファイアへキャッシュ状態を書き込む。"""
    for m in (get_hollow_modifier(obj), _preview_mod(obj)):
        if m is None or m.node_group is None:
            continue
        ids = input_identifiers(m.node_group)
        try:
            m[ids[S_USE_CACHE]] = use
            m[ids[S_CACHE_OBJ]] = cache
        except Exception:
            pass


def freeze_object(context, obj):
    """生空洞(柱を引く前)を隠しメッシュへ確定し、以後の軸柱は軽い
    ブーリアンだけで再計算する。マーカーのドラッグが軽くなる。"""
    mod = get_hollow_modifier(obj)
    if mod is None or mod.node_group is None:
        return False
    ids = input_identifiers(mod.node_group)

    # キャッシュ取得モードで評価し、柱を引く前の生空洞を取り出す。
    prev_show = mod.show_viewport
    mod.show_viewport = True
    mod[ids[S_CAPTURE]] = True
    mod[ids[S_USE_CACHE]] = False
    obj.update_tag()
    dg = context.evaluated_depsgraph_get()
    ev = obj.evaluated_get(dg)
    me = bpy.data.meshes.new_from_object(ev, depsgraph=dg)
    mod[ids[S_CAPTURE]] = False
    mod.show_viewport = prev_show

    # キャッシュオブジェクト(隠しメッシュ)を作成/更新する。
    name = _cache_name(obj)
    cache = bpy.data.objects.get(name)
    if cache is None:
        cache = bpy.data.objects.new(name, me)
        _root_collection().objects.link(cache)
    else:
        old = cache.data
        cache.data = me
        if old is not None and old.users == 0:
            bpy.data.meshes.remove(old)
    me.name = name
    # 対象に追従させ、モディファイア座標系(RELATIVE)で一致させる。
    cache.parent = obj
    cache.matrix_parent_inverse.identity()
    cache.matrix_basis.identity()
    cache.hide_viewport = True
    cache.hide_render = True

    _set_cache_inputs(obj, True, cache)
    obj.update_tag()
    return True


def unfreeze_object(obj):
    """中空化キャッシュを解除し、ライブ計算に戻す。"""
    _set_cache_inputs(obj, False, None)
    delete_cache(obj)
    obj.update_tag()


def delete_cache(obj):
    cache = bpy.data.objects.get(_cache_name(obj))
    if cache is not None:
        me = cache.data
        bpy.data.objects.remove(cache, do_unlink=True)
        if me is not None and me.users == 0:
            bpy.data.meshes.remove(me)


def clear_all_caches():
    """全オブジェクトのキャッシュを解除する(中空化パラメータ変更時)。"""
    for obj in bpy.data.objects:
        if obj.type == 'MESH' and is_frozen(obj):
            unfreeze_object(obj)


# ---- 空洞プレビュー(軸柱をライブ確認) --------------------------------------

def get_preview(obj):
    return bpy.data.objects.get(PREVIEW_PREFIX + obj.name)


def create_preview(context, obj, st):
    """空洞(+軸柱)をワイヤフレームで重ね表示するプレビュー物体を作る。

    本体モディファイアのビューポート表示を切り、調整中の再計算を
    プレビュー(空洞側)だけにする。マーカーを動かすと即座に反映される。
    """
    mod = get_hollow_modifier(obj)
    if mod is None:
        return None
    remove_preview(obj)   # 作り直し

    name = PREVIEW_PREFIX + obj.name
    # 本体とメッシュデータを共有する(=ノード入力が元ジオメトリになる)。
    pv = bpy.data.objects.new(name, obj.data)
    _root_collection().objects.link(pv)
    pv.parent = obj
    pv.matrix_parent_inverse.identity()
    pv.matrix_basis.identity()
    pv.display_type = 'WIRE'
    pv.show_in_front = True
    pv.hide_render = True
    pv.hide_select = True

    pmod = pv.modifiers.new(MOD_HOLLOW, 'NODES')
    pmod.node_group = mod.node_group or ensure_hollow_group()
    sync_modifier(obj, st)   # 値の書込み+S_PREVIEW/キャッシュ同期+本体表示OFF
    return pv


def remove_preview(obj):
    """プレビュー物体を削除し、本体モディファイアの表示を戻す。"""
    pv = get_preview(obj)
    if pv is not None:
        me = pv.data
        bpy.data.objects.remove(pv, do_unlink=True)
        if me is not None and me.users == 0:
            bpy.data.meshes.remove(me)
    mod = get_hollow_modifier(obj)
    if mod is not None:
        mod.show_viewport = True


# ---- 穴形状ワイヤプレビュー(配置の視覚化、ブーリアン無し) ------------------

def get_hole_preview(obj):
    return bpy.data.objects.get(HOLEPREV_PREFIX + obj.name)


def ensure_hole_preview(obj):
    """穴の直方体をワイヤ表示するプレビュー物体を用意する(超軽量)。"""
    pv = get_hole_preview(obj)
    if pv is not None:
        return pv
    name = HOLEPREV_PREFIX + obj.name
    me = bpy.data.meshes.new(name)
    pv = bpy.data.objects.new(name, me)
    _root_collection().objects.link(pv)
    pv.parent = obj
    pv.matrix_parent_inverse.identity()
    pv.matrix_basis.identity()
    pv.display_type = 'WIRE'
    pv.show_in_front = True
    pv.hide_render = True
    pv.hide_select = True
    pmod = pv.modifiers.new(MOD_HOLEPREV, 'NODES')
    pmod.node_group = ensure_holeprev_group()
    return pv


def remove_hole_preview(obj):
    pv = get_hole_preview(obj)
    if pv is not None:
        me = pv.data
        bpy.data.objects.remove(pv, do_unlink=True)
        if me is not None and me.users == 0:
            bpy.data.meshes.remove(me)


def has_modifier(context):
    obj = context.active_object
    return (obj is not None and obj.type == 'MESH'
            and (get_hollow_modifier(obj) is not None
                 or get_drill_modifier(obj) is not None))


def has_hollow_modifier(context):
    obj = context.active_object
    return (obj is not None and obj.type == 'MESH'
            and get_hollow_modifier(obj) is not None)
