# SLA Support Generator (SLASG) アセットの読み込みとサポートオブジェクト構築
#
# 本アドオンは morokko-at-gh 氏の SLA_Support_Generator (MIT License) の
# Geometry Nodes アセットを assets/ に同梱し、ワンクリックでセットアップする
# ラッパーです。生成処理そのものはすべて同梱の Geometry Nodes が行います。
#
#   上流: https://github.com/morokko-at-gh/SLA_Support_Generator
#   同梱コミット: 0d9334eb98b4e0302bc751a6e5e25aae2f951a17
#
# ソケットID (Socket_XX) は同梱 .blend 内ノードグループの interface 定義に
# 対応しています。アセットを更新した場合はズレていないか要確認。

import os

import bpy

ASSET_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
BLEND_MAIN = os.path.join(ASSET_DIR, "SLASG_MilliMetreUnit.blend")
BLEND_MIXED = os.path.join(ASSET_DIR, "SLASG_MixedStacking.blend")

NG_GENERATOR = "SLASG_SupportGenerator"
NG_SCATTER = "SLASG_VertexScatter"
NG_APARTMENT = "SLASG_Apartment"  # 混合スタック（Mixed Stacking）
MAT_VALID_VIEWER = "3DPValidViewer"

# --- SLASG_SupportGenerator 入力ソケット ------------------------------------
GEN = {
    "target_type": "Socket_69",      # メニュー: 0=Object, 1=Collection
    "target_object": "Socket_2",
    "target_collection": "Socket_70",
    "preview_mode": "Socket_75",     # メニュー: 0=Full, 1=Only Tip
    "auto_snap": "Socket_10",
    "low_poly_mode": "Socket_76",
    "vertex_vg": "Socket_11",
    "edge_vg": "Socket_12",
    "vertical_vg": "Socket_40",
    "resolution": "Socket_19",
    "max_neck_angle": "Socket_3",
    "touch_diameter": "Socket_4",
    "neck_diameter": "Socket_5",
    "pillar_diameter": "Socket_7",
    "base_diameter": "Socket_8",
    "touch_depth": "Socket_41",
    "neck_length": "Socket_6",
    "base_height": "Socket_9",
    "tree_section_increment": "Socket_44",
    "truss": "Socket_32",
    "truss_distance_limit": "Socket_15",
    "truss_minimum_height": "Socket_38",
    "truss_top_spacing": "Socket_16",
    "truss_angle": "Socket_43",
    "truss_spacing": "Socket_39",
    "truss_diameter": "Socket_18",
    "raft": "Socket_31",
    "raft_voxel_resolution": "Socket_23",
    "raft_expand_width": "Socket_24",
    "raft_floor_thickness": "Socket_25",
    "raft_wall_height": "Socket_26",
    "raft_wall_thickness": "Socket_27",
    "raft_wall_angle": "Socket_28",
    "vertical_stacking": "Socket_46",
    "stack_count": "Socket_49",
    "stack_z_spacing": "Socket_48",
    "multi_storey": "Socket_61",
    "enclose_ceiling": "Socket_59",
    "floor_thickness": "Socket_54",
    "floor_shape": "Socket_67",      # メニュー: 0=From Raft, 1=Reference Mesh
    "floor_shape_mesh": "Socket_68",
    "column_count": "Socket_50",
    "column_perimeter_offset": "Socket_62",
    "column_diameter": "Socket_53",
    "column_area_increment": "Socket_55",
    "brace_concentric": "Socket_51",
    "brace_thickness": "Socket_52",
    "brace_angle": "Socket_56",
    "brace_method": "Socket_65",     # メニュー: 0=Centroid, 1=Straight Skeleton
    "straight_skeleton_iteration": "Socket_66",
    "diagonal": "Socket_63",
    "diagonal_diameter": "Socket_64",
}

# --- SLASG_VertexScatter 入力ソケット ---------------------------------------
SCATTER = {
    "target_type": "Socket_28",      # メニュー: 0=Object, 1=Collection
    "target_object": "Socket_2",
    "target_collection": "Socket_29",
    "spacing": "Socket_5",
    "safe_distance": "Socket_8",
    "angle": "Socket_4",
    "facing_down": "Socket_19",
    "topological_island": "Socket_15",
    "ridge_angle": "Socket_12",
    "vertical_attr": "Socket_20",
    "edge_attr": "Socket_21",
    "auto_tree": "Socket_25",
    "merge_distance": "Socket_26",
    "branch_descent": "Socket_27",
}

# --- SLASG_Apartment (Mixed Stacking) 入力ソケット ---------------------------
APARTMENT = {
    "shape_type": "Socket_8",        # メニュー: 0=From Collection, 1=From Own Mesh
    "target_collection": "Socket_9",
    "merge_height": "Socket_10",
    "merge_horizontal": "Socket_11",
    "show_bounding_boxes": "Socket_14",
}

# --- 印刷実績のある初期値（mmシーン用） ---------------------------------------
# 同梱 SLASG_MilliMetreUnit.blend のサンプルオブジェクト
# Support_LowPoly_Medium / Support_HighPoly_Midium の設定値に基づく。
# ※ノードグループのデフォルト値は印刷可能な寸法になっていない（上流READMEに
#   記載の既知の制約）ため、生成時にこのプリセットを適用する。
GEN_PRESET = {
    "preview_mode": 0,               # Full
    "auto_snap": True,
    "low_poly_mode": False,
    "resolution": 12,
    "max_neck_angle": 0.7853982,     # 45°
    "touch_diameter": 0.5,
    "neck_diameter": 0.4,
    "pillar_diameter": 1.2,
    "base_diameter": 5.0,
    "touch_depth": 0.0,
    "neck_length": 2.0,
    "base_height": 2.0,
    "tree_section_increment": 50.0,
    # トラス/ラフトは低速なため編集中はオフ推奨（上流ドキュメント）。仕上げ時にオンへ。
    "truss": False,
    "truss_distance_limit": 6.0,
    "truss_minimum_height": 5.0,
    "truss_top_spacing": 0.0,
    "truss_angle": 0.7853982,        # 45°
    "truss_spacing": 2.5,
    "truss_diameter": 1.0,
    "raft": False,
    "raft_voxel_resolution": 16,
    "raft_expand_width": 5.0,
    "raft_floor_thickness": 1.0,
    "raft_wall_height": 2.0,
    "raft_wall_thickness": 1.0,
    "raft_wall_angle": 0.5235988,    # 30°
    "vertical_stacking": False,
    "stack_count": 2,
    "stack_z_spacing": 50.0,
    "multi_storey": False,
    "floor_thickness": 1.0,
    "column_count": 6,
    "column_diameter": 2.0,
    "column_area_increment": 20.0,
    "brace_concentric": 6,
    "brace_thickness": 0.7,
    "brace_angle": 0.6108652,        # 35°
}

SCATTER_PRESET = {
    "spacing": 2.0,
    "safe_distance": 1.0,
    "angle": 0.7853982,              # 45°
    "facing_down": True,
    "topological_island": True,
    "ridge_angle": 0.7853982,
    "auto_tree": True,
    "merge_distance": 3.0,
    "branch_descent": 3.0,
}


# --- アセット読み込み ---------------------------------------------------------
def _find_local(collection, name):
    """ライブラリ由来ではないローカルのデータブロックを名前で探す。"""
    for datablock in collection:
        if datablock.name == name and datablock.library is None:
            return datablock
    return None


def ensure_node_group(name, blend_path):
    """同梱 .blend からノードグループをアペンドする（既にあれば再利用）。

    既存を再利用することで、上流READMEが注意している
    「コピー＆ペースト繰り返しによるノードグループの重複」を回避する。
    """
    existing = _find_local(bpy.data.node_groups, name)
    if existing is not None:
        return existing

    if not os.path.exists(blend_path):
        raise FileNotFoundError(f"同梱アセットが見つかりません: {blend_path}")

    with bpy.data.libraries.load(blend_path, link=False) as (src, dst):
        if name not in src.node_groups:
            raise RuntimeError(f"{os.path.basename(blend_path)} に {name} がありません")
        dst.node_groups = [name]
    return dst.node_groups[0]


def ensure_material(name, blend_path=BLEND_MAIN):
    """同梱 .blend からマテリアルをアペンドする（既にあれば再利用）。"""
    existing = _find_local(bpy.data.materials, name)
    if existing is not None:
        return existing

    with bpy.data.libraries.load(blend_path, link=False) as (src, dst):
        if name not in src.materials:
            raise RuntimeError(f"{os.path.basename(blend_path)} に {name} がありません")
        dst.materials = [name]
    mat = dst.materials[0]
    mat.use_fake_user = True  # 未割り当てでもビュー切替用に保持
    return mat


# --- モディファイア操作 --------------------------------------------------------
def apply_preset(mod, socket_map, preset):
    for key, value in preset.items():
        mod[socket_map[key]] = value


def set_target(mod, socket_map, target):
    """Object / Collection どちらでもターゲットに設定できるようにする。"""
    if isinstance(target, bpy.types.Collection):
        mod[socket_map["target_type"]] = 1
        mod[socket_map["target_collection"]] = target
    elif isinstance(target, bpy.types.Object):
        mod[socket_map["target_type"]] = 0
        mod[socket_map["target_object"]] = target


def get_modifier(ob, node_group_name):
    """指定ノードグループを使う Geometry Nodes モディファイアを返す。"""
    if ob is None:
        return None
    for mod in ob.modifiers:
        if mod.type == "NODES" and mod.node_group and mod.node_group.name == node_group_name:
            return mod
    return None


def is_support_object(ob):
    return get_modifier(ob, NG_GENERATOR) is not None


# --- サポートオブジェクト構築 ---------------------------------------------------
def create_support_object(context, target=None, auto_scatter=False):
    """SLASGサポートオブジェクトを新規作成する。

    - 手動配置: 空メッシュ + SLASG_SupportGenerator。
      編集モードで頂点を追加した位置がサポート付着点になる。
    - 自動配置 (auto_scatter=True): SLASG_VertexScatter を
      SupportGenerator の上流に追加し、ターゲットから付着点を自動生成する。
    """
    gen_group = ensure_node_group(NG_GENERATOR, BLEND_MAIN)

    mesh = bpy.data.meshes.new("SLASG_Support")
    ob = bpy.data.objects.new("SLASG_Support", mesh)
    context.collection.objects.link(ob)

    if auto_scatter:
        scatter_group = ensure_node_group(NG_SCATTER, BLEND_MAIN)
        scatter_mod = ob.modifiers.new(NG_SCATTER, "NODES")
        scatter_mod.node_group = scatter_group
        apply_preset(scatter_mod, SCATTER, SCATTER_PRESET)
        set_target(scatter_mod, SCATTER, target)

    gen_mod = ob.modifiers.new(NG_GENERATOR, "NODES")
    gen_mod.node_group = gen_group
    apply_preset(gen_mod, GEN, GEN_PRESET)
    set_target(gen_mod, GEN, target)

    if auto_scatter:
        # サンプル (Support_HighPoly_*) と同じネック方向属性の配線
        gen_mod[GEN["vertex_vg"] + "_use_attribute"] = True
        gen_mod[GEN["vertex_vg"] + "_attribute_name"] = "Vertex"
        gen_mod[GEN["edge_vg"] + "_use_attribute"] = True
        gen_mod[GEN["edge_vg"] + "_attribute_name"] = "Edge"

    return ob


# --- レジン量計算 --------------------------------------------------------------
def _object_volume_ml(ob, deps, scene):
    """モディファイア評価後のワールド空間体積を mL で返す。

    シーン単位を考慮する（単位なし(None)のシーンは 1 BU = 1 mm として扱う）。
    """
    ev = ob.evaluated_get(deps)
    me = ev.to_mesh()
    me.calc_loop_triangles()
    mw = ev.matrix_world
    verts = me.vertices
    total = 0.0
    for tri in me.loop_triangles:
        v0 = mw @ verts[tri.vertices[0]].co
        v1 = mw @ verts[tri.vertices[1]].co
        v2 = mw @ verts[tri.vertices[2]].co
        total += v0.cross(v1).dot(v2) / 6.0  # 符号付き四面体体積
    ev.to_mesh_clear()

    us = scene.unit_settings
    bu_to_mm = us.scale_length * 1000.0 if us.system != "NONE" else 1.0
    volume_mm3 = abs(total) * bu_to_mm**3
    return volume_mm3 / 1000.0  # mm3 -> mL


def compute_resin_volume(context):
    """(造形物mL, サポートmL) を返す。

    ビューレイヤー上の可視メッシュを対象に、SLASGモディファイアを持つ
    オブジェクトをサポート、それ以外を造形物として集計する。
    サポートは重なり（トラス交差等）を含む概算のためやや過大に出る。
    垂直/混合スタックのモデル複製分はサポート側に含まれる。
    """
    deps = context.evaluated_depsgraph_get()
    model_ml = 0.0
    support_ml = 0.0
    for ob in context.view_layer.objects:
        if ob.type != "MESH" or not ob.visible_get():
            continue
        is_support = is_support_object(ob) or get_modifier(ob, NG_APARTMENT) is not None
        vol = _object_volume_ml(ob, deps, context.scene)
        if is_support:
            support_ml += vol
        else:
            model_ml += vol
    return model_ml, support_ml


def create_mixed_stacking_object(context, collection=None):
    """混合スタック（SLASG_Apartment）オブジェクトを新規作成する。"""
    group = ensure_node_group(NG_APARTMENT, BLEND_MIXED)

    mesh = bpy.data.meshes.new("SLASG_MixedStacking")
    ob = bpy.data.objects.new("SLASG_MixedStacking", mesh)
    context.collection.objects.link(ob)

    mod = ob.modifiers.new(NG_APARTMENT, "NODES")
    mod.node_group = group
    mod[APARTMENT["shape_type"]] = 0  # From Collection
    if collection is not None:
        mod[APARTMENT["target_collection"]] = collection
    return ob
