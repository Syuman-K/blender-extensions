# オペレーター定義（SLASGサポートのセットアップ / 編集補助）

import bpy
from bpy.types import Operator

from . import slasg


def _pick_target(context):
    """アクティブ（または選択中）のメッシュをターゲット候補として返す。

    サポートオブジェクト自身はターゲットにしない。
    """
    ob = context.active_object
    if ob and ob.type == "MESH" and not slasg.is_support_object(ob):
        return ob
    for ob in context.selected_objects:
        if ob.type == "MESH" and not slasg.is_support_object(ob):
            return ob
    return None


class ASG_OT_add_support(Operator):
    bl_idname = "asg.add_support"
    bl_label = "サポートを追加"
    bl_description = (
        "SLASGサポートオブジェクトを追加します。"
        "アクティブなメッシュが自動的にターゲットになります"
    )
    bl_options = {"REGISTER", "UNDO"}

    auto_scatter: bpy.props.BoolProperty(
        name="自動配置",
        description="Vertex Scatter でターゲットから付着点を自動生成します",
        default=False,
    )

    def execute(self, context):
        if context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")

        target = _pick_target(context)
        try:
            ob = slasg.create_support_object(context, target=target, auto_scatter=self.auto_scatter)
        except Exception as exc:  # noqa: BLE001 - ユーザーへ通知して安全に中断
            self.report({"ERROR"}, f"サポートオブジェクトの作成に失敗しました: {exc}")
            return {"CANCELLED"}

        for o in context.selected_objects:
            o.select_set(False)
        ob.select_set(True)
        context.view_layer.objects.active = ob

        if target is None:
            self.report(
                {"WARNING"},
                f"{ob.name} を追加しました。モディファイアの Target Object にターゲットを設定してください",
            )
        elif self.auto_scatter:
            self.report({"INFO"}, f"{ob.name} を追加しました（ターゲット: {target.name} / 自動配置）")
        else:
            self.report(
                {"INFO"},
                f"{ob.name} を追加しました（ターゲット: {target.name}）。「付着点を編集」で頂点を配置してください",
            )
        return {"FINISHED"}


class ASG_OT_add_mixed_stacking(Operator):
    bl_idname = "asg.add_mixed_stacking"
    bl_label = "混合スタックを追加"
    bl_description = (
        "多数多種のモデルを一括印刷するための多層構造物（Mixed Stacking）を追加します。"
        "モディファイアの Target Collection に対象コレクションを設定してください"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        if context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        try:
            ob = slasg.create_mixed_stacking_object(context)
        except Exception as exc:  # noqa: BLE001
            self.report({"ERROR"}, f"混合スタックの作成に失敗しました: {exc}")
            return {"CANCELLED"}

        for o in context.selected_objects:
            o.select_set(False)
        ob.select_set(True)
        context.view_layer.objects.active = ob
        self.report({"INFO"}, f"{ob.name} を追加しました。Target Collection を設定してください")
        return {"FINISHED"}


class ASG_OT_edit_points(Operator):
    bl_idname = "asg.edit_support_points"
    bl_label = "付着点を編集"
    bl_description = (
        "サポートオブジェクトの編集モードに入り、推奨スナップ設定を適用します。"
        "Ctrl+右クリックで付着点（頂点）をモデル表面に追加できます"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return slasg.is_support_object(context.active_object)

    def execute(self, context):
        bpy.ops.asg.setup_snap()
        bpy.ops.object.mode_set(mode="EDIT")
        context.tool_settings.mesh_select_mode = (True, False, False)
        self.report({"INFO"}, "Ctrl+右クリック: 付着点を追加 / G: 移動（モデル表面にスナップします）")
        return {"FINISHED"}


class ASG_OT_apply_scatter(Operator):
    bl_idname = "asg.apply_scatter"
    bl_label = "自動配置を確定"
    bl_description = (
        "Vertex Scatter モディファイアを適用し、自動生成された付着点を"
        "編集可能な頂点として確定します（上流ドキュメント推奨の運用）"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return slasg.get_modifier(context.active_object, slasg.NG_SCATTER) is not None

    def execute(self, context):
        ob = context.active_object
        if context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        mod = slasg.get_modifier(ob, slasg.NG_SCATTER)
        try:
            bpy.ops.object.modifier_apply(modifier=mod.name)
        except Exception as exc:  # noqa: BLE001
            self.report({"ERROR"}, f"適用に失敗しました: {exc}")
            return {"CANCELLED"}
        self.report({"INFO"}, "自動配置を確定しました。「付着点を編集」で手動調整できます")
        return {"FINISHED"}


class ASG_OT_set_preview(Operator):
    bl_idname = "asg.set_preview_mode"
    bl_label = "プレビューモード"
    bl_description = (
        "サポート生成のプレビューモードを切り替えます。"
        "「先端のみ」は付着点のみ表示で高速（ハイポリ編集用）、エクスポート時は「全形状」にします"
    )
    bl_options = {"REGISTER", "UNDO"}

    mode: bpy.props.EnumProperty(
        name="モード",
        items=(
            ("FULL", "全形状", "サポートの全形状を生成（エクスポート時はこちら）"),
            ("TIP", "先端のみ", "付着点のみ表示（高速・ハイポリ編集用）"),
        ),
        default="FULL",
    )

    @classmethod
    def poll(cls, context):
        return slasg.is_support_object(context.active_object)

    def execute(self, context):
        mod = slasg.get_modifier(context.active_object, slasg.NG_GENERATOR)
        mod[slasg.GEN["preview_mode"]] = 0 if self.mode == "FULL" else 1
        mod.node_group.interface_update(context)
        context.active_object.update_tag()
        return {"FINISHED"}


class ASG_OT_setup_snap(Operator):
    bl_idname = "asg.setup_snap"
    bl_label = "推奨スナップ設定"
    bl_description = (
        "付着点編集用の推奨スナップ設定を適用します"
        "（面スナップ / アクティブ基準 / 裏面カリング / 非編集オブジェクトへ吸着）"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ts = context.scene.tool_settings
        ts.use_snap = True
        ts.snap_elements = {"FACE"}
        ts.snap_target = "ACTIVE"
        ts.use_snap_align_rotation = False
        ts.use_snap_backface_culling = True
        ts.use_snap_self = False        # Include Active: オフ
        ts.use_snap_edit = False        # Include Edited: オフ
        ts.use_snap_nonedit = True      # Include Non-Edited: オン（ターゲットに吸着）
        ts.use_snap_selectable = False  # Exclude Non-Selectable: オフ
        ts.use_snap_translate = True
        ts.use_snap_rotate = True
        ts.use_snap_scale = True
        self.report({"INFO"}, "推奨スナップ設定を適用しました")
        return {"FINISHED"}


class ASG_OT_setup_units(Operator):
    bl_idname = "asg.setup_units"
    bl_label = "シーン単位をmmに設定"
    bl_description = (
        "シーンの単位設定を 3Dプリント向けの推奨値にします"
        "（Metric / Unit Scale 0.001 / Millimeters）。1 BU = 1 mm になります"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        us = context.scene.unit_settings
        us.system = "METRIC"
        us.scale_length = 0.001
        us.length_unit = "MILLIMETERS"
        us.system_rotation = "DEGREES"
        self.report({"INFO"}, "シーン単位を mm（1 BU = 1 mm）に設定しました")
        return {"FINISHED"}


class ASG_OT_compute_volume(Operator):
    bl_idname = "asg.compute_volume"
    bl_label = "レジン量を計算"
    bl_description = (
        "造形物とサポート（トラス・ラフト・スタック構造含む）の体積から"
        "必要レジン量(mL)を概算します。サポートは重なりを含むためやや過大に出ます"
    )
    bl_options = {"REGISTER"}

    def execute(self, context):
        try:
            model_ml, support_ml = slasg.compute_resin_volume(context)
        except Exception as exc:  # noqa: BLE001
            self.report({"ERROR"}, f"体積計算に失敗しました: {exc}")
            return {"CANCELLED"}

        total = model_ml + support_ml
        self.report(
            {"INFO"},
            f"レジン概算: 造形物 {model_ml:.2f}mL + サポート {support_ml:.2f}mL "
            f"= 合計 {total:.2f}mL",
        )
        return {"FINISHED"}


class ASG_OT_toggle_valid_viewer(Operator):
    bl_idname = "asg.toggle_valid_viewer"
    bl_label = "3DPチェック表示"
    bl_description = (
        "下向き面のハイライトとスライス面表示を行うチェック用マテリアル"
        "（3DPValidViewer）をビューレイヤーのマテリアルオーバーライドに設定/解除します"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        vl = context.view_layer
        try:
            mat = slasg.ensure_material(slasg.MAT_VALID_VIEWER)
        except Exception as exc:  # noqa: BLE001
            self.report({"ERROR"}, f"チェック用マテリアルの読み込みに失敗しました: {exc}")
            return {"CANCELLED"}

        if vl.material_override == mat:
            vl.material_override = None
            self.report({"INFO"}, "チェック表示を解除しました")
        else:
            vl.material_override = mat
            self.report(
                {"INFO"},
                "チェック表示をオンにしました（マテリアルプレビュー/レンダー表示で確認できます）",
            )
        return {"FINISHED"}


classes = (
    ASG_OT_add_support,
    ASG_OT_add_mixed_stacking,
    ASG_OT_edit_points,
    ASG_OT_apply_scatter,
    ASG_OT_set_preview,
    ASG_OT_setup_snap,
    ASG_OT_setup_units,
    ASG_OT_compute_volume,
    ASG_OT_toggle_valid_viewer,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
