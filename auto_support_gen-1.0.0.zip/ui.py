# 3Dビューポート サイドバー(Nパネル)のUI

import bpy
from bpy.types import Panel

from . import slasg

UPSTREAM_DOC_URL = "https://github.com/morokko-at-gh/SLA_Support_Generator/blob/main/README_ja.md"


def _units_are_mm(context):
    us = context.scene.unit_settings
    return us.system == "METRIC" and abs(us.scale_length - 0.001) < 1e-9


class ASG_PT_main(Panel):
    bl_label = "SLA Support Generator"
    bl_idname = "ASG_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Support"

    def draw(self, context):
        layout = self.layout
        ob = context.active_object

        # --- セットアップ ---
        box = layout.box()
        box.label(text="セットアップ", icon="PREFERENCES")
        if not _units_are_mm(context):
            box.label(text="シーン単位がmm設定ではありません", icon="ERROR")
        box.operator("asg.setup_units", icon="SNAP_INCREMENT")
        box.operator("asg.setup_snap", icon="SNAP_FACE")

        # --- サポート生成 ---
        box = layout.box()
        box.label(text="サポート", icon="MOD_PHYSICS")
        col = box.column(align=True)
        col.scale_y = 1.3
        op = col.operator("asg.add_support", text="サポートを追加（手動配置）", icon="ADD")
        op.auto_scatter = False
        op = col.operator("asg.add_support", text="サポートを追加（自動配置）", icon="POINTCLOUD_DATA")
        op.auto_scatter = True

        gen_mod = slasg.get_modifier(ob, slasg.NG_GENERATOR)
        if gen_mod is not None:
            col = box.column(align=True)
            col.operator("asg.edit_support_points", icon="EDITMODE_HLT")
            if slasg.get_modifier(ob, slasg.NG_SCATTER) is not None:
                col.operator("asg.apply_scatter", icon="CHECKMARK")

            # クイック設定（アクティブなサポートのモディファイア値を直接編集）
            sub = box.box()
            sub.label(text=f"クイック設定: {ob.name}", icon="MODIFIER")
            row = sub.row(align=True)
            is_full = gen_mod[slasg.GEN["preview_mode"]] == 0
            op = row.operator("asg.set_preview_mode", text="全形状", depress=is_full)
            op.mode = "FULL"
            op = row.operator("asg.set_preview_mode", text="先端のみ", depress=not is_full)
            op.mode = "TIP"
            col = sub.column(align=True)
            col.prop(gen_mod, f'["{slasg.GEN["truss"]}"]', text="トラス（仕上げ時にオン）")
            col.prop(gen_mod, f'["{slasg.GEN["raft"]}"]', text="ラフト（仕上げ時にオン）")
            col.prop(gen_mod, f'["{slasg.GEN["vertical_stacking"]}"]', text="垂直スタック")
            if gen_mod[slasg.GEN["vertical_stacking"]]:
                col.prop(gen_mod, f'["{slasg.GEN["stack_count"]}"]', text="個数")
                col.prop(gen_mod, f'["{slasg.GEN["stack_z_spacing"]}"]', text="Z間隔")
                col.prop(gen_mod, f'["{slasg.GEN["multi_storey"]}"]', text="多層構造（パーゴラ）")
            sub.label(text="全パラメータはモディファイアプロパティで", icon="INFO")

        # --- 混合スタック ---
        box = layout.box()
        box.label(text="量産スタック", icon="OUTLINER_OB_POINTCLOUD")
        box.operator("asg.add_mixed_stacking", icon="ADD")

        # --- チェック ---
        box = layout.box()
        box.label(text="チェック", icon="MATERIAL")
        mat = None
        for m in bpy.data.materials:
            if m.name == slasg.MAT_VALID_VIEWER and m.library is None:
                mat = m
                break
        overriding = mat is not None and context.view_layer.material_override == mat
        box.operator(
            "asg.toggle_valid_viewer",
            text="3DPチェック表示を解除" if overriding else "3DPチェック表示",
            icon="HIDE_OFF",
            depress=overriding,
        )
        box.operator("asg.compute_volume", icon="MOD_FLUIDSIM")

        layout.operator("wm.url_open", text="本家ドキュメント（パラメータ解説）", icon="URL").url = UPSTREAM_DOC_URL


classes = (ASG_PT_main,)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
