# Auto Support Gen - 光造形プリンター用 SLASGサポート生成アドオン
#
# morokko-at-gh 氏の SLA_Support_Generator (MIT License) の Geometry Nodes を
# 同梱し、ワンクリックでセットアップできるようにしたラッパーアドオン。
# 生成機能の実体は assets/ 内の Geometry Nodes（詳細は slasg.py と README.md）。
#
# Blender 5.0 系の拡張機能(extension)形式。メタ情報は blender_manifest.toml を参照。
# bl_info は拡張機能では不要だが、レガシーアドオンとして読み込まれた場合の保険として残す。

bl_info = {
    "name": "Auto Support Gen",
    "author": "hiroki.sekimizu",
    "version": (1, 0, 0),
    "blender": (5, 0, 0),
    "location": "3Dビューポート > サイドバー(N) > Support",
    "description": "光造形プリンター用のサポート材を生成します（SLA Support Generator 同梱）",
    "category": "Mesh",
}

import importlib

from . import slasg, operators, ui

# 開発時のリロードに対応（F8 / スクリプト再読み込み）
_modules = (slasg, operators, ui)
for _m in _modules:
    importlib.reload(_m)


def register():
    for m in (operators, ui):
        m.register()


def unregister():
    for m in (ui, operators):
        m.unregister()


if __name__ == "__main__":
    register()
